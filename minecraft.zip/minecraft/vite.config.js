/**
* @type {import('vite').UserConfig}
*/
export default {
  base: '/minecraft/',
  build: {
    sourcemap: true
  }
}