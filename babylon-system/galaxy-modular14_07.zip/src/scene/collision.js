// src/scene/collision.js
// Colisión esférica barata cámara vs cuerpos físicos.
// - Soporta deslizamiento tangencial sobre la superficie
// - Evita el "rebote" radial duro
// - Mantiene sweep test para no tunelar

export function createCameraBodyCollision({
  bodyMaps = [],
  padding = 0.000002,
  allowedKinds = ['planet', 'moon', 'asteroid', 'comet'],
}) {
  const EPS = 1e-8;
  const PAD = Number.isFinite(padding) ? padding : 0.000002;
  const kinds = new Set(
    Array.isArray(allowedKinds) ? allowedKinds : ['planet', 'moon', 'asteroid', 'comet']
  );

  const _n = new BABYLON.Vector3();
  const _move = new BABYLON.Vector3();
  const _tan = new BABYLON.Vector3();
  const _candidate = new BABYLON.Vector3();

  function eachCollisionBody(fn) {
    for (const map of bodyMaps) {
      if (!map || typeof map.values !== 'function') continue;
      for (const node of map.values()) {
        if (!node) continue;
        const md = node.metadata || {};
        if (!kinds.has(md.kind)) continue;

        const radiusWorld = Number(
          md.collisionRadiusWorld ?? md.radiusWorld
        );
        if (!(radiusWorld > 0)) continue;

        fn(node, radiusWorld, md);
      }
    }
  }

  function getNodeWorldPos(node) {
    try { node.computeWorldMatrix?.(true); } catch (_) {}
    try {
      return (typeof node.getAbsolutePosition === 'function')
        ? node.getAbsolutePosition()
        : node.position;
    } catch (_) {
      return node.position;
    }
  }

  function segmentHitsSphere(a, b, c, r) {
    const abx = b.x - a.x;
    const aby = b.y - a.y;
    const abz = b.z - a.z;
    const ab2 = abx * abx + aby * aby + abz * abz;
    if (ab2 < EPS) return false;

    const acx = c.x - a.x;
    const acy = c.y - a.y;
    const acz = c.z - a.z;

    let t = (acx * abx + acy * aby + acz * abz) / ab2;
    if (t < 0) t = 0;
    else if (t > 1) t = 1;

    const qx = a.x + abx * t;
    const qy = a.y + aby * t;
    const qz = a.z + abz * t;

    const dx = qx - c.x;
    const dy = qy - c.y;
    const dz = qz - c.z;
    return (dx * dx + dy * dy + dz * dz) < (r * r);
  }

  function projectOutsideToRef(point, center, minR, ref, fallbackPos = null) {
    ref.x = point.x - center.x;
    ref.y = point.y - center.y;
    ref.z = point.z - center.z;

    let n2 = ref.x * ref.x + ref.y * ref.y + ref.z * ref.z;
    if (n2 < EPS && fallbackPos) {
      ref.x = fallbackPos.x - center.x;
      ref.y = fallbackPos.y - center.y;
      ref.z = fallbackPos.z - center.z;
      n2 = ref.x * ref.x + ref.y * ref.y + ref.z * ref.z;
    }
    if (n2 < EPS) {
      ref.set(0, 1, 0);
      n2 = 1;
    }

    const inv = 1.0 / Math.sqrt(n2);
    ref.x = center.x + ref.x * inv * minR;
    ref.y = center.y + ref.y * inv * minR;
    ref.z = center.z + ref.z * inv * minR;
  }

  function enforceBodyCollision(cam, prevPos = null) {
    if (!cam?.position) return false;

    let collided = false;

    eachCollisionBody((node, radiusWorld) => {
      const center = getNodeWorldPos(node);
      if (!center) return;

      const minR = radiusWorld + PAD;
      const minR2 = minR * minR;

      const dx = cam.position.x - center.x;
      const dy = cam.position.y - center.y;
      const dz = cam.position.z - center.z;
      const d2 = dx * dx + dy * dy + dz * dz;

      let hit = d2 < minR2;
      if (!hit && prevPos) {
        hit = segmentHitsSphere(prevPos, cam.position, center, minR);
      }
      if (!hit) return;

      collided = true;

      // Sin movimiento previo: solo clamp suave fuera de la esfera
      if (!prevPos) {
        projectOutsideToRef(cam.position, center, minR, _candidate, prevPos);
        cam.position.copyFrom(_candidate);
        return;
      }

      // 1) Punto seguro sobre la superficie
      projectOutsideToRef(prevPos, center, minR, _candidate, prevPos);

      // 2) Movimiento deseado del frame
      _move.x = cam.position.x - prevPos.x;
      _move.y = cam.position.y - prevPos.y;
      _move.z = cam.position.z - prevPos.z;

      // 3) Normal superficial
      _n.x = _candidate.x - center.x;
      _n.y = _candidate.y - center.y;
      _n.z = _candidate.z - center.z;
      const nLen = Math.sqrt(_n.x * _n.x + _n.y * _n.y + _n.z * _n.z) || 1;
      _n.scaleInPlace(1 / nLen);

      // 4) Quita la componente radial hacia dentro, conserva la tangencial
      const inward = (_move.x * _n.x) + (_move.y * _n.y) + (_move.z * _n.z);
      _tan.copyFrom(_move);
      if (inward < 0) {
        _tan.x -= _n.x * inward;
        _tan.y -= _n.y * inward;
        _tan.z -= _n.z * inward;
      }

      // 5) Nueva posición deslizante
      cam.position.x = _candidate.x + _tan.x;
      cam.position.y = _candidate.y + _tan.y;
      cam.position.z = _candidate.z + _tan.z;

      // 6) Re-clamp final por curvatura
      const fx = cam.position.x - center.x;
      const fy = cam.position.y - center.y;
      const fz = cam.position.z - center.z;
      const fd2 = fx * fx + fy * fy + fz * fz;
      if (fd2 < minR2) {
        projectOutsideToRef(cam.position, center, minR, _candidate, prevPos);
        cam.position.copyFrom(_candidate);
      }
    });

    return collided;
  }

  return {
    enforceBodyCollision,
  };
}