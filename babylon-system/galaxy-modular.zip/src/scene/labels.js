export function createLabels({ scene, camera, engine }){
  // GUI root
  const gui = BABYLON.GUI.AdvancedDynamicTexture.CreateFullscreenUI("ui", true, scene);

  const labelsById = new Map(); // key -> { rect, tb, kind, mesh, system, planet }
  let showLabels = true;

  // ============================================================
  // Arc label texture (DataURL)
  // ============================================================
  function createArcLabelDataURL(text, kind){
    const size = 512;
    const canvas = document.createElement("canvas");
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext("2d");

    ctx.clearRect(0,0,size,size);
    ctx.translate(size/2, size/2);

    // style
    const color = (kind === "system") ? "#00ffcc" : "#00ffcc";
    ctx.strokeStyle = "rgba(0,255,204,0.35)";
    ctx.lineWidth = 10;

    // ring arc
    const r = 180;
    ctx.beginPath();
    ctx.arc(0,0,r, -Math.PI*0.80, -Math.PI*0.20);
    ctx.stroke();

    // small tick
    ctx.strokeStyle = "rgba(0,255,204,0.55)";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(0,0,r, Math.PI*0.52, Math.PI*0.60);
    ctx.stroke();

    // text
    ctx.font = "700 44px Orbitron, sans-serif";
    ctx.fillStyle = color;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    // glow
    ctx.shadowColor = "#00ffcc";
    ctx.shadowBlur = 18;
    ctx.fillText(String(text || "").toUpperCase(), 0, -220);
    ctx.shadowBlur = 0;

    return canvas.toDataURL("image/png");
  }

  const arcLabelCache = new Map(); // `${kind}:${text}` -> url
  function getArcLabelURL(text, kind){
    const key = `${kind}:${text}`;
    let v = arcLabelCache.get(key);
    if (v) return v;
    v = createArcLabelDataURL(text, kind);
    arcLabelCache.set(key, v);
    return v;
  }

  // ============================================================
  // GUI label creator
  // ============================================================
  function createGuiLabel(id, text, mesh, kind){
    // SYSTEM labels keep arc-ring style (cheap and readable)
    if (kind === "system"){
      const rect = new BABYLON.GUI.Rectangle("lbl_" + String(id));
      rect.background = "rgba(0,0,0,0)";
      rect.thickness = 0;

      const basePx = 120;
      rect.widthInPixels = basePx;
      rect.heightInPixels = basePx;
      rect.horizontalAlignment = BABYLON.GUI.Control.HORIZONTAL_ALIGNMENT_CENTER;
      rect.verticalAlignment = BABYLON.GUI.Control.VERTICAL_ALIGNMENT_CENTER;

      const img = new BABYLON.GUI.Image("img_" + String(id), getArcLabelURL(text, "system"));
      img.stretch = BABYLON.GUI.Image.STRETCH_UNIFORM;
      rect.addControl(img);

      gui.addControl(rect);
      rect.linkWithMesh(mesh);
      rect.linkOffsetY = 0;

      rect._img = img;
      rect._basePx = basePx;
      rect._minPx = 90;
      rect._maxPx = 220;
      rect._pxScale = 1.0;
      rect.alpha = 1;
      rect.isVisible = true;
      return rect;
    }

    // Por defecto: sin label GUI para cuerpos (si usas Elite DOM HUD)
    // Si quieres volver a activarlos, aquí es donde iría.
    return null;
  }

  // ============================================================
  // Public API: register label
  // ============================================================
  function registerLabel(id, text, kind, mesh, extra){
    if (!mesh) return null;

    let key = String(id || "");
    if (!key) return null;

    // Evitar colisiones: namespacing si no viene ya.
    if (!key.includes(":")){
      const sys = extra && extra.system ? extra.system : "";
      const pl  = extra && extra.planet ? extra.planet : "";
      key = `${kind}:${sys}:${pl}:${key}`;
    }

    let meta = labelsById.get(key);
    if (!meta){
      const rect = createGuiLabel(key, text, mesh, kind);
      meta = {
        rect,
        tb: (rect && rect._tb) ? rect._tb : null,
        kind, mesh,
        system: extra && extra.system,
        planet: extra && extra.planet
      };
      labelsById.set(key, meta);
    } else {
      meta.kind = kind || meta.kind;
      meta.mesh = mesh || meta.mesh;
      meta.system = (extra && extra.system) || meta.system;
      meta.planet = (extra && extra.planet) || meta.planet;
      if (meta.rect){
        try { meta.rect.linkWithMesh(meta.mesh); } catch(_){}
      }
    }
    return meta.rect;
  }

  // ============================================================
  // Update sizing (called each frame)
  // ============================================================
  function update(){
    if (!showLabels) return;
    if (!camera || !engine) return;

    const vh = engine.getRenderHeight(true);
    const fov = (typeof camera.fov === "number") ? camera.fov : 0.8;
    const tanHalf = Math.tan(fov * 0.5);
    const camPos = camera.globalPosition || camera.position;

    for (const meta of labelsById.values()){
      if (!meta || !meta.rect || !meta.mesh) continue;
      const rect = meta.rect;
      const mesh = meta.mesh;
      const kind = meta.kind || "system";

      // Systems: optional autosize by distance
      let px = rect._basePx || 120;

      if (kind === "system"){
        const wpos = (mesh.getAbsolutePosition ? mesh.getAbsolutePosition() : mesh.position);
        const d = BABYLON.Vector3.Distance(camPos, wpos);
        // simple distance scaling (clamped)
        const s = Math.max(0.6, Math.min(1.2, 6000 / Math.max(1, d)));
        px = px * s;
      }

      const minPx = rect._minPx || 80;
      const maxPx = rect._maxPx || 260;
      px = Math.max(minPx, Math.min(maxPx, px));

      rect.widthInPixels = px;
      rect.heightInPixels = px;
      rect.isVisible = showLabels;
    }
  }

  function setShowLabels(v){
    showLabels = !!v;
    for (const meta of labelsById.values()){
      if (meta && meta.rect) meta.rect.isVisible = showLabels;
    }
  }

  return {
    gui,
    registerLabel,
    update,
    setShowLabels,
    labelsById,
    getArcLabelURL,
  };
}