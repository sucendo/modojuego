export function setupLights(scene){
  // Mantén exactamente los mismos valores que tenías en createScene
  const light = new BABYLON.HemisphericLight(
    "hemi",
    new BABYLON.Vector3(0.2, 1, 0.2),
    scene
  );
  light.intensity = 0.85;
  return { light };
}