// bodies/stars.js
// Crea estrellas y registra luces por sistema.
// - Si una estrella tiene elementos orbitales (periapsis/apoapsis/orbitalPeriod),
//   se crea su jerarquía de órbita (Ω/i/ω) y se anima con el mismo Kepler solver
//   que los planetas (via updateOrbits).
// - Si en un sistema N-ario ninguna estrella tiene órbita definida, se mantiene
//   el fallback legacy: separación en círculo + rotación simple.

export function buildStars({ scene, systemNodes, GALAXY, lights, labelsApi, starMeshById, kmPerUnitLocal = 1e6 }) {
  if (!scene || !Array.isArray(systemNodes)) throw new Error('[stars] scene/systemNodes required');
  if (!starMeshById) starMeshById = new Map();
  starMeshById.clear();

  const byName = new Map();
  for (const it of systemNodes) byName.set(it.name, it);

  const starsBySystem = new Map();
  for (const [sid, sdef] of Object.entries(GALAXY?.star || {})) {
    if (!sdef) continue;
    const sysId = sdef.orbits;
    if (!sysId) continue;
    if (!starsBySystem.has(sysId)) starsBySystem.set(sysId, []);
    starsBySystem.get(sysId).push({ id: sid, def: sdef });
  }

  // Escala realista dentro del sistema: tamaño (km) -> unidades de escena
  const kmPerUnit = (Number(kmPerUnitLocal) > 0) ? Number(kmPerUnitLocal) : 1e6;
  const KM_TO_UNITS = 1 / kmPerUnit;

  const DEG = Math.PI / 180;
  const TAU = Math.PI * 2;

  const binaryGroups = [];
  const starSystems = []; // reutiliza updateOrbits() (estructura { planets:[{orbit, planet}] })

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function color3FromHex(hex) {
    if (typeof hex !== 'number') return null;
    return BABYLON.Color3.FromInts((hex >> 16) & 255, (hex >> 8) & 255, hex & 255);
  }
  function emissiveFromDef(def) {
    if (def?.emissive && def.emissive.r !== undefined) return def.emissive;
    const c = color3FromHex(def?.color);
    return c ? c.scale(1.1) : new BABYLON.Color3(1, 1, 1);
  }

  function getOrbitDirFromDef(def) {
    const p = Number(def?.orbitalPeriod);
    if (Number.isFinite(p) && p < 0) return -1;
    if (def?.retrogradeOrbit === true) return -1;
    if (def?.orbitDirection === -1) return -1;
    return 1;
  }

  function getSpinDirFromDef(def) {
    const rp = Number(def?.rotationPeriod);
    if (Number.isFinite(rp) && rp < 0) return -1;
    const tilt = Number(def?.axialTilt);
    if (Number.isFinite(tilt) && tilt > 90) return -1;
    if (def?.retrogradeSpin === true) return -1;
    if (def?.spinDirection === -1) return -1;
    return 1;
  }

  function meanFromLastPerihelion(def, nAbs) {
    const s = def?.lastPerihelion;
    if (!s || !nAbs) return 0;
    const t0 = Date.parse(s);
    if (Number.isNaN(t0)) return 0;
    const daysSince = (Date.now() - t0) / 86400000;
    return (daysSince * nAbs);
  }

  function hasOrbit(def) {
    // Consideramos “órbita definida” si hay periodo y distancia (peri o apo) o si forceOrbit=true
    if (def?.forceOrbit === true) return true;
    const peri = Math.max(0, Number(def?.periapsis || 0));
    const apo  = Math.max(0, Number(def?.apoapsis || 0));
    const pAbs = Math.abs(Number(def?.orbitalPeriod || 0));
    return (pAbs > 0 && (peri > 0 || apo > 0));
  }

  function createOrbitNodes({ systemName, parentMesh, bodyId, def }) {
    // Orientación orbital: Ω (Y), i (X), ω (Y dentro del plano)
    const lonAsc = Number(def?.longitudeOfAscendingNode || 0) * DEG;
    const inc    = Number(def?.inclination || 0) * DEG;
    const argPeri= Number(def?.argumentOfPeriapsis || 0) * DEG;

    const orbitPlane = new BABYLON.TransformNode(`orbPlane_${systemName}_${bodyId}`, scene);
    orbitPlane.parent = parentMesh;
    orbitPlane.rotation.y = lonAsc;
    orbitPlane.rotation.x = inc;

    const orbitArg = new BABYLON.TransformNode(`orb_${systemName}_${bodyId}`, scene);
    orbitArg.parent = orbitPlane;
    orbitArg.rotation.y = argPeri;

    return { orbitPlane, orbitArg };
  }

  function initOrbit(orbitNode, def) {
    const peri = Math.max(0, Number(def?.periapsis || 0));
    const apo  = Math.max(0, Number(def?.apoapsis || 0));
    const aKm  = (peri + apo) * 0.5;
    const denom = (peri + apo);
    const e = (denom > 0) ? clamp((apo - peri) / denom, 0, 0.999999) : 0;

    // Distancias peri/apo en km (respecto al padre)
    const aU = Math.max(0.001, (aKm > 0 ? aKm : Math.max(peri, apo, 1)) * KM_TO_UNITS);

    const orbitDir = getOrbitDirFromDef(def);
    const pAbs = Math.abs(Number(def?.orbitalPeriod || 0));
    const nAbs = (pAbs > 0) ? (TAU / pAbs) : 0;

    const Mnow = meanFromLastPerihelion(def, nAbs);

    orbitNode.metadata = Object.assign({}, orbitNode.metadata, {
      aU, e,
      mean: orbitDir * Mnow,
      n: nAbs,
      dir: orbitDir,
    });
  }

  // Mini Kepler solver solo para “poner” la posición inicial
  function normAngle(a) {
    a = a % TAU;
    if (a < 0) a += TAU;
    return a;
  }
  function solveKeplerE(M, e) {
    M = normAngle(M);
    e = Math.max(0, Math.min(0.999999, e || 0));
    let E = (e < 0.8) ? M : Math.PI;
    for (let i = 0; i < 8; i++) {
      const f = E - e * Math.sin(E) - M;
      const fp = 1 - e * Math.cos(E);
      E = E - f / Math.max(1e-8, fp);
    }
    return E;
  }
  function placeNow(orbitNode, bodyMesh) {
    const md = orbitNode?.metadata;
    if (!md) return;
    const a = Number(md.aU);
    const e = Number(md.e);
    const M = Number(md.mean);
    if (!Number.isFinite(a) || !Number.isFinite(e) || !Number.isFinite(M)) return;

    const E = solveKeplerE(M, e);
    const cosE = Math.cos(E);
    const r = a * (1 - e * cosE);

    const sq1pe = Math.sqrt(1 + e);
    const sq1me = Math.sqrt(1 - e);
    const nu = 2 * Math.atan2(sq1pe * Math.sin(E * 0.5), sq1me * Math.cos(E * 0.5));

    const x = r * Math.cos(nu);
    const z = r * Math.sin(nu);

    if (bodyMesh) bodyMesh.position.set(x, 0, z);
    else orbitNode.position.set(x, 0, z);
  }

  function initSpin(mesh, def) {
    const spinDir = getSpinDirFromDef(def);
    const rpAbs = Math.abs(Number(def?.rotationPeriod || 0));
    const spinAbs = (rpAbs > 0) ? (TAU / rpAbs) : 0;

    // eje base
    const ra = def?.rotationAxis;
    let axis = (ra && Number.isFinite(ra.x) && Number.isFinite(ra.y) && Number.isFinite(ra.z))
      ? new BABYLON.Vector3(ra.x, ra.y, ra.z)
      : new BABYLON.Vector3(0, 1, 0);
    if (axis.lengthSquared() < 1e-9) axis.set(0, 1, 0);
    axis.normalize();

    const tilt = Number(def?.axialTilt || 0) * DEG;
    if (tilt) {
      const q = BABYLON.Quaternion.RotationAxis(BABYLON.Axis.Z, tilt);
      const m = new BABYLON.Matrix();
      if (typeof BABYLON.Matrix.FromQuaternionToRef === 'function') {
        BABYLON.Matrix.FromQuaternionToRef(q, m);
      } else if (typeof q.toRotationMatrix === 'function') {
        q.toRotationMatrix(m);
      } else {
        BABYLON.Matrix.RotationYawPitchRollToRef(0, 0, tilt, m);
      }
      axis = BABYLON.Vector3.TransformNormal(axis, m);
      if (axis.lengthSquared() < 1e-9) axis.set(0, 1, 0);
      axis.normalize();
    }

    if (spinAbs > 0) {
      mesh.metadata = Object.assign({}, mesh.metadata, {
        spin: spinDir * spinAbs,
        spinAxis: axis,
      });
    }
  }

  for (const [sysId, list] of starsBySystem.entries()) {
    const it = byName.get(sysId);
    if (!it) continue;

    list.sort((a, b) => String(a.id).localeCompare(String(b.id)));
    const total = list.length;

    // ¿Hay alguna estrella con órbita kepleriana definida?
    const anyOrbit = list.some(x => hasOrbit(x.def));

    // Fallback legacy: para sistemas sin datos orbitales (deja el comportamiento anterior)
    const radiiUnits = list.map(x => (x.def?.size || 696340) * KM_TO_UNITS);
    const baseSep = Math.max(2.0, (radiiUnits.reduce((s, v) => s + v, 0) / Math.max(1, total)) * 6);

    it.stars.length = 0;
    it.primaryStar = null;

    // Elegimos primary como la estrella de mayor tamaño (siempre útil para UI/anchors)
    let primaryCandidate = null;
    let bestSize = -Infinity;
    for (const s of list) {
      const sz = Number(s.def?.size || 0);
      if (Number.isFinite(sz) && sz > bestSize) { bestSize = sz; primaryCandidate = s.id; }
    }

    // Si vamos a animar órbitas, creamos un “contenedor” de sistema para updateOrbits
    const sysBucket = anyOrbit ? { systemName: sysId, planets: [] } : null;

    for (let i = 0; i < total; i++) {
      const starId = list[i].id;
      const sdef = list[i].def;

      const rU = (sdef?.size || 696340) * KM_TO_UNITS;
      const diam = rU * 2;

      const starMesh = BABYLON.MeshBuilder.CreateSphere(`star_${sysId}_${starId}`, { diameter: diam, segments: 18 }, scene);
      starMesh.isPickable = false;
      starMesh.renderingGroupId = 2;
      starMesh.metadata = Object.assign({}, starMesh.metadata, { kmPerUnit: kmPerUnitLocal, systemName: sysId, bodyId: starId, kind: 'star' });

      const smat = new BABYLON.StandardMaterial(`starMat_${sysId}_${starId}`, scene);
      smat.disableLighting = true;
      smat.emissiveColor = emissiveFromDef(sdef);
      const base = color3FromHex(sdef?.color) || smat.emissiveColor;
      smat.diffuseColor = base.scale(0.15);
      smat.specularColor = new BABYLON.Color3(0, 0, 0);
      starMesh.material = smat;

      // Parent / posición: depende de si hay órbitas o fallback
      if (anyOrbit && hasOrbit(sdef)) {
        const { orbitPlane, orbitArg } = createOrbitNodes({ systemName: sysId, parentMesh: it.system, bodyId: starId, def: sdef });
        starMesh.parent = orbitArg;
        starMesh.position.set(0, 0, 0);

        initOrbit(orbitArg, sdef);
        placeNow(orbitArg, starMesh);
        initSpin(starMesh, sdef);

        // reutiliza updateOrbits: { orbit, planet }
        if (sysBucket) sysBucket.planets.push({ orbit: orbitArg, planet: starMesh, satellites: [], moons: [] });

        // guardamos también en metadata por si lo necesitas
        starMesh.metadata.orbitPlane = orbitPlane;
        starMesh.metadata.orbitNode = orbitArg;
      } else {
        // Sin órbita: queda anclada al centro del sistema (o fallback separando si no hay órbitas definidas)
        starMesh.parent = it.system;
        if (!anyOrbit) {
          if (total === 1) {
            starMesh.position.set(0, 0, 0);
          } else {
            const ang = (TAU) * (i / total);
            starMesh.position.set(Math.cos(ang) * baseSep, 0, Math.sin(ang) * baseSep);
          }
        } else {
          starMesh.position.set(0, 0, 0);
        }
        initSpin(starMesh, sdef);
      }

      try {
        lights?.registerStar?.({ systemId: sysId, starMesh, systemRoot: it.system, intensity: 7.5, range: 25000 });
      } catch (_) {}

      if (labelsApi?.registerLabel) labelsApi.registerLabel(`star:${sysId}:${starId}`, String(starId), 'star', starMesh, { system: sysId });

      it.stars.push(starMesh);
      starMeshById.set(starId, starMesh);

      if (!it.primaryStar) it.primaryStar = starMesh;
      if (primaryCandidate && starId === primaryCandidate) it.primaryStar = starMesh;
    }

    // Si no hay órbitas keplerianas, mantenemos el “spin” visual legacy para binarios/trinarios
    if (!anyOrbit && it.stars.length > 1) binaryGroups.push({ stars: it.stars.slice(), omega: 0.06 });
    if (sysBucket && sysBucket.planets.length > 0) starSystems.push(sysBucket);
  }

  function updateBinaries(dtSec) {
    if (!dtSec) return;
    for (const g of binaryGroups) {
      const rot = g.omega * dtSec;
      const c = Math.cos(rot), s = Math.sin(rot);
      for (const starMesh of g.stars) {
        const x = starMesh.position.x, z = starMesh.position.z;
        starMesh.position.x = x * c - z * s;
        starMesh.position.z = x * s + z * c;
      }
    }
  }

  return { updateBinaries, starSystems };
}
