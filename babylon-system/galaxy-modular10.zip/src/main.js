import { bootstrap } from './scene/createScene.js';
bootstrap();
