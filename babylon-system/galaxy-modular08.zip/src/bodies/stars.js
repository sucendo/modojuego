// bodies/stars.js
// Crea estrellas y registra luces por sistema.

export function buildStars({ scene, systemNodes, GALAXY, lights, labelsApi, starMeshById, kmPerUnitLocal = 1e6 }) {
  if (!scene || !Array.isArray(systemNodes)) throw new Error('[stars] scene/systemNodes required');
  if (!starMeshById) starMeshById = new Map();
  starMeshById.clear();

  const byName = new Map();
  for (const it of systemNodes) byName.set(it.name, it);

  const starsBySystem = new Map();
  for (const [sid, sdef] of Object.entries(GALAXY?.star || {})) {
    if (!sdef) continue;
    const sysId = sdef.orbits;
    if (!sysId) continue;
    if (!starsBySystem.has(sysId)) starsBySystem.set(sysId, []);
    starsBySystem.get(sysId).push({ id: sid, def: sdef });
  }

  // Escala realista dentro del sistema: tamaño (km) -> unidades de escena
  const kmPerUnit = (Number(kmPerUnitLocal) > 0) ? Number(kmPerUnitLocal) : 1e6;
  const KM_TO_UNITS = 1 / kmPerUnit;
  const binaryGroups = [];

  function color3FromHex(hex) {
    if (typeof hex !== 'number') return null;
    return BABYLON.Color3.FromInts((hex >> 16) & 255, (hex >> 8) & 255, hex & 255);
  }
  function emissiveFromDef(def) {
    if (def?.emissive && def.emissive.r !== undefined) return def.emissive;
    const c = color3FromHex(def?.color);
    return c ? c.scale(1.1) : new BABYLON.Color3(1, 1, 1);
  }

  for (const [sysId, list] of starsBySystem.entries()) {
    const it = byName.get(sysId);
    if (!it) continue;

    list.sort((a, b) => String(a.id).localeCompare(String(b.id)));
    const total = list.length;

    const radiiUnits = list.map(x => (x.def?.size || 696340) * KM_TO_UNITS);
    const baseSep = Math.max(2.0, (radiiUnits.reduce((s, v) => s + v, 0) / Math.max(1, total)) * 6);

    it.stars.length = 0;
    it.primaryStar = null;

    for (let i = 0; i < total; i++) {
      const starId = list[i].id;
      const sdef = list[i].def;

      const rU = (sdef?.size || 696340) * KM_TO_UNITS;
      const diam = rU * 2;

      const starMesh = BABYLON.MeshBuilder.CreateSphere(`star_${sysId}_${starId}`, { diameter: diam, segments: 18 }, scene);
      starMesh.parent = it.system;
      starMesh.isPickable = false;
      starMesh.renderingGroupId = 2;
      starMesh.metadata = Object.assign({}, starMesh.metadata, { kmPerUnit: kmPerUnitLocal });

      const smat = new BABYLON.StandardMaterial(`starMat_${sysId}_${starId}`, scene);
      smat.disableLighting = true;
      smat.emissiveColor = emissiveFromDef(sdef);
      const base = color3FromHex(sdef?.color) || smat.emissiveColor;
      smat.diffuseColor = base.scale(0.15);
      smat.specularColor = new BABYLON.Color3(0, 0, 0);
      starMesh.material = smat;

      try {
        lights?.registerStar?.({ systemId: sysId, starMesh, systemRoot: it.system, intensity: 7.5, range: 25000 });
      } catch (_) {}

      if (total === 1) {
        starMesh.position.set(0, 0, 0);
      } else {
        const ang = (Math.PI * 2) * (i / total);
        starMesh.position.set(Math.cos(ang) * baseSep, 0, Math.sin(ang) * baseSep);
      }

      if (labelsApi?.registerLabel) labelsApi.registerLabel(`star:${sysId}:${starId}`, String(starId), 'star', starMesh, { system: sysId });

      it.stars.push(starMesh);
      starMeshById.set(starId, starMesh);
      if (!it.primaryStar) it.primaryStar = starMesh;
    }

    if (it.stars.length > 1) binaryGroups.push({ stars: it.stars.slice(), omega: 0.06 });
  }

  function updateBinaries(dtSec) {
    if (!dtSec) return;
    for (const g of binaryGroups) {
      const rot = g.omega * dtSec;
      const c = Math.cos(rot), s = Math.sin(rot);
      for (const starMesh of g.stars) {
        const x = starMesh.position.x, z = starMesh.position.z;
        starMesh.position.x = x * c - z * s;
        starMesh.position.z = x * s + z * c;
      }
    }
  }

  return { updateBinaries };
}