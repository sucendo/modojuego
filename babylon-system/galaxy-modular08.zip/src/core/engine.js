export function createEngine(canvas){
  const engine = new BABYLON.Engine(canvas, true, {
    preserveDrawingBuffer: true,
    stencil: true
  });

  // Improve depth precision dramatically for huge scenes
  engine.useReverseDepthBuffer = true;
  return engine;
}