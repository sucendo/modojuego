export function setupCamera(scene, canvas, opts = {}) {
  const camera = new BABYLON.UniversalCamera(
    "cam",
    new BABYLON.Vector3(0, 3, -18),
    scene
  );
  camera.attachControl(canvas, true);

  const BASE_SPEED = Number.isFinite(opts.baseSpeed) ? opts.baseSpeed : 100.0;
  const FAST_MULT = Number.isFinite(opts.fastMult) ? opts.fastMult : 20.0;

  camera.speed = BASE_SPEED;

  // ============================================================
  // Camera Modes
  //  - "mouse": como hasta ahora (ratón apunta + WASD/Space/Ctrl + Shift turbo)
  //  - "ship": tipo nave (W/S pitch, A/D roll, Q/E yaw, 0-9 velocidades)
  // ============================================================
  const state = {
    mode: "mouse",
    isFast: false,
    ship: {
      unitsPerLy: Number.isFinite(opts.unitsPerLy) ? opts.unitsPerLy : 1_000_000,
      speedLevel: 0,
      targetSpeedUps: 0,   // units per second
      currentSpeedUps: 0,  // units per second
      rotRate: Number.isFinite(opts.shipRotRate) ? opts.shipRotRate : 1.35, // rad/s
      accelK: Number.isFinite(opts.shipAccelK) ? opts.shipAccelK : 3.0      // smoothing constant
    }
  };

  const keysDown = new Set();

  const LY_KM = 9.4607304725808e12; // km in 1 ly
  const SECONDS_PER_YEAR = 365.25 * 86400;

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function _shipSpeedForLevel(level) {
    const uPerLy = Math.max(1, state.ship.unitsPerLy);

    // level 0: stop
    if (level <= 0) return 0;

    // level 1: speed of sound (~343 m/s)
    if (level === 1) {
      const soundKmS = 0.343;
      const lyPerSec = soundKmS / LY_KM;
      return lyPerSec * uPerLy;
    }

    // level 2: speed of light (1 ly / year by definition)
    const v2 = uPerLy / SECONDS_PER_YEAR;

    // level 9: 1 ly / hour
    const v9 = uPerLy / 3600;

    if (level === 2) return v2;
    if (level >= 9) return v9;

    // levels 3..8: progresión geométrica entre c y (1 ly/h)
    const steps = 7; // 2->9
    const ratio = v9 / Math.max(1e-12, v2);
    const f = Math.pow(ratio, 1 / steps);
    return v2 * Math.pow(f, level - 2);
  }

  function setUnitsPerLy(unitsPerLy) {
    if (Number.isFinite(unitsPerLy) && unitsPerLy > 0) {
      state.ship.unitsPerLy = unitsPerLy;
      setSpeedLevel(state.ship.speedLevel);
    }
  }

  function setSpeedLevel(level) {
    level = clamp(Math.floor(level), 0, 9);
    state.ship.speedLevel = level;
    state.ship.targetSpeedUps = _shipSpeedForLevel(level);
  }

  function _ensureQuatFromEuler() {
    if (camera.rotationQuaternion) return;
    camera.rotationQuaternion = BABYLON.Quaternion.RotationYawPitchRoll(
      camera.rotation.y,
      camera.rotation.x,
      camera.rotation.z
    );
    camera.rotation.set(0, 0, 0);
  }

  function _ensureEulerFromQuat() {
    if (!camera.rotationQuaternion) return;
    const e = camera.rotationQuaternion.toEulerAngles();
    camera.rotation.copyFrom(e);
    camera.rotationQuaternion = null;
  }

  function setMode(mode) {
    mode = (mode === "ship") ? "ship" : "mouse";
    if (mode === state.mode) return;

    if (mode === "ship") {
      // Si estabas en pointer lock (modo ratón), salimos al pasar a nave
      try { document.exitPointerLock?.(); } catch(e) {}
      // pasa a control tipo nave (sin inputs de Babylon)
      camera.detachControl();
      _ensureQuatFromEuler();
      camera.speed = 0;
      setSpeedLevel(state.ship.speedLevel || 0);
    } else {
      // vuelve al modo clásico (inputs de Babylon)
      _ensureEulerFromQuat();
      camera.attachControl(canvas, true);
    }

    state.mode = mode;
    _syncUi();
  }

  function getMode() { return state.mode; }
  function getSpeedLevel() { return state.ship.speedLevel; }

  // Keyboard handling (global)
  function _shouldIgnoreKey(ev) {
    const t = ev?.target;
    const tag = t?.tagName ? String(t.tagName).toUpperCase() : "";
    return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || ev?.metaKey || ev?.ctrlKey || ev?.altKey;
  }

  function _onKeyDown(ev) {
    if (!ev || _shouldIgnoreKey(ev)) return;

    const code = ev.code || "";
    const key = (ev.key || "").toLowerCase();
    keysDown.add(code);

    // M / K para cambiar de modo
    if (key === "m") {
      ev.preventDefault?.();
      setMode("mouse");
      return;
    }
    if (key === "k") {
      ev.preventDefault?.();
      setMode("ship");
      return;
    }

    // Shift turbo (solo modo mouse)
    if (ev.key === "Shift") state.isFast = true;

    // Velocidad 0..9 (solo modo ship)
    if (state.mode === "ship" && key.length === 1 && key >= "0" && key <= "9") {
      ev.preventDefault?.();
      setSpeedLevel(parseInt(key, 10));
      return;
    }

    // Evita scroll/acciones por defecto en teclas de vuelo
    if (state.mode === "ship" && ["KeyW","KeyS","KeyA","KeyD","KeyQ","KeyE"].includes(code)) {
      ev.preventDefault?.();
    }
  }

  function _onKeyUp(ev) {
    if (!ev || _shouldIgnoreKey(ev)) return;
    const code = ev.code || "";
    keysDown.delete(code);
    if (ev.key === "Shift") state.isFast = false;
  }

  window.addEventListener("keydown", _onKeyDown, { passive: false });
  window.addEventListener("keyup", _onKeyUp, { passive: false });

  // Pointer lock SOLO en modo mouse
  function _onPointerDown() {
    if (state.mode === "mouse") canvas.requestPointerLock?.();
  }
  canvas.addEventListener("pointerdown", _onPointerDown);

  // Cleanup si la escena se reconstruye
  scene.onDisposeObservable?.add(() => {
    window.removeEventListener("keydown", _onKeyDown);
    window.removeEventListener("keyup", _onKeyUp);
    canvas.removeEventListener("pointerdown", _onPointerDown);
  });

  function update(dtSec) {
    dtSec = Number(dtSec) || 0;
    if (dtSec <= 0) return;

    if (state.mode === "mouse") {
      camera.speed = BASE_SPEED * (state.isFast ? FAST_MULT : 1.0);
      return;
    }

    // ===== Ship mode =====
    camera.speed = 0;
    _ensureQuatFromEuler();

    const q = camera.rotationQuaternion || BABYLON.Quaternion.Identity();
    const rr = state.ship.rotRate;

    // W/S -> pitch, Q/E -> yaw, A/D -> roll
    const dpitch = (keysDown.has("KeyW") ? -1 : 0) + (keysDown.has("KeyS") ? 1 : 0);
    const dyaw   = (keysDown.has("KeyQ") ? -1 : 0) + (keysDown.has("KeyE") ? 1 : 0);
    const droll  = (keysDown.has("KeyA") ? -1 : 0) + (keysDown.has("KeyD") ? 1 : 0);

    if (dpitch) {
      const dq = BABYLON.Quaternion.RotationAxis(BABYLON.Axis.X, dpitch * rr * dtSec);
      camera.rotationQuaternion = q.multiply(dq);
    }
    if (dyaw) {
      const dq = BABYLON.Quaternion.RotationAxis(BABYLON.Axis.Y, dyaw * rr * dtSec);
      camera.rotationQuaternion = (camera.rotationQuaternion || q).multiply(dq);
    }
    if (droll) {
      const dq = BABYLON.Quaternion.RotationAxis(BABYLON.Axis.Z, droll * rr * dtSec);
      camera.rotationQuaternion = (camera.rotationQuaternion || q).multiply(dq);
    }
    if (camera.rotationQuaternion) camera.rotationQuaternion.normalize();

    // Smooth speed towards target
    const cur = state.ship.currentSpeedUps;
    const tgt = state.ship.targetSpeedUps;
    const alpha = 1 - Math.exp(-state.ship.accelK * dtSec);
    state.ship.currentSpeedUps = cur + (tgt - cur) * alpha;

    const v = state.ship.currentSpeedUps;
    if (Math.abs(v) > 1e-12) {
      const fwd = camera.getDirection(BABYLON.Axis.Z);
      camera.position.addInPlace(fwd.scale(v * dtSec));
    }

    _syncUi();
  }

  // ===== UI (botones) =====
  let ui = null;

  function _ensureUi() {
    if (opts.enableModeUI === false) return;
    if (typeof document === "undefined") return;

    const existing = document.getElementById("camModePanel");
    if (existing) {
      ui = {
        panel: existing,
        btnMouse: document.getElementById("camModeMouse"),
        btnShip: document.getElementById("camModeShip"),
        speed: document.getElementById("camModeSpeed")
      };
      return;
    }

    const panel = document.createElement("div");
    panel.id = "camModePanel";
    panel.style.position = "fixed";
    panel.style.right = "12px";
    panel.style.bottom = "12px";
    panel.style.zIndex = "9999";
    panel.style.display = "flex";
    panel.style.flexDirection = "column";
    panel.style.gap = "6px";
    panel.style.padding = "8px";
    panel.style.background = "rgba(0,0,0,0.35)";
    panel.style.border = "1px solid rgba(255,255,255,0.15)";
    panel.style.borderRadius = "10px";
    panel.style.backdropFilter = "blur(6px)";
    panel.style.fontFamily = "system-ui, Arial";
    panel.style.userSelect = "none";

    const btnMouse = document.createElement("button");
    btnMouse.id = "camModeMouse";
    btnMouse.textContent = "M · modo ratón";
    btnMouse.style.padding = "6px 10px";
    btnMouse.style.cursor = "pointer";

    const btnShip = document.createElement("button");
    btnShip.id = "camModeShip";
    btnShip.textContent = "K · modo nave";
    btnShip.style.padding = "6px 10px";
    btnShip.style.cursor = "pointer";

    const speed = document.createElement("div");
    speed.id = "camModeSpeed";
    speed.textContent = "Velocidad: 0";
    speed.style.fontSize = "12px";
    speed.style.opacity = "0.95";

    btnMouse.onclick = () => setMode("mouse");
    btnShip.onclick = () => setMode("ship");

    panel.appendChild(btnMouse);
    panel.appendChild(btnShip);
    panel.appendChild(speed);
    document.body.appendChild(panel);

    ui = { panel, btnMouse, btnShip, speed };
    _syncUi();
  }

  function _syncUi() {
    if (!ui) return;
    const isMouse = state.mode === "mouse";
    ui.btnMouse.style.opacity = isMouse ? "1.0" : "0.6";
    ui.btnShip.style.opacity = isMouse ? "0.6" : "1.0";
    ui.btnMouse.style.outline = isMouse ? "2px solid rgba(255,255,255,0.35)" : "none";
    ui.btnShip.style.outline = (!isMouse) ? "2px solid rgba(255,255,255,0.35)" : "none";
    ui.speed.textContent = `Velocidad: ${state.ship.speedLevel}  (${state.mode === "ship" ? "nave" : "ratón"})`;
  }

  _ensureUi();

  const controller = {
    setMode,
    getMode,
    update,
    setSpeedLevel,
    getSpeedLevel,
    setUnitsPerLy,
    _state: state
  };

  return { camera, BASE_SPEED, FAST_MULT, controller };
}