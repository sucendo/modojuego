import { SYSTEMS } from '../data/systems.js';
import { GALAXY } from '../data/galaxy.js';
import { createEngine } from '../core/engine.js';
import { createFloatingOrigin } from '../core/floatingOrigin.js';
import { initHudToggles } from '../ui/hudToggles.js';
import { setupLights } from './lights.js';
import { setupCamera } from './camera.js';
import { createLabels } from '../ui/labels.js';

export function bootstrap() {
    const canvas = document.getElementById("renderCanvas");
    const engine = createEngine(canvas);

    const scene = new BABYLON.Scene(engine);

    // ============================================================
    // Fondo negro garantizado (evita tintes/transparentes raros)
    // ============================================================
    scene.autoClear = true;
    scene.autoClearDepthAndStencil = true;
    scene.clearColor = new BABYLON.Color4(0, 0, 0, 1);
    scene.environmentTexture = null;
    // Por si el canvas quedase con alpha (o CSS raro)
    try { engine.getRenderingCanvas().style.background = "#000"; } catch(e) {}
	
    // ============================================================
    // ROOT del mundo (todo lo "espacial" cuelga de aquí)
    // IMPORTANTÍSIMO: debe existir antes de crear nodos/sistemas/planetas
    // ============================================================
    const worldRoot = new BABYLON.TransformNode("worldRoot", scene);
	
    // ============================================================
    // Registries / índices compartidos entre builders
    // (deben existir antes de buildStarsForSystems/buildPlanets...)
    // ============================================================
    const starMeshById = new Map();   // starId -> Mesh
    const planetMeshById = new Map(); // planetId -> Mesh
    const planetSystems = [];         // { star, orbitNodes:[], planets:[] }
 
    // ============================================================
    // Lights + Camera (modulares)
    // ============================================================
    setupLights(scene);
    const camCfg = setupCamera(scene, canvas);
    const camera = camCfg.camera;
    const BASE_SPEED = camCfg.BASE_SPEED;
    const FAST_MULT = 1000.0; // override para tu modo rápido (antes tenías 1000) 
    let isFast = false;
	
	// ============================================================
	// Labels API (módulo)
	// ============================================================
	const labelsApi = createLabels({ scene, camera, engine });

    window.addEventListener("keydown", (e) => {
      if (e.key === "Shift") isFast = true;
    });
    window.addEventListener("keyup", (e) => {
      if (e.key === "Shift") isFast = false;
    });

    // Ajustes que antes estaban en el bloque inline de cámara
    camera.position.set(2, 50, -540);
    camera.angularSensibility = 3500;
    camera.inertia = 0.0;
    camera.angularInertia = 0.0; // avoid "shake" when rebasing
    camera.angularSensibility = 3500;
    camera.inertia = 0.0;
    camera.angularInertia = 0.0; // avoid "shake" when rebasing
    camera.keysUp = [87];      // W
    camera.keysDown = [83];    // S
    camera.keysLeft = [65];    // A
    camera.keysRight = [68];   // D
    camera.keysUpward = [32];  // Space
    camera.keysDownward = [17];// Ctrl
    camera.minZ = 1.0; // avoid extreme minZ (kills precision)
    camera.maxZ = 5e9; // large view range; reverse depth helps

    // Fondo negro total: sin skybox ni esfera de estrellas de fondo.
    
    // ============================================================
    // GALAXY DATA (inlined from galaxy.js)
    // ============================================================
// galaxyData.js
    // Estructura limpia: systems por un lado, cuerpos por otro (stars/planets/satellites/etc.)
    // Reglas:
    // - star.orbits = systemId
    // - planet.orbits = starId
    // - satellite.orbits = planetId (o moonId si quieres lunas de lunas)
    // - NO existe orbits:"galaxy"
    
    



// ============================================================
    // SYSTEMS: coordenadas fijas en LY (1 LY = __LY unidades de escena)
    // ============================================================
    // (SYSTEMS moved above into GALAXY source-of-truth)
// Crear "estrellas/sistemas" como dots siempre visibles (>= 1px) + una esfera muy pequeña
    const systemNodes = [];
    
    function makeNameLabel(text, parentMesh, yOffset){
      const key = `system:${String(text)}`;
      return labelsApi.registerLabel(key, String(text), "system", parentMesh, { system: text });
    }
	
	function makeSystemNode(name, posWorld){
      // Nodo de sistema (ancla). TODO cuelga de worldRoot => floating origin OK
      const sys = new BABYLON.TransformNode("sys_"+name, scene);
      sys.parent = worldRoot;
      sys.position.copyFrom(posWorld);

      // dot billboard (para verse siempre desde lejos)
      const dot = BABYLON.MeshBuilder.CreatePlane("sysDot_"+name, {width: 1, height: 1}, scene);
      dot.parent = sys;
      dot.position.set(0, 0, 0);
      dot.billboardMode = BABYLON.Mesh.BILLBOARDMODE_ALL;
      dot.isPickable = false;
      dot.renderingGroupId = 1;

      const dmat = new BABYLON.StandardMaterial("sysDotMat_"+name, scene);
      dmat.disableLighting = true;
      dmat.emissiveColor = new BABYLON.Color3(1,1,1);
      dmat.alpha = 1.0;
      dmat.backFaceCulling = false;
      dot.material = dmat;

      // Label de sistema (nivel 0: lejos)
      makeNameLabel(name, dot, 0);

      const it = { system: sys, dot, name, stars: [], primaryStar: null };
      systemNodes.push(it);
      return it;
    }


    function buildStarsForSystems(){
      starMeshById.clear();
      // Index systemNodes by name for quick lookup
      const byName = new Map();
      for (const it of systemNodes) byName.set(it.name, it);

      // group stars by systemId (sdef.orbits)
      const starsBySystem = new Map();
      for (const [sid, sdef] of Object.entries(GALAXY.star || {})){
        if (!sdef) continue;
        const sysId = sdef.orbits;
        if (!sysId) continue;
        if (!starsBySystem.has(sysId)) starsBySystem.set(sysId, []);
        starsBySystem.get(sysId).push({ id: sid, def: sdef });
      }

      // Helpers
      const KM_TO_UNITS_SIZE = 1/50000; // size (km, radio) -> unidades (radio)
      function color3FromHex(hex){
        if (typeof hex !== "number") return null;
        return BABYLON.Color3.FromInts((hex>>16)&255, (hex>>8)&255, hex&255);
      }
      function emissiveFromDef(def){
        // si trae Color3 ya, úsalo; si trae hex, conviértelo; si no, blanco
        if (def.emissive && def.emissive.r !== undefined) return def.emissive;
        const c = color3FromHex(def.color);
        return c ? c.scale(1.1) : new BABYLON.Color3(1,1,1);
      }

      for (const [sysId, list] of starsBySystem.entries()){
        const it = byName.get(sysId);
        if (!it) continue;

        // orden estable: la primera será primaria
        list.sort((a,b)=>String(a.id).localeCompare(String(b.id)));
        const total = list.length;

        // separación local (si no hay datos orbitales)
        const radiiUnits = list.map(x => (x.def.size||696340) * KM_TO_UNITS_SIZE);
        const baseSep = Math.max(2.0, (radiiUnits.reduce((s,v)=>s+v,0) / Math.max(1,total)) * 6);

        for (let i=0;i<total;i++){
          const starId = list[i].id;
          const sdef = list[i].def;

          const rU = (sdef.size||696340) * KM_TO_UNITS_SIZE;
          const diam = rU * 2;

          const starMesh = BABYLON.MeshBuilder.CreateSphere(`star_${sysId}_${starId}`, { diameter: diam, segments: 18 }, scene);
          starMesh.parent = it.system;
          starMesh.isPickable = false;
          starMesh.renderingGroupId = 2;

          // material: estrella auto-iluminada
          const smat = new BABYLON.StandardMaterial(`starMat_${sysId}_${starId}`, scene);
          smat.disableLighting = true;
          smat.emissiveColor = emissiveFromDef(sdef);
          // un toque de color base para que no sea puro blanco
          const base = color3FromHex(sdef.color) || smat.emissiveColor;
          smat.diffuseColor = base.scale(0.15);
          smat.specularColor = new BABYLON.Color3(0,0,0);
          starMesh.material = smat;

          // offset en binarios/trinarios (baricentro en 0,0,0 del sistema)
          if (total === 1){
            starMesh.position.set(0,0,0);
          } else {
            const ang = (Math.PI * 2) * (i/total);
            starMesh.position.set(Math.cos(ang)*baseSep, 0, Math.sin(ang)*baseSep);
          }

          // label de estrella (nivel 1: al acercarse al sistema)
          makeLabel(starId, starMesh, 0, { kind: "star", system: sysId, key: `star:${sysId}:${starId}` });

          it.stars.push(starMesh);
          starMeshById.set(starId, starMesh);
          if (!it.primaryStar) it.primaryStar = starMesh;
        }

        // animación suave de binarios/trinarios (opcional, no física)
        if (it.stars.length > 1){
          const omega = 0.06; // velocidad angular (rad/s) demo
          scene.onBeforeRenderObservable.add(() => {
            const t = scene.getEngine().getDeltaTime() * 0.001;
            const rot = omega * t;
            for (const s of it.stars){
              const x = s.position.x, z = s.position.z;
              s.position.x = x*Math.cos(rot) - z*Math.sin(rot);
              s.position.z = x*Math.sin(rot) + z*Math.cos(rot);
            }
          });
        }
      }
    }

    // ============================================================
    // SYSTEMS: construir desde GALAXY.system (única fuente de verdad)
    // ============================================================

    // Si existe el bloque SYSTEMS antiguo (incluyendo las ~100 estrellas), lo fusionamos
    // solo para preservar las distancias actuales en escena, pero a partir de aquí
    // se renderiza únicamente desde GALAXY.
    (function mergeLegacySystemsIntoGalaxy(){
      try{
        if (typeof SYSTEMS !== "undefined" && SYSTEMS && SYSTEMS.__LY){
          GALAXY.system.__LY = SYSTEMS.__LY;
          for (const k of Object.keys(SYSTEMS)){
            if (k === "__LY") continue;
            if (!SYSTEMS[k] || !SYSTEMS[k].posLY) continue;
            if (!GALAXY.system[k]) GALAXY.system[k] = {};
            // preserva coords actuales (no tocamos distancias entre sistemas)
            GALAXY.system[k].posLY = SYSTEMS[k].posLY.clone ? SYSTEMS[k].posLY.clone() : SYSTEMS[k].posLY;
          }
        } else {
          // fallback razonable: 1 LY = 1e6 unidades (como el demo)
          GALAXY.system.__LY = 1000000;
        }
      }catch(e){ /* noop */ }
    })();

    // Crear nodos de sistema
    for (const k of Object.keys(GALAXY.system)) {
      if (k === "__LY") continue;
      const def = GALAXY.system[k];
      if (!def || !def.posLY) continue;
      const pos = def.posLY.clone().scale(GALAXY.system.__LY);
      makeSystemNode(k, pos);
    }

    // ============================================================
    // STARS: crear estrellas físicas desde GALAXY.star (size = RADIO en km)
    // - puede haber sistemas con 0 estrellas => solo dot/label
    // - puede haber binarios/trinarios => offsets locales alrededor del baricentro
    // ============================================================
    buildStarsForSystems();

    // ============================================================
    // PLANETS: planetas orbitando alrededor de cada estrella/sistema
    // (escala "local" cerca de la estrella; no afecta a las distancias entre sistemas)
    // ============================================================
    // OJO: planetSystems ya está declarado arriba como registry compartido.
    // Si necesitas reiniciarlo al reconstruir, vacíalo:
    planetSystems.length = 0;

    // PRNG determinista por nombre (para que cada estrella tenga siempre el mismo set)
    function hashStr(s){
      let h = 2166136261 >>> 0; // FNV-1a
      for (let i=0; i<s.length; i++){
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 16777619);
      }
      return h >>> 0;
    }
    function mulberry32(a){
      return function(){
        let t = a += 0x6D2B79F5;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      };

    // Merge/extend with GALAXY.system (if provided)
    if (typeof GALAXY === "object" && GALAXY && GALAXY.system) {
      for (const [k,v] of Object.entries(GALAXY.system)) {
        if (k === "__LY") continue;
        if (!SYSTEMS[k]) SYSTEMS[k] = v; // keep original list as-is; just add missing
      }
      if (typeof SYSTEMS.__LY !== "number" && typeof GALAXY.system.__LY === "number") SYSTEMS.__LY = GALAXY.system.__LY;
    }

    }

    function makePlanet(systemName, starMesh, i, rng){
      // órbitas a escala "de demo" (unidades Babylon), no astronómicas:
      const orbitR = 450 + i*380 + Math.floor(rng()*120);     // distancia al astro
      const diameter = 55 + Math.floor(rng()*90);             // tamaño del planeta
      const tilt = (rng()*0.35) - 0.175;                      // inclinación orbital aprox
      const speed = 0.12 + rng()*0.30;                        // rad/s aprox (se ajusta con dt)

      const orbit = new BABYLON.TransformNode(`orb_${systemName}_${i}`, scene);
      orbit.parent = starMesh;
      orbit.position.set(0, 0, 0);
      orbit.rotation.z = tilt;

      const planetName = (systemName === "Al-Lat" && ["Mercurio","Venus","Tierra","Marte","Jupiter","Saturno","Urano","Neptuno","Pluton","Ceres"][i])
        ? ["Mercurio","Venus","Tierra","Marte","Jupiter","Saturno","Urano","Neptuno","Pluton","Ceres"][i]
        : `Planeta ${i+1}`;

      const p = BABYLON.MeshBuilder.CreateSphere(`pl_${systemName}_${i}_${planetName}`, {diameter, segments: 18}, scene);
      p.parent = orbit;
      p.position.set(orbitR, 0, 0);
      p.isPickable = false;

      const mat = new BABYLON.StandardMaterial(`plMat_${systemName}_${i}`, scene);
      // color suave (evitar "neón" para que no compita con el HUD)
      const c = new BABYLON.Color3(0.25 + rng()*0.65, 0.25 + rng()*0.65, 0.25 + rng()*0.65);
      mat.diffuseColor = c;
      mat.emissiveColor = c.scale(0.25);  // un poco visible aunque no haya luz
      mat.specularColor = new BABYLON.Color3(0.08, 0.08, 0.08);
      p.material = mat;
        planetMeshById.set(planetName, p);
      // Nombre del planeta
      makeLabel(planetName, p, 0, { kind: "planet", targetPx: 16, system: systemName, planet: planetName });

      // mini-luna ocasional
      let moon = null;
      let moonOrbit = null;
      if (rng() < 0.35){
        const mR = 110 + Math.floor(rng()*90);
        const mD = 18 + Math.floor(rng()*26);
        const mSpeed = 0.8 + rng()*1.4;

        moonOrbit = new BABYLON.TransformNode(`moonOrb_${systemName}_${i}`, scene);
        moonOrbit.parent = p;
        moonOrbit.position.set(0,0,0);

        moon = BABYLON.MeshBuilder.CreateSphere(`moon_${systemName}_${i}`, {diameter: mD, segments: 14}, scene);
        moon.parent = moonOrbit;
        moon.position.set(mR, 0, 0);
        moon.isPickable = false;

        const mm = new BABYLON.StandardMaterial(`moonMat_${systemName}_${i}`, scene);
        const mc = new BABYLON.Color3(0.55 + rng()*0.35, 0.55 + rng()*0.35, 0.55 + rng()*0.35);
        mm.diffuseColor = mc;
        mm.emissiveColor = mc.scale(0.18);
        mm.specularColor = new BABYLON.Color3(0.05,0.05,0.05);
        moon.material = mm;

        const moonName = `${planetName} I`;
        moonMeshById.set(moonName, moon);
        makeLabel(moonName, moon, 0, { kind: "moon", system: systemName, planet: planetName, key: `moon:${systemName}:${planetName}:${moonName}` });
        moonOrbit.metadata = { speed: mSpeed, spin: (rng()*1.2) };
      }

      orbit.metadata = { speed, spin: (rng()*0.9) + 0.1 };
      p.metadata = { spin: (rng()*1.6) + 0.2 };

      return { orbit, planet: p, moonOrbit, moon };
    }

    function buildPlanetsForSystems(){
      // Mantiene el demo original: para cada "system node" crea planetas.
      // Si existe dataset (GALAXY.planets), lo usa; si no, fallback procedural.
      planetSystems.length = 0;
      planetMeshById.clear();

      const hasGalaxy = (typeof GALAXY === "object" && GALAXY);
      const stars = hasGalaxy && GALAXY.star ? GALAXY.star : {};
      const planets = hasGalaxy && GALAXY.planets ? GALAXY.planets : {};
      const satellites = hasGalaxy && GALAXY.satellites ? GALAXY.satellites : {};

      const starsBySystem = new Map();
      for (const [starId, sdef] of Object.entries(stars)){
        const sys = sdef.orbits;
        if (!sys) continue;
        if (!starsBySystem.has(sys)) starsBySystem.set(sys, []);
        starsBySystem.get(sys).push({ id: starId, def: sdef });
      }

      const planetsByStar = new Map();
      for (const [pid, pdef] of Object.entries(planets)){
        const sid = pdef.orbits;
        if (!sid) continue;
        if (!planetsByStar.has(sid)) planetsByStar.set(sid, []);
        planetsByStar.get(sid).push({ id: pid, def: pdef });
      }

      const satsByPlanet = new Map();
      for (const [mid, mdef] of Object.entries(satellites)){
        const pid = mdef.orbits;
        if (!pid) continue;
        if (!satsByPlanet.has(pid)) satsByPlanet.set(pid, []);
        satsByPlanet.get(pid).push({ id: mid, def: mdef });
      }

      // Escalas (km -> unidades demo)
      const KM_TO_UNITS_ORBIT = 1/1e6;   // 1 unidad = 1 millón de km (órbitas)
      const KM_TO_UNITS_SIZE  = 1/50000; // size (km) -> unidades de radio aprox
      const MIN_PLANET_DIAM   = 0;   // real scale (no clamp)
      const MIN_MOON_DIAM     = 0;     // real scale (no clamp)

      function colorFromDef(c){
        if (typeof c === "number"){
          const hex = "#"+(c>>>0).toString(16).padStart(6,"0");
          return BABYLON.Color3.FromHexString(hex);
        }
        return null;
      }

      function makePlanetFromDef(systemName, starMesh, planetId, pdef){
        const peri = (pdef.periapsis||0);
        const apo  = (pdef.apoapsis||0);
        const aKm  = (peri+apo)*0.5;
        const orbitR = Math.max(0.001, aKm * KM_TO_UNITS_ORBIT);

        const tilt = (pdef.inclination||0) * Math.PI/180;
        const period = (pdef.orbitalPeriod||0);
        const speed = (period > 0) ? (0.35 * (365.25/period)) : 0.18;

        const orbit = new BABYLON.TransformNode(`orb_${systemName}_${planetId}`, scene);
        orbit.parent = starMesh;
        orbit.rotation.z = tilt;

        const radiusUnits = (pdef.size||2500) * KM_TO_UNITS_SIZE; // size ~ radio km
        const d = Math.max(MIN_PLANET_DIAM, radiusUnits*2);
        const p = BABYLON.MeshBuilder.CreateSphere(`pl_${systemName}_${planetId}`, {diameter: d, segments: 18}, scene);
        p.parent = orbit;
        p.position.set(orbitR, 0, 0);
        p.isPickable = false;

        const mat = new BABYLON.StandardMaterial(`plMat_${systemName}_${planetId}`, scene);
        const c = colorFromDef(pdef.color) || new BABYLON.Color3(0.35,0.35,0.35);
        mat.diffuseColor = c;
        mat.emissiveColor = c.scale(0.25);
        mat.specularColor = new BABYLON.Color3(0.08,0.08,0.08);
        p.material = mat;

        // Label pegado al mesh (sigue órbita)
        makeLabel(planetId, p, 0, { kind: "planet", system: systemName, planet: planetId, key: `planet:${systemName}:${planetId}` });

        orbit.metadata = { speed, spin: 0.12 };
        p.metadata = { spin: 0.35 };

        // Lunas dataset
        const moons = satsByPlanet.get(planetId) || [];
        for (const { id: moonId, def: mdef } of moons){
          const mperi = (mdef.periapsis||0), mapo=(mdef.apoapsis||0);
          const maKm = (mperi+mapo)*0.5;
          const mR = Math.max(110, maKm * KM_TO_UNITS_ORBIT);
          const mr = (mdef.size||300) * KM_TO_UNITS_SIZE;
          const mD = Math.max(MIN_MOON_DIAM, mr*2);

          const mOrbit = new BABYLON.TransformNode(`moonOrb_${systemName}_${planetId}_${moonId}`, scene);
          mOrbit.parent = p;
          mOrbit.rotation.z = (mdef.inclination||0) * Math.PI/180;

          const moon = BABYLON.MeshBuilder.CreateSphere(`moon_${systemName}_${planetId}_${moonId}`, {diameter: mD, segments: 14}, scene);
          moon.parent = mOrbit;
          moon.position.set(mR, 0, 0);
          moon.isPickable = false;

          const mm = new BABYLON.StandardMaterial(`moonMat_${systemName}_${planetId}_${moonId}`, scene);
          const mc = colorFromDef(mdef.color) || new BABYLON.Color3(0.7,0.7,0.7);
          mm.diffuseColor = mc;
          mm.emissiveColor = mc.scale(0.18);
          mm.specularColor = new BABYLON.Color3(0.05,0.05,0.05);
          moon.material = mm;

          const mperiod = (mdef.orbitalPeriod||0);
          mOrbit.metadata = { speed: (mperiod>0) ? (1.1 * (30/mperiod)) : 1.0, spin: 0.1 };
          moon.metadata = { spin: 0.45 };
          makeLabel(moonId, moon, 0, { kind: "moon", system: systemName, planet: planetId, key: `moon:${systemName}:${planetId}:${moonId}` });
        }

        return { orbit, planet: p };
      }

      for (const it of systemNodes){
        const sysName = it.name;

        const orbitNodes = [];
        const planetsOut = [];

        // Dataset exists for this system?
        const starList = starsBySystem.get(sysName);

        // Nota: renderizamos SOLO lo que exista en GALAXY (sin fallback procedural).

        if (starList && starList.length){
          for (const st of starList){
            const starMesh = starMeshById.get(st.id) || it.primaryStar;
            if (!starMesh) continue;
            const plist = planetsByStar.get(st.id) || [];
            plist.sort((a,b)=>{
              const aa=((a.def.periapsis||0)+(a.def.apoapsis||0))*0.5;
              const bb=((b.def.periapsis||0)+(b.def.apoapsis||0))*0.5;
              return aa-bb;
            });
            for (const { id: pid, def: pdef } of plist){
              const obj = makePlanetFromDef(sysName, starMesh, pid, pdef);
              orbitNodes.push(obj.orbit);
              planetsOut.push(obj);
            }
          }
        }

        // Si no hay estrellas/planetas definidos para este sistema, no se crea nada.

        planetSystems.push({ star: it.primaryStar, orbitNodes, planets: planetsOut });
        }
    }
    buildPlanetsForSystems();

    // Ajuste tamaño mínimo en pantalla para todos los dots de sistemas
    function updateSystemDotsMinPx(){
      const vh = engine.getRenderHeight(true);
      const fov = (typeof camera.fov === "number") ? camera.fov : 0.8;
      const tanHalf = Math.tan(fov * 0.5);
      const minPx = 2.0; // sistemas: mínimo 2px para distinguirlos

      for (const it of systemNodes) {
        const dot = it.dot;
        if (!dot) continue;
        const wpos = dot.getAbsolutePosition();
        const d = BABYLON.Vector3.Distance(camera.position, wpos);
        const pxPerUnit = (vh / (2 * tanHalf)) / Math.max(1e-6, d);
        const wantUnits = Math.max(1e-4, minPx / Math.max(1e-9, pxPerUnit));
        dot.scaling.setAll(wantUnits);
      }
    }

    // Labels: tamaño constante en pantalla + jerarquía por distancia
    const LABEL_HIDE_MOON_DIST = 2.0e7;    // unidades mundo
    const LABEL_HIDE_PLANET_DIST = 8.0e7;  // unidades mundo

    function updateLabels(){
      const LABEL_PX_SCALE = 0.65; // reduce overall label size
      // LOD thresholds (en unidades del mundo del demo)
      const SHOW_PLANETS_WITHIN = 1.2e8; // al entrar en un sistema (aprox)
      const SHOW_MOONS_WITHIN = 8.0e6;   // al acercarte a un planeta (aprox)
      // Mapa rápido de posiciones de sistema (centro/estrella)
      const systemPosByName = new Map();
      for (const sn of systemNodes) {
        if (sn && sn.name && sn.dot) systemPosByName.set(sn.name, sn.dot.getAbsolutePosition());
      }
      const vh = engine.getRenderHeight(true);
      const fov = (typeof camera.fov === "number") ? camera.fov : 0.8;
      const tanHalf = Math.tan(fov * 0.5);
      const camPos = camera.globalPosition || camera.position;

      for (const it of labelItems){
        if (!it || !it.plane) continue;
        const p = it.plane;
        const wpos = p.getAbsolutePosition();
        const d = BABYLON.Vector3.Distance(camPos, wpos);

        // Jerarquía por distancia (LOD de nombres):
        // - Sistemas: siempre
        // - Planetas: aparecen al acercarte al sistema
        // - Lunas: aparecen al acercarte al planeta (o a la luna)
        let visible = true;

        const kind = it.kind;

        // respeta el toggle
        if (toggleNames && !toggleNames.checked) visible = false;

        // Calcula distancias a nivel "sistema" y "planeta" si aplica
        if (visible && kind === "planet") {
          // distancia cámara -> estrella/sistema (dot del sistema)
          const sysName = it.system;
          if (sysName && systemPosByName.has(sysName)) {
            const sysPos = systemPosByName.get(sysName);
            const dSys = BABYLON.Vector3.Distance(camPos, sysPos);
            // umbral: dentro de este radio empiezan a verse planetas del sistema
            if (dSys > SHOW_PLANETS_WITHIN) visible = false;
          } else {
            // sin info de sistema: fallback por distancia al propio planeta
            if (d > SHOW_PLANETS_WITHIN) visible = false;
          }
        }

        if (visible && kind === "moon") {
          // muestra lunas cuando estás cerca del planeta host
          const pid = it.planet;
          const planetMesh = pid ? planetMeshById.get(pid) : null;
          if (planetMesh) {
            const dp = BABYLON.Vector3.Distance(camPos, planetMesh.getAbsolutePosition());
            if (dp > SHOW_MOONS_WITHIN) visible = false;
          } else {
            // fallback: cerca de la luna
            if (d > SHOW_MOONS_WITHIN) visible = false;
          }
        }

        p.setEnabled(visible);
        if (!visible) continue;

        // mantener tamaño constante en pantalla
        const pxPerUnit = (vh / (2 * tanHalf)) / Math.max(1e-6, d);
        const wantUnits = (it.targetPx * LABEL_PX_SCALE) / Math.max(1e-9, pxPerUnit);

        // límites para evitar tamaños absurdos
        const clamped = Math.min(200.0, Math.max(0.02, wantUnits));
        const s = clamped / (it.baseW || 1.0);
        p.scaling.setAll(s);
      }
    }

    // Plano de referencia: paralelos y meridianos (líneas) cada 1000 unidades
    // "Paralelos" = líneas paralelas al eje X (variando Z)
    // "Meridianos" = líneas paralelas al eje Z (variando X)
    const GRID_STEP = 100000;
    const GRID_EXTENT = 1000000000; // ampliado (cubre de sobra todos los objetos)
    const gridLines = [];

    for (let x = -GRID_EXTENT; x <= GRID_EXTENT; x += GRID_STEP) {
      gridLines.push([new BABYLON.Vector3(x, 0, -GRID_EXTENT), new BABYLON.Vector3(x, 0, GRID_EXTENT)]);
    }
    for (let z = -GRID_EXTENT; z <= GRID_EXTENT; z += GRID_STEP) {
      gridLines.push([new BABYLON.Vector3(-GRID_EXTENT, 0, z), new BABYLON.Vector3(GRID_EXTENT, 0, z)]);
    }

    const grid = BABYLON.MeshBuilder.CreateLineSystem("gridLines", { lines: gridLines }, scene);
    grid.parent = worldRoot;
    grid.isPickable = false;
    grid.color = new BABYLON.Color3(0.45, 1.0, 0.55); // verde claro
    grid.position.y = -0.01;

    const gridLineMat = new BABYLON.StandardMaterial("gridLineMat", scene);
    gridLineMat.disableLighting = true;
    gridLineMat.emissiveColor = new BABYLON.Color3(0.45, 1.0, 0.55); // verde claro
    gridLineMat.alpha = 0.12; // transparencia // más transparente
    grid.material = gridLineMat;

    // Rejilla vertical: plano X-Y en Z=0 (para ver también el eje vertical)
    const gridLinesV = [];
    for (let x = -GRID_EXTENT; x <= GRID_EXTENT; x += GRID_STEP) {
      gridLinesV.push([new BABYLON.Vector3(x, -GRID_EXTENT, 0), new BABYLON.Vector3(x, GRID_EXTENT, 0)]);
    }
    for (let y = -GRID_EXTENT; y <= GRID_EXTENT; y += GRID_STEP) {
      gridLinesV.push([new BABYLON.Vector3(-GRID_EXTENT, y, 0), new BABYLON.Vector3(GRID_EXTENT, y, 0)]);
    }

    const gridV = BABYLON.MeshBuilder.CreateLineSystem("gridLinesV", { lines: gridLinesV }, scene);
    gridV.parent = worldRoot;
    gridV.isPickable = false;
    gridV.color = new BABYLON.Color3(0.45, 0.75, 1.0); // azul claro
    gridV.position.z = 0;

    const gridLineMatV = new BABYLON.StandardMaterial("gridLineMatV", scene);
    gridLineMatV.disableLighting = true;
    gridLineMatV.emissiveColor = new BABYLON.Color3(0.45, 0.75, 1.0); // azul claro
    gridLineMatV.alpha = 0.08; // más transparente que la horizontal
    gridV.material = gridLineMatV;


    // Ejes principales un poco más visibles
    const axes = BABYLON.MeshBuilder.CreateLineSystem("axes", {
      lines: [
        [new BABYLON.Vector3(-GRID_EXTENT, 0, 0), new BABYLON.Vector3(GRID_EXTENT, 0, 0)],
        [new BABYLON.Vector3(0, 0, -GRID_EXTENT), new BABYLON.Vector3(0, 0, GRID_EXTENT)],
      ]
    }, scene);
    axes.parent = worldRoot;
    axes.isPickable = false;
    axes.color = new BABYLON.Color3(0.25, 0.25, 0.30);
    axes.position.y = -0.009;

    const axesLineMat = new BABYLON.StandardMaterial("axesLineMat", scene);
    axesLineMat.disableLighting = true;
    axesLineMat.emissiveColor = new BABYLON.Color3(1,1,1);
    axesLineMat.alpha = 0.16; // un poco más visible que la rejilla
    axes.material = axesLineMat;


    // Mallas de referencia (para el toggle de "Mostrar malla")
    const gridMeshes = [grid, gridV, axes];
    function makeSphere(name, pos, color, diameter){
      const m = BABYLON.MeshBuilder.CreateSphere(name, {diameter, segments: 32}, scene);
      m.parent = worldRoot;
      m.position.copyFrom(pos);
      const mat = new BABYLON.StandardMaterial(name+"Mat", scene);
      mat.diffuseColor = color;
      mat.emissiveColor = color.scale(1.0);
      mat.specularColor = new BABYLON.Color3(0.1,0.1,0.1);
      m.material = mat;
      return m;
    }

    // --- Visibilidad mínima (>= 1px) ---
    // Añadimos un "dot" billboard por esfera y lo escalamos para que nunca baje de 1 píxel.
    function makeMinPxDot(name, parentMesh, color){
      const dot = BABYLON.MeshBuilder.CreatePlane("dot_"+name, {width: 1, height: 1}, scene);
      dot.parent = parentMesh;
      dot.position.set(0, 0, 0);
      dot.billboardMode = BABYLON.Mesh.BILLBOARDMODE_ALL;
      dot.isPickable = false;
      dot.renderingGroupId = 1;

      const m = new BABYLON.StandardMaterial("dotMat_"+name, scene);
      m.disableLighting = true;
      m.emissiveColor = color.clone();
      m.alpha = 1.0;
      m.backFaceCulling = false;
      dot.material = m;
      return dot;
    }


    function makeLabel(text, parentMesh, yOffset, opts){
      const kind = (opts && opts.kind) ? opts.kind : "planet";
      const system = opts && opts.system;
      const planet = opts && opts.planet;
      const key = (opts && opts.key)
        ? String(opts.key)
        : `${kind}:${system||""}:${planet||""}:${String(text)}`;
    return labelsApi.registerLabel(key, String(text), kind, parentMesh, { system, planet });
    }

    // ============================================================
    // Floating Origin (extraído a core/floatingOrigin.js)
    // ============================================================
    const floating = createFloatingOrigin({
      scene,
      camera,
      worldRoot,
      // si quieres forzar defaults:
      // thresh: 20_000,
      // rebaseGrid: 1000,
    });

    // ============================================================
    // HUD toggles (extraído a ui/hudToggles.js)
    // ============================================================
    initHudToggles({
      setShowLabels: labelsApi.setShowLabels,
      // define aquí gridMeshes / grid / axes si existen en tu escena
      getGridMeshes: () => (typeof gridMeshes !== "undefined" ? gridMeshes : null),
      getFallbackGrid: () => ({
        grid: (typeof grid !== "undefined" ? grid : null),
        gridV: (typeof gridV !== "undefined" ? gridV : null),
        axes: (typeof axes !== "undefined" ? axes : null),
      }),
    });

    const elOff = document.getElementById("off");
    const elCam = document.getElementById("cam");
    const elAbs = document.getElementById("abs");
    scene.onBeforeRenderObservable.add(() => {
      camera.speed = BASE_SPEED * (isFast ? FAST_MULT : 1.0);

      floating.apply();

      // Dots + labels
      updateSystemDotsMinPx();
      labelsApi.update(false);

      // Animar órbitas (planetas)
      const dt = engine.getDeltaTime() * 0.001;
      for (const sys of planetSystems){
        for (const obj of sys.planets){
          if (obj.orbit?.metadata?.speed != null){
            obj.orbit.rotation.y += obj.orbit.metadata.speed * dt;
            obj.orbit.rotation.x += (obj.orbit.metadata.spin || 0) * 0.15 * dt;
          }
          if (obj.planet?.metadata?.spin != null){
            obj.planet.rotation.y += obj.planet.metadata.spin * dt;
          }
          if (obj.moonOrbit?.metadata?.speed != null){
            obj.moonOrbit.rotation.y += obj.moonOrbit.metadata.speed * dt;
          }
          if (obj.moon?.metadata?.spin != null){
            obj.moon.rotation.y += obj.moon.metadata.spin * dt;
          }
        }
      }

      // HUD debug floating origin (si existe en el HTML)
      floating.updateHud();

      const abs = floating.getCameraAbsolute();
      const off = floating.originOffset;
      if (elOff) elOff.textContent = `${off.x.toFixed(0)}, ${off.y.toFixed(0)}, ${off.z.toFixed(0)}`;
      if (elCam) elCam.textContent = `${camera.position.x.toFixed(0)}, ${camera.position.y.toFixed(0)}, ${camera.position.z.toFixed(0)}`;
      if (elAbs) elAbs.textContent = `${abs.x.toFixed(0)}, ${abs.y.toFixed(0)}, ${abs.z.toFixed(0)}`;
    });
	
	engine.runRenderLoop(() => scene.render());
    window.addEventListener("resize", () => engine.resize());   
 }
