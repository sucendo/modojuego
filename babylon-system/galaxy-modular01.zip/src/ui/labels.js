// Labels (Elite-like arcs + glow) MOVED OUT of createScene.js
export function createLabels({ scene, camera, engine }){
  const gui = BABYLON.GUI.AdvancedDynamicTexture.CreateFullscreenUI("ui", true, scene);

  // Registry
  const labelsById = new Map(); // key -> { rect, tb, kind, mesh, ... }
  let showLabels = true;

  // ============================================================
  // LABELS (Elite-like HUD): name + distance (AU) + reticle
  // (copiado desde tu createScene.js y encapsulado)
  // ============================================================
  const AU_KM = 149597870.7;
  const UNITS_TO_KM_LOCAL = 1e6; // órbitas: 1 unidad = 1 millón de km
  function formatAU(au){
    if (!isFinite(au)) return "";
    const v = Math.abs(au);
    if (v >= 1000) return au.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",") + " AU";
    if (v >= 100)  return au.toFixed(1) + " AU";
    if (v >= 10)   return au.toFixed(2) + " AU";
    return au.toFixed(3) + " AU";
  }

  function createArcLabelDataURL(text, opts){
    opts = opts || {};
    const texSize   = opts.texSize   || 512;
    const ringColor = opts.ringColor || "#b36a1f";
    const textColor = opts.textColor || "#b36a1f";
    const ringWidth = (opts.ringWidth != null) ? opts.ringWidth : 14;

    // Orbitron 700 (radio font). NOTE: requires <link> in <head>.
    const font = opts.font || '700 66px "Orbitron", system-ui, -apple-system, Segoe UI, Roboto, Arial';

    const arcRadius  = (opts.arcRadius  != null) ? opts.arcRadius  : 210;
    const ringRadius = (opts.ringRadius != null) ? opts.ringRadius : 190;
    const arcSpanDeg = (opts.arcSpanDeg != null) ? opts.arcSpanDeg : 150;
    const yOffset    = (opts.yOffset    != null) ? opts.yOffset    : -40;

    // Glow stack (Elite-like HUD). Multiple passes to emulate CSS multi text-shadow.
    const glowStack = opts.glowStack || [
      { blur: 5,  color: "#00ffcc" },
      { blur: 10, color: "#00ffcc" },
      { blur: 15, color: "#008080" },
      { blur: 20, color: "#008080" },
    ];

    const c = document.createElement("canvas");
    c.width = texSize; c.height = texSize;
    const ctx = c.getContext("2d");
    const cx = texSize/2, cy = texSize/2;

    ctx.clearRect(0,0,texSize,texSize);

    // ring (no shadow)
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0)";
    ctx.beginPath();
    ctx.arc(cx, cy, ringRadius, 0, Math.PI*2);
    ctx.strokeStyle = ringColor;
    ctx.lineWidth = ringWidth;
    ctx.stroke();
    ctx.restore();

    // arc text (letters upright / vertical) with multi-pass glow
    ctx.save();
    ctx.font = font;
    ctx.fillStyle = textColor;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;

    const s = String(text || "").toUpperCase();
    const chars = Array.from(s);

    // Tighter tracking
    const perCharDeg = (opts.perCharDeg != null) ? opts.perCharDeg : 9;
    const span = ((chars.length <= 1) ? 0 : (perCharDeg * (chars.length - 1))) * Math.PI / 180;
    const start = -span/2;
    const step = (chars.length <= 1) ? 0 : (span / (chars.length - 1));

    function drawChar(ch, a){
      ctx.save();
      ctx.translate(cx, cy + yOffset);
      ctx.rotate(a);
      ctx.translate(0, -arcRadius);
      ctx.rotate(-a);
      ctx.fillText(ch, 0, 0);
      ctx.restore();
    }

    for (let i=0;i<chars.length;i++){
      const a = start + i*step;
      for (const g of glowStack){
        ctx.shadowColor = g.color;
        ctx.shadowBlur  = g.blur;
        drawChar(chars[i], a);
      }
      ctx.shadowBlur = 0;
      ctx.shadowColor = "rgba(0,0,0,0)";
      drawChar(chars[i], a);
    }

    // arc span ticks (optional)
    const arcSpan = arcSpanDeg * Math.PI / 180;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.strokeStyle = ringColor;
    ctx.lineWidth = Math.max(2, Math.floor(ringWidth*0.35));
    ctx.beginPath();
    ctx.arc(0, 0, ringRadius, -arcSpan*0.5, arcSpan*0.5);
    ctx.stroke();
    ctx.restore();

    return c.toDataURL("image/png");
  }

  const arcCache = new Map();
  function getArcLabelURL(text, kind){
    const k = `${kind}|${String(text)}`;
    let url = arcCache.get(k);
    if (url) return url;

    // colores (puedes ajustar aquí por kind)
    const ringColor = "#b36a1f";
    const textColor = "#b36a1f";
    url = createArcLabelDataURL(text, {
      ringColor, textColor,
      glowStack: [
        { blur: 5,  color: "#00ffcc" },
        { blur: 10, color: "#00ffcc" },
        { blur: 15, color: "#008080" },
        { blur: 20, color: "#008080" },
      ],
      perCharDeg: 9,
    });
    arcCache.set(k, url);
    return url;
  }

  function createGuiLabel(key, text, targetMesh, kind){
    // rect contenedor
    const rect = new BABYLON.GUI.Rectangle("lbl_" + key);
    rect.thickness = 0;
    rect.background = "rgba(0,0,0,0)";
    rect.isHitTestVisible = false;

    // ring image (arc texture)
    const img = new BABYLON.GUI.Image("img_" + key, getArcLabelURL(text, kind));
    img.stretch = BABYLON.GUI.Image.STRETCH_UNIFORM;
    rect.addControl(img);

    // defaults sizing (se reescalan en updateArcGuiLabelSizes)
    rect._basePx = (kind === "system") ? 160 : 140;
    rect._minPx = (kind === "system") ? 120 : 90;
    rect._maxPx = (kind === "system") ? 320 : 360;
    rect._pxScale = 1.0;

    rect.widthInPixels  = rect._basePx;
    rect.heightInPixels = rect._basePx;

    rect._img = img;

    gui.addControl(rect);
    rect.linkWithMesh(targetMesh);
    rect.linkOffsetY = 0;

    return rect;
  }

  function registerLabel(id, text, kind, mesh, extra){
    if (!mesh) return null;
    let key = String(id || "");
    if (!key) return null;

    // evita colisiones
    if (!key.includes(":")){
      const sys = extra && extra.system ? extra.system : "";
      const pl  = extra && extra.planet ? extra.planet : "";
      key = `${kind}:${sys}:${pl}:${key}`;
    }

    let meta = labelsById.get(key);
    if (!meta){
      const rect = createGuiLabel(key, String(text), mesh, kind);
      meta = { rect, kind, mesh, system: extra && extra.system, planet: extra && extra.planet };
      labelsById.set(key, meta);
    } else {
      meta.kind = kind || meta.kind;
      meta.mesh = mesh || meta.mesh;
      if (meta.rect){
        try { meta.rect.linkWithMesh(meta.mesh); } catch(_){}
        // si cambia texto:
        try { meta.rect._img.source = getArcLabelURL(String(text), meta.kind); } catch(_){}
      }
    }
    return meta.rect;
  }

  function setShowLabels(v){
    showLabels = !!v;
    for (const meta of labelsById.values()){
      if (meta && meta.rect) meta.rect.isVisible = showLabels;
    }
  }

  // fade/tiers (copiado de tu createScene; si lo tenías más avanzado, lo seguimos refinando aquí)
  function updateLabelVisibility(_debug){
    if (!showLabels) return;
    for (const meta of labelsById.values()){
      if (!meta || !meta.rect || !meta.mesh) continue;
      // si tú ya calculabas alpha por distancia/tiers en createScene, déjalo aquí
      meta.rect.isVisible = true;
      meta.rect.alpha = 1;
    }
  }

  function updateArcGuiLabelSizes(){
    if (!showLabels) return;
    if (!camera || !engine) return;
    const vh = engine.getRenderHeight(true);
    const fov = (typeof camera.fov === "number") ? camera.fov : 0.8;
    const tanHalf = Math.tan(fov * 0.5);
    const camPos = camera.globalPosition || camera.position;

    for (const meta of labelsById.values()){
      if (!meta || !meta.rect || !meta.mesh) continue;
      const rect = meta.rect;
      const mesh = meta.mesh;
      const kind = meta.kind || "planet";

      let px = rect._basePx || 140;

      // si hay boundingSphere, ajusta al tamaño aparente
      try{
        const bi = (typeof mesh.getBoundingInfo === "function") ? mesh.getBoundingInfo() : null;
        const bs = bi && bi.boundingSphere ? bi.boundingSphere : null;
        if (bs){
          const r = bs.radiusWorld;
          const wpos = (mesh.getAbsolutePosition ? mesh.getAbsolutePosition() : mesh.position);
          const d = BABYLON.Vector3.Distance(camPos, wpos);
          if (d > 1e-6){
            const projR = (r / (d * tanHalf)) * (vh/2);
            const margin = (kind === "star") ? 28 : 18;
            px = projR * 2 + margin;
          }
        }
      }catch(_){}

      const minPx = rect._minPx || 80;
      const maxPx = rect._maxPx || 360;
      px = Math.max(minPx, Math.min(maxPx, px));
      px = px * (rect._pxScale || 1);

      rect.widthInPixels = px;
      rect.heightInPixels = px;
    }
  }

  function update(debugFlag){
    updateLabelVisibility(debugFlag);
    updateArcGuiLabelSizes();
  }

  return {
    gui,
    registerLabel,
    setShowLabels,
    update,
    labelsById,
    formatAU, // por si lo necesitas desde fuera
    AU_KM,
    UNITS_TO_KM_LOCAL,
  };
}