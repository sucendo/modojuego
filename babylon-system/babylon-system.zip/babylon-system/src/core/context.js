// core/context.js
// Paso 14: SceneContext único para wiring y para pasar dependencias entre módulos.

export function createSceneContext() {
  return {
    BABYLON: null, // opcional, pero útil para módulos que antes recibían BABYLON por parámetro
    engine: null,
    scn: null,
    ui: null,
    uiState: null,

    world: {
      bodies: null,
      moonOrbitNodes: null,
      labelsById: null,
    },
	
    data: {
      planetParamsByName: null,
      getDefaultPlanetParams: null, // () => defaultPlanetParams
      buildRuntimePlanetParams: null,
      createJsonPlanet: null,
      relinkMoonsParent: null,
    },

    refs: {
      sunMeshRef: null,
      haloRef: null,
      surfaceBodyRef: null,
      surfaceAttachedToRef: null,
      atmoPPRef: null,
    },

    cameras: {
      cameraFly: null,
      cameraOrbit: null,
      cameraSurface: null,
    },
	
    services: {
      // Paso 15: servicios de alto nivel (single source of truth)
      selection: null,
      approach: null,
      orbit: null,
      lighting: null,
      planets: null, // agrupador opcional de helpers planetarios si lo necesitas luego
	  atmosphere: null,
    },

    systems: {
      // callbacks / systems (se rellenan en main)
      updateDynamicLOD: null,
      relinkAllBodyMeshesToLights: null,
      updateExtraSystemShadows: null,
      enforcePlanetCollision: null,
      updateOrbits: null,
      surfaceStep: null,
      updateLabelVisibility: null,
      updateRings: null,
      setAtmosphereTarget: null,
      enableAtmospherePP: null,
      updateAtmospherePP: null,
    },
  };
}