import { createTickSystem } from "./scene/tick.js";
import { createBackgroundSystem } from "./scene/background.js";
import { createGalaxyBuilder } from "./galaxy/builder.js";
import { createApproachSystem } from "./scene/approach.js";
import { createSelectionSystem } from "./scene/selection.js";
import { createSceneContext } from "./core/context.js";
import { createInputSystem } from "./scene/input.js";
import { createSurfaceController } from "./scene/surfaceController.js";
import { createLabelsSystem } from "./scene/labels.js";
import { createLowPolyFarPlanet } from "./planets/farPlanet.js";
import { loadPlanetConfig, buildRuntimePlanetParams, createJsonPlanet } from "./planets/jsonPlanet.js";
import { setupLighting } from "./scene/lights.js";
import { makeRings, updateRings } from "./planets/rings.js";
import { createStarDotManager, createStarDotSprite } from "./galaxy/starDots.js";
import { buildSystems } from "./galaxy/systems.js";
import { throttleMs } from "./utils/throttle.js";
import { createAtmosphereSystem } from "./scene/atmosphereSystem.js";
import { initUI } from "./scene/ui.js";
import { setupCamerasAndModes } from "./scene/cameras.js";
import { createOrbitSystem } from "./scene/orbits.js";
import { createCameraPlanetCollision } from "./scene/collision.js";
import { createLodSystem } from "./planets/lodSystem.js";
import { createFullDetailSystem } from "./planets/fullDetail.js";

    // ====================================================================
    // 0) Engine
    // ====================================================================
    const canvas = document.getElementById("renderCanvas");
    const engine = new BABYLON.Engine(canvas, true, {
      preserveDrawingBuffer: false,
      stencil: false,
      powerPreference: "high-performance",
      adaptToDeviceRatio: true,
    });
    // Rendimiento: baja resolución interna en pantallas densas
    try {
      const dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
      // 1.0 = nativo, 1.25-1.6 suele ser un buen equilibrio
      engine.setHardwareScalingLevel(dpr > 1.25 ? 1.35 : 1.0);
    } catch(e) {}

    // ====================================================================
    // 4) Scene
    // ====================================================================
    const { ui, uiState } = initUI();
    // Paso 14: context raíz (se rellena dentro de createScene)
    const ctx = createSceneContext();
	ctx.BABYLON = BABYLON;

    const createScene = async () => {
      const scn = new BABYLON.Scene(engine);
      ctx.engine = engine;
      ctx.scn = scn;
      ctx.ui = ui;
      ctx.uiState = uiState;
      const starDotMgr = createStarDotManager(scn, 8000);
      // star dots list (se rellena al crear sistemas)
      const galaxyStarDots = []; // billboards/sprites para que las estrellas lejanas siempre se vean

      // ------------------------------------------------------------
      // Helpers (MUST be defined before any use)
      // ------------------------------------------------------------
      // Nota: normName/bodyKey vienen del galaxyBuilder.buildAll()
 
      // Para escalas galácticas (sistemas muy separados) sin clipping ni z-fighting
      // (si el build de Babylon no lo soporta, no pasa nada)
      try { scn.useLogarithmicDepth = true; } catch(e) {}
      // Rendimiento: evita trabajo extra de picking continuo
      scn.skipPointerMovePicking = true;
      scn.blockMaterialDirtyMechanism = true;
      // Fondo realmente negro (evita el "cielo gris" cuando sube la exposición/bloom)
      scn.clearColor = new BABYLON.Color4(0, 0, 0, 1);
	  
      // Iluminación Global (IBL) muy suave (sin crear skybox/ground)
      scn.environmentIntensity = 0.15;

      // Paso 7: background + star-dots updater fuera del main
      createBackgroundSystem({
        scn,
        engine,
        starDotMgr,
        getGalaxyStarDots: () => galaxyStarDots,
      }).install();

      // Cameras + modos (Paso 2 refactor)
      const {
        cameraOrbit,
        cameraFly,
        cameraSurface,
        playerRoot,
        mode,
        setMode,
        lockOrbitToBody,
        unlockOrbit,
        getOrbitLockedBodyName,
      } = setupCamerasAndModes({
        scn,
        engine,
        canvas,
        ui,
        // Paso 18: la atmósfera se gestiona por el atmosphereSystem (ver más abajo)
        onActiveCameraChanged: (cam) => {
          try { ctx.services?.atmosphere?.ensureForCamera?.(cam); } catch(e) {}
        },
      });
      ctx.mode = mode;
      ctx.cameras.cameraFly = cameraFly;
      ctx.cameras.cameraOrbit = cameraOrbit;
      ctx.cameras.cameraSurface = cameraSurface;	  
	  
      // Nota: setupCamerasAndModes ya llama a onActiveCameraChanged() una vez.
 
      // Luz de "linterna" en superficie (evita que el terreno quede negro si el sol no incluye los chunks)
      const playerLamp = new BABYLON.PointLight("playerLamp", new BABYLON.Vector3(0, 0.25, 0), scn);
      playerLamp.parent = cameraSurface;
      playerLamp.intensity = 0.85;
      playerLamp.range = 140;
      playerLamp.setEnabled(false);

      // Create meshes (moved up: lights module needs bodies reference)
      const bodies = new Map(); // id => body (internal stable key)
      const orbitNodes = new Map(); // id => node rotated around its parent (star/planet)
      const moonOrbitNodes = new Map(); // id => node rotated around its parent planet
      let sunMesh = null; // set when Canopus is created via createStarSystem(coreSystem)
      let halo = null; // core-system halo mesh (created in createStarSystem for Canopus)
      const sunMeshRef = { get: () => sunMesh, set: (m) => { sunMesh = m; } };
      const haloRef = { get: () => halo, set: (m) => { halo = m; } };
      ctx.world.bodies = bodies;
	  ctx.world.moonOrbitNodes = moonOrbitNodes;
      ctx.refs.sunMeshRef = sunMeshRef;
      ctx.refs.haloRef = haloRef;
	  
      // ------------------------------------------------------------
      // Paso 8 refs (DEBEN existir antes de LOD/tick)
      // surfaceCtrl se inicializa más abajo, pero estas refs pueden vivir ya.
      // ------------------------------------------------------------
      let surfaceCtrl = null;
      const surfaceBodyRef = { get: () => (surfaceCtrl ? surfaceCtrl.getSurfaceBody() : null) };
      const surfaceAttachedToRef = { get: () => (surfaceCtrl ? surfaceCtrl.getAttachedBody() : null) };
      ctx.refs.surfaceBodyRef = surfaceBodyRef;
      ctx.refs.surfaceAttachedToRef = surfaceAttachedToRef;
	  
      // ------------------------------------------------------------
      // Paso 18: Atmosphere System (look = generador) via ctx
      // ------------------------------------------------------------
      ctx.services.atmosphere = createAtmosphereSystem(ctx);

      // ------------------------------------------------------------
      // Paso 13: Selection system (single source of truth)
      // ------------------------------------------------------------
      const selectionSys = createSelectionSystem({
        ui,
        bodies,
        mode,
        getSurfaceCtrl: () => surfaceCtrl,
      });
	  ctx.services.selection = selectionSys;
 
      // Lights (Paso 4 refactor)
      const lighting = setupLighting(ctx);
      const {
        sunLight,
        hemi,
        shadowGen,
        mainLitMeshes,
        lightByStarMesh,
        systemLights,
        registerStarLight,
        createLocalSystemLight,
        includeMeshInBodyLight,
        relinkAllBodyMeshesToLights,
        updateExtraSystemShadows,
      } = lighting;
	  ctx.services.lighting = lighting;
      ctx.systems.relinkAllBodyMeshesToLights = relinkAllBodyMeshesToLights;
      ctx.systems.updateExtraSystemShadows = updateExtraSystemShadows;

      // Glow desactivado por rendimiento (ya tenemos halo del sol)
      // const glow = new BABYLON.GlowLayer("glow", scn);
      // glow.intensity = 0.12;

      // Textures (put these in: /textures/planets/)
      const T = (f) => "textures/planets/" + f;	  

      // ------------------------------------------------------------
      // Helper: carga textura si existe; si falla devuelve null
      // (lo usa galaxy/builder.js para anillos/halos opcionales)
      // ------------------------------------------------------------
      function loadTextureOrNull(scene, url, opts = {}) {
        try {
          if (!url || typeof url !== "string") return null;
          // Si es ruta relativa sin protocolo, la dejamos tal cual
          const tex = new BABYLON.Texture(
            url,
            scene,
            true,
            false,
            BABYLON.Texture.TRILINEAR_SAMPLINGMODE,
            null,
            () => { /* onError -> no reventar */ }
          );
          if (opts.hasAlpha) tex.hasAlpha = true;
          return tex;
        } catch (e) {
          return null;
        }
      }

      const mapsByName = {
        // Texturas opcionales (si las pones en /textures/planets/)
        // Si no existen, el código hace fallback a colores.
        "Canopus": { /* albedo: T("2k_sun.jpg") */ },
      };

      // ====================================================================
      // DUNE systems/data extracted to src/galaxy/systems.js
      const { coreSystem, extraSystems, bodyDefs, planetMeta } = buildSystems(T);

      // system roots map (used by builder)
      const systemRoots = new Map(); // systemId -> root node

      // ====================================================================
      // ====================================================================
      // JSON planets (exported by generate-planet-js)
      // - Bodies can optionally declare def.jsonFile in src/galaxy/systems.js
      // - Everything else (rocky bodies): default.json (with per-name seed for variation)
      // NOTE: JSON files live in src/data/
      const planetParamsByName = new Map(); // bodyName -> params
      let defaultPlanetParams = null;
      // Paso 16: data wiring para módulos ctx-driven
      ctx.data.planetParamsByName = planetParamsByName;
      ctx.data.getDefaultPlanetParams = () => defaultPlanetParams;
      ctx.data.buildRuntimePlanetParams = buildRuntimePlanetParams;
      ctx.data.createJsonPlanet = createJsonPlanet;

      // Load default params (fallback for any rocky body without a specific JSON)
      try {
        defaultPlanetParams = await loadPlanetConfig("src/data/default.json");
      } catch (e) {
        console.warn("[json planets] no se pudo cargar default.json", e);
        defaultPlanetParams = null;
      }
	  
      // ------------------------------------------------------------------
      // Paso 10: Galaxy builder (crea estrellas/planetas/lunas/rings/ids)
      // ------------------------------------------------------------------
      const galaxyBuilder = createGalaxyBuilder({
        BABYLON,
        scn,
        extraSystems,
        bodies,
        orbitNodes,
        moonOrbitNodes,
        systemRoots,
        galaxyStarDots,
        starDotMgr,
        createStarDotSprite,
        makeRings,
        loadTextureOrNull, // si no existe en tu proyecto, dímelo y lo añadimos
        defaultPlanetParams,
        planetParamsByName,
        buildRuntimePlanetParams,
        createJsonPlanet,
        createLowPolyFarPlanet,
        sunLight,
        shadowGen,
        mainLitMeshes,
        registerStarLight,
        createLocalSystemLight,
        includeMeshInBodyLight,
        mapsByName,
        SYSTEM_POS_SCALE: 2.8,
        sunMeshRef,
        haloRef,
      });

      const { relinkMoonsParent, normName, bodyKey } = galaxyBuilder.buildAll();
      // Paso 16: LOD lo necesita
      ctx.data.relinkMoonsParent = relinkMoonsParent;

      // Collect specific JSON files declared in systems.js (centralized source of truth)
      const fileToBodies = new Map(); // file -> [bodyName,...]
      for (const sys of (extraSystems || [])) {
        for (const b of (sys.planets || [])) {
          if (b && b.jsonFile) {
            const f = String(b.jsonFile);
            if (!fileToBodies.has(f)) fileToBodies.set(f, []);
             // IMPORTANT: later we normalize names (pDef.name = _normName(pDef.name))
             // so store the normalized key here too, otherwise .has(pDef.name) may fail.
             fileToBodies.get(f).push(normName(b.name));
          }
        }
        for (const b of (sys.moons || [])) {
          if (b && b.jsonFile) {
            const f = String(b.jsonFile);
            if (!fileToBodies.has(f)) fileToBodies.set(f, []);
            fileToBodies.get(f).push(normName(b.name));
          }
        }
      }

      await Promise.all(
        [...fileToBodies.entries()].map(async ([file, bodyNames]) => {
          try {
            const params = await loadPlanetConfig("src/data/" + file);
            for (const name of bodyNames) planetParamsByName.set(normName(name), params);
          } catch (e) {
            console.warn(`[json planets] no se pudo cargar ${file}`, e);
          }
        })
      );

	  // Optional: show build report from systems.js (also logged in console)
      try {
        const rep = window.__GALAXY_REPORT;
        const el = document.getElementById("galaxyReport");
        if (el && rep) {
          const c = rep.counts || {};
          const problems = rep.problems || {};
          const nWarn = (problems.missingSystemPos?.length || 0)
            + (problems.systemsNoStar?.length || 0)
            + (problems.planetsMissingOrbit?.length || 0)
            + (problems.planetsUnknownSystem?.length || 0)
            + (problems.duplicateIds?.length || 0)
            + (problems.duplicatePlanetNames?.length || 0)
            + (problems.moonsMissingParent?.length || 0);

          const head = (nWarn === 0)
            ? `<span class="ok">✓ Galaxy OK</span>`
            : `<span class="warn">⚠ Galaxy warnings: ${nWarn}</span>`;

          el.innerHTML = `${head}<br>`
            + `Systems: ${c.systems ?? 0}, Stars: ${c.stars ?? 0}, Planets: ${c.planets ?? 0}, Moons: ${c.moons ?? 0}`
            + (nWarn ? `<br><span class="warn">Ver consola ("GALAXY BUILD REPORT")</span>` : "");
        }
      } catch(e) {}

      // Labels system (Paso 3 refactor)
      const labelsSys = createLabelsSystem({ scn, ui, bodies });
      const { registerLabel, updateLabelVisibility } = labelsSys;
	  ctx.systems.updateLabelVisibility = updateLabelVisibility;
      // Compat: el código LOD actual toca labelsById directamente para relink
      const labelsById = labelsSys.labelsById;
	  ctx.world.labelsById = labelsById;

      // Fill selector + labels
      ui.planetSelect.innerHTML = "";
      
      // ====================================================================
      // 3b) Create extra star systems (FAR-only por defecto)
      // ====================================================================
      // (la galaxia ya está construida por galaxyBuilder.buildAll())
	  
      // ====================================================================
      // 3c) LOD dinámico: detalle completo SOLO para el planeta/luna al que te acercas
      // - El resto se mantiene en low LOD (rápido).
      // - En surface mode, el cuerpo activo siempre va en high.
      // ====================================================================

      const lodSys = createLodSystem(ctx);

      const { updateDynamicLOD } = lodSys;
	  ctx.systems.updateDynamicLOD = updateDynamicLOD;
	  
      // ====================================================================
      // Paso 11: Full detail (surface) fuera del main
      // ====================================================================
      const fullDetailSys = createFullDetailSystem({
        BABYLON,
        scn,
        planetParamsByName,
        getDefaultPlanetParams: () => defaultPlanetParams,
        buildRuntimePlanetParams,
        createJsonPlanet,
        includeMeshInBodyLight,
        shadowGen,
        relinkMoonsParent,
        lockOrbitToBody,
        getOrbitLockedBodyName,
      });

      // ====================================================================
      // 4) Labels + UI populate (incluye sistemas extra)
      // ====================================================================
      const allDefs = bodyDefs.concat(
        extraSystems
          .filter(s => s.id !== "Canopus")
          .flatMap(s => [s.star, ...(s.planets || []), ...((s.moons) || [])])
      );

	  for (const def of allDefs) {
        if (!def) continue;
        // Normaliza nombre display
        const n = normName(def.name);
        if (!n) {
          console.warn("[skip] body sin nombre:", def);
          continue;
        }
        def.name = n;

        const id = def._key || bodyKey(def.systemId || "", def.kind || "", n, def.parentKey || "");
        def._key = id;

        const opt = document.createElement("option");
        opt.value = id;          // internal stable key
        opt.innerText = n;       // display name ONLY
        ui.planetSelect.appendChild(opt);

        const lb = bodies.get(id);
        if (lb && lb.farMesh) registerLabel(id, n, def.kind, lb.farMesh);
      }

      // Default selection by display name (Arrakis)
      try {
        const arrOpt = Array.from(ui.planetSelect.options).find(o => (o.textContent || o.innerText) === "Arrakis");
        if (arrOpt) ui.planetSelect.value = arrOpt.value;
      } catch (e) {}
      updateLabelVisibility(true);


      // ====================================================================
      // 5) Modes: orbit / fly / surface
      // ====================================================================

      ui.speedRange.addEventListener("input", (e) => {
        uiState.timeScale = parseFloat(e.target.value);
        ui.speedVal.textContent = uiState.timeScale.toFixed(1) + "x";
      });
      ui.speedVal.textContent = uiState.timeScale.toFixed(1) + "x";

      // Body currently used for surface mode (player attached)
      // Paso 8: Input + Surface controller
      const inputSys = createInputSystem(window);
      const input = inputSys.input;
      inputSys.install();

      // ====================================================================
      // 8) Surface movement + gravity (C-ready)
      // ====================================================================
      // Crear surfaceCtrl antes de approachSys para que getTargetBody sea consistente
      surfaceCtrl = createSurfaceController({
        scn,
        playerRoot,
        cameraSurface,
        input,
        // Paso 13: el target ahora viene SIEMPRE de selectionSys
        getTargetBody: () => selectionSys.getActiveBody(),
      });
	  
      // Paso 12: Approach system fuera del main
      const approachSys = createApproachSystem({
        BABYLON,
        scn,
        ui,
        selection: selectionSys,
        mode,
        setMode,
        lockOrbitToBody,
        cameraOrbit,
        cameraFly,
        cameraSurface,
        playerRoot,
        fullDetailSys,
        sunMeshRef,
        getSurfaceCtrl: () => surfaceCtrl,
      });
	  ctx.services.approach = approachSys;

      // Paso 13: surface controller usa la MISMA fuente que approach (selectionSys)
      // (así “surfaceStep” y “approach” jamás discrepan)
      surfaceCtrl.setGetTargetBody(selectionSys.getActiveBody);

      // Alias para tick.js (mantiene tu wiring actual)
      function surfaceStep(dt) { surfaceCtrl.surfaceStep(dt); }
	  ctx.systems.surfaceStep = surfaceStep;

      // Orbits system (Paso 5 refactor)
      const orbitSys = createOrbitSystem(ctx);
      const { updateOrbits, updateAllOrbitsAbsolute } = orbitSys;
	  ctx.systems.updateOrbits = updateOrbits;
	  ctx.services.orbit = orbitSys;

      // ====================================================================
      // 10) 
      // ====================================================================
      // 9b) Camera safety: evitar atravesar planetas (colisión esférica barata)
      // ====================================================================
      const { enforcePlanetCollision } = createCameraPlanetCollision({ bodies, padding: 0.9 });
	  ctx.systems.enforcePlanetCollision = enforcePlanetCollision;

	  // Render loop logic
      // ====================================================================
      setMode("orbit", {
        onExitSurface: () => surfaceCtrl && surfaceCtrl.detachPlayerFromBody(),
      });

      // Instala listeners y hace "initial approach"
      approachSys.install();
	  
      // ------------------------------------------------------------
      // Helper: posición REAL en mundo de la cámara
      // (evita incoherencias cuando hay parenting / cámaras distintas)
      // ------------------------------------------------------------
	  
      // Paso 6: Tick system (mueve todo el onBeforeRenderObservable fuera del main)
      ctx.systems.updateRings = updateRings;

      createTickSystem(ctx).install({ input }); // tick nativo con ctx (Paso 14.2)

      // updateAllOrbitsAbsolute está en orbitSys (por si lo necesitas)

      return scn;
    };

    createScene()
      .then((scene) => {
        engine.runRenderLoop(() => scene.render());
        window.addEventListener("resize", () => engine.resize());
      })
      .catch((err) => {
        console.error("Error al crear la escena:", err);
        const el = document.getElementById("galaxyReport");
        if (el) el.innerHTML = `<span class="warn">❌ Error al iniciar: ${String(err?.message || err)}</span>`;
      });
  