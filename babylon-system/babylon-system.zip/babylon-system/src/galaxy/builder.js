// galaxy/builder.js
// Paso 10: extraer "createStarSystem" + layout/ids a un módulo.
// Mantiene comportamiento: solo mueve código fuera del main.

export function createGalaxyBuilder({
  BABYLON,
  scn,

  // Data
  extraSystems,

  // Shared runtime state
  bodies,
  orbitNodes,
  moonOrbitNodes,
  systemRoots,
  galaxyStarDots,

  // Assets / visuals
  starDotMgr,
  createStarDotSprite,
  makeRings,
  loadTextureOrNull,

  // Planet generation
  defaultPlanetParams,
  planetParamsByName,
  buildRuntimePlanetParams,
  createJsonPlanet,
  createLowPolyFarPlanet,

  // Lighting
  sunLight,
  shadowGen,
  mainLitMeshes,
  registerStarLight,
  createLocalSystemLight,
  includeMeshInBodyLight,

  // Scene-wide refs (output)
  sunMeshRef,   // { get():Mesh|null, set(m) }
  haloRef,      // { get():Mesh|null, set(m) }

  // Config
  mapsByName = {},
  SYSTEM_POS_SCALE = 2.8,
  GALAXY_LAYOUT = {
    holeRadius: 1200,
    radialStep: 700,
    angleStep: 0.92,
    verticalJitter: 140,
    globalScale: 0.75,
  },
}) {
  // -----------------------------
  // Helpers (ids / names)
  // -----------------------------
  function _normName(s) {
    return (typeof s === "string") ? s.trim() : "";
  }
  const _bodyKey = (systemId, kind, name, parentKey = "") =>
    `${systemId || ""}|${kind || ""}|${parentKey || ""}|${name || ""}`;

  // pseudo-random determinista (0..1) a partir de un string
  function _galRand01(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    h >>>= 0;
    return (h % 100000) / 100000;
  }

  function buildGalaxySystemPositions(systems) {
    const map = new Map();
    let spiralIndex = 0;

    for (const sys of systems) {
      if (sys && sys.pos && typeof sys.pos.x === "number" && typeof sys.pos.y === "number" && typeof sys.pos.z === "number") {
        map.set(sys.id, sys.pos.clone().scale(GALAXY_LAYOUT.globalScale));
        continue;
      }

      const i = spiralIndex++;
      const r = GALAXY_LAYOUT.holeRadius + i * GALAXY_LAYOUT.radialStep;
      const a = i * GALAXY_LAYOUT.angleStep;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;

      const j = (_galRand01("GALAXY_Y_" + sys.id) - 0.5) * 2.0;
      const y = j * GALAXY_LAYOUT.verticalJitter;

      map.set(sys.id, new BABYLON.Vector3(x, y, z).scale(GALAXY_LAYOUT.globalScale));
    }
    return map;
  }

  const galaxyPosBySystemId = buildGalaxySystemPositions(extraSystems);

  // -----------------------------
  // Lookup helpers
  // -----------------------------
  function findBodyByNameInSystem(name, systemId, preferredKind = "planet") {
    const n = _normName(name);
    if (!n) return null;
    for (const b of bodies.values()) {
      if (!b || !b.def) continue;
      if (b.def.systemId !== systemId) continue;
      if (_normName(b.def.name) !== n) continue;
      if (b.def.kind === preferredKind) return b;
    }
    for (const b of bodies.values()) {
      if (!b || !b.def) continue;
      if (b.def.systemId !== systemId) continue;
      if (_normName(b.def.name) === n) return b;
    }
    return null;
  }

  // Used by LOD module
  function relinkMoonsParent(parentKey, newParentMesh) {
    if (!parentKey || !newParentMesh) return;
    for (const [, mb] of bodies.entries()) {
      if (!mb || !mb.def) continue;
      if (mb.def.kind !== "moon") continue;
      if (mb.def.parentKey !== parentKey) continue;
      if (mb.orbitNode) mb.orbitNode.parent = newParentMesh;
    }
  }

  // -----------------------------
  // Per-system builders
  // -----------------------------
  function linkToLight(mesh, ocean, bodyRef) {
    if (!mesh) return;
    includeMeshInBodyLight(mesh, bodyRef);
    if (ocean) includeMeshInBodyLight(ocean, bodyRef);
  }

  function applyShadows(mesh, ocean, isCore) {
    if (!mesh) return;
    if (isCore) {
      shadowGen.addShadowCaster(mesh);
      mesh.receiveShadows = true;
      if (ocean) ocean.receiveShadows = false;
    } else {
      mesh.receiveShadows = false;
      if (ocean) ocean.receiveShadows = false;
    }
  }

  function createRings(def, planetMesh) {
    if (!def || !planetMesh) return null;
    if (!def.rings) return null;

    let rt = null;
    if (typeof def.ringTex === "string" && def.ringTex.startsWith("proc:")) {
      const mode = def.ringTex.split(":")[1] || "ion";
      const dyn = new BABYLON.DynamicTexture(def.name + "_ringDyn", { width: 512, height: 512 }, scn, false);
      const ctx = dyn.getContext();
      ctx.clearRect(0,0,512,512);

      const cx = 256, cy = 256;
      for (let y=0; y<512; y++) {
        for (let x=0; x<512; x++) {
          const dx = (x-cx)/256;
          const dy = (y-cy)/256;
          const r = Math.sqrt(dx*dx + dy*dy);
          if (mode === "dust") {
            if (r < 0.58 || r > 0.86) continue;
          } else {
            if (r < 0.40 || r > 1.02) continue;
          }

          let a = 0.0;
          if (mode === "dust") {
            a += Math.max(0, 1 - Math.abs(r - 0.70)/0.06) * 0.22;
            a += Math.max(0, 1 - Math.abs(r - 0.80)/0.05) * 0.16;
          } else {
            a += Math.max(0, 1 - Math.abs(r - 0.62)/0.10) * 0.35;
            a += Math.max(0, 1 - Math.abs(r - 0.78)/0.12) * 0.25;
            a += Math.max(0, 1 - Math.abs(r - 0.92)/0.06) * 0.18;
          }

          const stripe = (Math.sin((r*(mode === "dust" ? 180 : 120)) + (dx*18)) * 0.5 + 0.5);
          a *= (mode === "dust") ? (0.35 + stripe*0.35) : (0.55 + stripe*0.55);

          if (mode === "ion") {
            const speck = (Math.sin((x*12.9898 + y*78.233)) * 43758.5453);
            const rnd = speck - Math.floor(speck);
            if (rnd > 0.985) a += 0.25;
          }
          if (mode === "dust") {
            const speck = (Math.sin((x*7.9898 + y*23.233)) * 15731.5453);
            const rnd = speck - Math.floor(speck);
            if (rnd > 0.996) a += 0.08;
          }

          if (a <= 0.005) continue;
          let rr, gg, bb;
          if (mode === "dust") {
            rr = 210; gg = 190; bb = 145;
            a *= 0.55;
          } else {
            rr = 120; gg = 170; bb = 255;
          }
          ctx.fillStyle = `rgba(${rr},${gg},${bb},${Math.min(1,a)})`;
          ctx.fillRect(x,y,1,1);
        }
      }
      dyn.update();
      rt = dyn;
    } else {
      rt = loadTextureOrNull(scn, def.ringTex, { hasAlpha: true });
    }

    if (!rt) return null;

    const ringRadiusMul = (typeof def.ringRadiusMul === "number") ? def.ringRadiusMul : 3.3;
    const ringAlpha = (typeof def.ringAlpha === "number") ? def.ringAlpha : 0.95;
    const ringTint = def.ringTint || new BABYLON.Color3(0.95, 0.90, 0.80);

    const ring = makeRings(scn, planetMesh, {
      name: def.name + "_Rings",
      radius: def.radius * ringRadiusMul,
      tessellation: 128,
      tilt: (typeof def.ringTilt === "number") ? def.ringTilt : 0,
      texture: rt,
      alpha: ringAlpha,
      tint: ringTint,
      planetRadius: def.radius,
      shadowSoftness: (typeof def.ringShadowSoftness === "number") ? def.ringShadowSoftness : 0.04,
      shadowMin: (typeof def.ringShadowMin === "number") ? def.ringShadowMin : 0.12,
    });

    return ring;
  }

  function createStarSystem(sys, opts = {}) {
    const isCore = !!opts.core || sys.id === "Canopus";
    const root = new BABYLON.TransformNode("sys_" + sys.id, scn);

    if (!sys.star) sys.star = {};
    if (!sys.star.kind) sys.star.kind = "sun";
    if (typeof sys.star.radius !== "number") sys.star.radius = 26;
    const _rawStarName = (typeof sys.star.name === "string") ? sys.star.name.trim() : "";
    const starName = _rawStarName || (sys.id ? (sys.id + " Star") : "Unknown Star");
    sys.star.name = starName;

    const gpos = galaxyPosBySystemId.has(sys.id)
      ? galaxyPosBySystemId.get(sys.id)
      : (sys.pos || BABYLON.Vector3.Zero());
    root.position.copyFrom(gpos);
    systemRoots.set(sys.id, root);

    const starSeg = isCore ? 64 : 48;
    const star = BABYLON.MeshBuilder.CreateSphere(starName, { diameter: sys.star.radius * 2, segments: starSeg }, scn);
    star.parent = root;
    star.position.set(0,0,0);
    star.isPickable = false;
    star.checkCollisions = false;
    star.alwaysSelectAsActiveMesh = true;
    star.doNotSyncBoundingInfo = true;

    if (isCore) {
      const sunMat = new BABYLON.PBRMaterial("sunMat", scn);
      sunMat.unlit = true;
      sunMat.emissiveColor = new BABYLON.Color3(1, 0.6, 0.1);
      const sunNoise = new BABYLON.NoiseProceduralTexture("sunNoise", 512, scn);
      sunNoise.animationSpeedFactor = 0.8;
      sunNoise.brightness = 0.5;
      sunMat.emissiveTexture = sunNoise;
      star.material = sunMat;

      const halo = BABYLON.MeshBuilder.CreatePlane("Canopus_Halo", { size: sys.star.radius * 3.6 }, scn);
      halo.parent = star;
      halo.isPickable = false;
      halo.billboardMode = BABYLON.Mesh.BILLBOARDMODE_ALL;

      const haloTex = new BABYLON.DynamicTexture("haloTex", { width: 512, height: 512 }, scn, false);
      const ctx = haloTex.getContext();
      const g = ctx.createRadialGradient(256,256,0,256,256,256);
      g.addColorStop(0.00, "rgba(255,210,140,0.55)");
      g.addColorStop(0.25, "rgba(255,165, 70,0.22)");
      g.addColorStop(0.55, "rgba(255,120, 40,0.10)");
      g.addColorStop(1.00, "rgba(0,0,0,0.00)");
      ctx.fillStyle = g; ctx.fillRect(0,0,512,512);
      haloTex.update();

      const haloMat = new BABYLON.StandardMaterial("haloMat", scn);
      haloMat.diffuseTexture = haloTex;
      haloMat.emissiveTexture = haloTex;
      haloMat.opacityTexture = haloTex;
      haloMat.disableLighting = true;
      haloMat.backFaceCulling = false;
      haloMat.alpha = 0.75;
      haloMat.alphaMode = BABYLON.Engine.ALPHA_ADD;
      haloMat.needDepthPrePass = true;
      halo.material = haloMat;

      sunMeshRef.set(star);
      haloRef.set(halo);

      mainLitMeshes.push(star);
      sunLight.parent = star;
      sunLight.position.set(0,0,0);
      registerStarLight(star, sunLight);
    } else {
      const starMat = new BABYLON.StandardMaterial(starName + "_mat", scn);
      starMat.emissiveColor = sys.star.emissive || new BABYLON.Color3(1,0.9,0.7);
      starMat.diffuseColor = BABYLON.Color3.Black();
      starMat.specularColor = BABYLON.Color3.Black();
      starMat.disableLighting = true;
      star.material = starMat;
    }

    // Star dot sprite
    let starDot = null;
    if (starDotMgr) {
      const col = sys.star.emissive || new BABYLON.Color3(1, 0.9, 0.7);
      const spr = createStarDotSprite(starDotMgr, starName + "_dot", root.position, col, 1.0);
      spr.renderingGroupId = 0;
      starDot = spr;
    }
    galaxyStarDots.push({ dot: starDot, star, radius: sys.star.radius });

    // Stable key for star
    sys.star.kind = sys.star.kind || "sun";
    sys.star.systemId = sys.id;
    const starKey = _bodyKey(sys.id, "sun", starName, "");
    sys.star._key = starKey;

    bodies.set(starKey, {
      id: starKey,
      def: sys.star,
      farMesh: star,
      ocean: null,
      atmo: null,
      ring: null,
      starRef: star,
      systemId: sys.id,
      orbitAngle: 0,
      orbitNode: null,
      proc: null,
    });

    if (!isCore) {
      createLocalSystemLight({
        systemId: sys.id,
        starMesh: star,
        root,
        intensity: sys.star.lightIntensity,
        range: sys.star.lightRange,
      });
    }

    // Planets
    for (const pDef of (sys.planets || [])) {
      pDef._sysSpeed = sys.speedScale || 1;
      pDef.kind = "planet";
      pDef.systemId = sys.id;
      pDef.name = _normName(pDef.name);
      if (!pDef.name) { console.warn("[skip] planet sin nombre:", pDef, "en", sys.id); continue; }
      pDef.parentKey = starKey;
      pDef.parent = starName;
      const pKey = _bodyKey(sys.id, "planet", pDef.name, starKey);
      pDef._key = pKey;

      const orbitNode = new BABYLON.TransformNode(pDef.name + "_orbit", scn);
      orbitNode.parent = root;
      orbitNode.position.set(0, 0, 0);
      orbitNodes.set(pKey, orbitNode);

      let created = null;
      let runtimeParams = null;

      const isRocky = !(pDef.gasGiant || pDef.rocky === false);
      if (isRocky && defaultPlanetParams) {
        const hasSpecific = !!pDef.jsonFile && planetParamsByName.has(pDef.name);
        const base = hasSpecific ? planetParamsByName.get(pDef.name) : defaultPlanetParams;
        runtimeParams = buildRuntimePlanetParams(base, pDef, {
          maxSubdiv: (isCore || hasSpecific) ? 7 : 5,
          minSubdiv: 2,
          forceSeedFromName: !hasSpecific,
          lockJsonParams: hasSpecific,
        });
        created = createJsonPlanet(scn, pDef, orbitNode, runtimeParams);
        pDef.useJsonPlanet = true;
      } else {
        created = createLowPolyFarPlanet(scn, pDef, orbitNode);
      }

      const mesh  = created.land;
      const ocean = created.ocean;
      const bodyRefForLight = { starRef: star, systemId: sys.id };

      const ring = isCore ? createRings(pDef, mesh) : null;

      mesh.isPickable = false;
      if (ocean) ocean.isPickable = false;
      if (ring) ring.isPickable = false;

      applyShadows(mesh, ocean, isCore);
      linkToLight(mesh, ocean, bodyRefForLight);

      bodies.set(pKey, {
        id: pKey,
        def: pDef,
        farMesh: mesh,
        ocean,
        ring,
        starRef: star,
        systemId: sys.id,
        orbitAngle: Math.random() * Math.PI * 2,
        orbitNode,
        proc: null,
        genParams: (isRocky && defaultPlanetParams) ? runtimeParams : null,

        isCore: !!isCore,
        lod: "low",
        lowMesh: mesh,
        lowOcean: ocean,
        lowGenParams: (isRocky && defaultPlanetParams) ? runtimeParams : null,
        hiMesh: null,
        hiOcean: null,
      });

      if (!isCore) {
        if (mesh.material && mesh.material.freeze) mesh.material.freeze();
        if (ocean && ocean.material && ocean.material.freeze) ocean.material.freeze();
        if (ring && ring.material && ring.material.freeze) ring.material.freeze();
      }
    }

    // Moons
    for (const mDef of (sys.moons || [])) {
      if (!mDef.parent) continue;
      mDef._sysSpeed = sys.speedScale || 1;

      mDef.kind = "moon";
      mDef.systemId = sys.id;
      mDef.name = _normName(mDef.name);
      mDef.parent = _normName(mDef.parent);
      if (!mDef.name || !mDef.parent) { console.warn("[skip] moon sin nombre/parent:", mDef, "en", sys.id); continue; }

      const parentBody = findBodyByNameInSystem(mDef.parent, sys.id, "planet");
      if (!parentBody) {
        console.warn("[moon] parent no encontrado:", mDef.parent, "para", mDef.name, "en", sys.id);
        continue;
      }

      const parentKey = parentBody.id || (parentBody.def && parentBody.def._key) || "";
      mDef.parentKey = parentKey;
      const mKey = _bodyKey(sys.id, "moon", mDef.name, parentKey);
      mDef._key = mKey;

      const moonOrbitNode = new BABYLON.TransformNode(mDef.name + "_moonOrbit", scn);
      moonOrbitNode.parent = parentBody.farMesh;
      moonOrbitNode.position.set(0,0,0);
      moonOrbitNodes.set(mKey, moonOrbitNode);

      let created = null;
      let runtimeParams = null;
      const isRockyMoon = !(mDef.gasGiant || mDef.rocky === false);
      if (isRockyMoon && defaultPlanetParams) {
        const hasSpecificMoon = !!mDef.jsonFile && planetParamsByName.has(mDef.name);
        const baseMoon = hasSpecificMoon ? planetParamsByName.get(mDef.name) : defaultPlanetParams;
        runtimeParams = buildRuntimePlanetParams(baseMoon, mDef, {
          maxSubdiv: (isCore || hasSpecificMoon) ? 6 : 4,
          minSubdiv: 2,
          forceSeedFromName: !hasSpecificMoon,
          lockJsonParams: hasSpecificMoon,
        });
        created = createJsonPlanet(scn, mDef, moonOrbitNode, runtimeParams);
        mDef.useJsonPlanet = true;
      } else {
        created = createLowPolyFarPlanet(scn, mDef, moonOrbitNode);
      }

      const mesh = created.land;
      const ocean = created.ocean;
      const bodyRefForLight = { starRef: star, systemId: sys.id };

      mesh.isPickable = false;
      if (ocean) ocean.isPickable = false;

      applyShadows(mesh, ocean, isCore);
      linkToLight(mesh, ocean, bodyRefForLight);

      bodies.set(mKey, {
        id: mKey,
        def: mDef,
        farMesh: mesh,
        landMesh: mesh,
        mesh: mesh,
        ocean,
        ring: null,
        starRef: star,
        systemId: sys.id,
        orbitAngle: Math.random() * Math.PI * 2,
        orbitNode: moonOrbitNode,
        proc: null,
        genParams: (isRockyMoon && defaultPlanetParams) ? runtimeParams : null,

        isCore: !!isCore,
        lod: "low",
        lowMesh: mesh,
        lowOcean: ocean,
        lowGenParams: (isRockyMoon && defaultPlanetParams) ? runtimeParams : null,
        hiMesh: null,
        hiOcean: null,
      });

      if (!isCore) {
        if (mesh.material && mesh.material.freeze) mesh.material.freeze();
        if (ocean && ocean.material && ocean.material.freeze) ocean.material.freeze();
      }
    }

    if (!isCore) {
      star.freezeWorldMatrix();
      star.doNotSyncBoundingInfo = true;
      if (star.material && star.material.freeze) star.material.freeze();
    }
  }

  function buildAll() {
    for (const sys of extraSystems) {
      createStarSystem(sys, { core: sys.id === "Canopus" });
    }
    return {
      galaxyPosBySystemId,
      relinkMoonsParent,
      normName: _normName,
      bodyKey: _bodyKey,
    };
  }

  return { buildAll, relinkMoonsParent, normName: _normName, bodyKey: _bodyKey };
}