// scene/tick.js
// Paso 6: sacar el "bucle gordo" del main.js a un módulo
// - Mantiene el mismo comportamiento, pero deja main.js como orquestador.

import { getCameraWorldPos } from "./cameraUtils.js";

function isCtx(x) {
  return !!(x && x.scn && x.engine && x.world && x.refs && x.systems && x.cameras);
}

function unpackFromCtx(ctx) {
  const sunMesh = ctx.refs?.sunMeshRef?.get ? ctx.refs.sunMeshRef.get() : null;
  const halo = ctx.refs?.haloRef?.get ? ctx.refs.haloRef.get() : null;

  return {
    engine: ctx.engine,
    scn: ctx.scn,
    ui: ctx.ui,

    bodies: ctx.world.bodies,
    mode: ctx.mode,
    uiState: ctx.uiState,

    sunMesh,
    halo,
    surfaceBodyRef: ctx.refs.surfaceBodyRef,
    surfaceAttachedToRef: ctx.refs.surfaceAttachedToRef,

    cameraFly: ctx.cameras.cameraFly,
    cameraOrbit: ctx.cameras.cameraOrbit,
    cameraSurface: ctx.cameras.cameraSurface,

    updateDynamicLOD: ctx.systems.updateDynamicLOD,
    relinkAllBodyMeshesToLights: ctx.systems.relinkAllBodyMeshesToLights,
    updateExtraSystemShadows: ctx.systems.updateExtraSystemShadows,
    enforcePlanetCollision: ctx.systems.enforcePlanetCollision,
    updateOrbits: ctx.systems.updateOrbits,
    surfaceStep: ctx.systems.surfaceStep,
    updateLabelVisibility: ctx.systems.updateLabelVisibility,

    updateRings: ctx.systems.updateRings,

    atmoPPRef: ctx.refs.atmoPPRef,
    atmosphere: (ctx.services && ctx.services.atmosphere) ? ctx.services.atmosphere : null,
    setAtmosphereTarget: ctx.systems.setAtmosphereTarget,
    enableAtmospherePP: ctx.systems.enableAtmospherePP,
    updateAtmospherePP: ctx.systems.updateAtmospherePP,
  };
}

export function createTickSystem(optsOrCtx) {
  const opts = isCtx(optsOrCtx) ? unpackFromCtx(optsOrCtx) : optsOrCtx;

  const {
    engine,
    scn,
    ui,

    // State / refs
    bodies,
    mode,
    uiState,
    sunMesh,
    halo,
    surfaceBodyRef,          // { get(): body|null }
    surfaceAttachedToRef,    // { get(): body|null }

    // Cameras
    cameraFly,
    cameraOrbit,
    cameraSurface,

    // Systems
    updateDynamicLOD,
    relinkAllBodyMeshesToLights,
    updateExtraSystemShadows,
    enforcePlanetCollision,
    updateOrbits,
    surfaceStep,
    updateLabelVisibility,

    // Rings
    updateRings,

    // Atmosphere PP (screen-space)
    atmoPPRef,               // { get(): pp|null }
	atmosphere,
    setAtmosphereTarget,
    enableAtmospherePP,
    updateAtmospherePP,
  } = opts;

  // Guardrails (para fallar pronto si falta wiring en ctx)
  if (!engine || !scn) throw new Error("[tick] engine/scn requeridos");
  if (!bodies) throw new Error("[tick] bodies requerido");
  if (!mode) throw new Error("[tick] mode requerido");
  if (typeof updateDynamicLOD !== "function") throw new Error("[tick] updateDynamicLOD requerido");
  if (typeof relinkAllBodyMeshesToLights !== "function") throw new Error("[tick] relinkAllBodyMeshesToLights requerido");
  if (typeof updateExtraSystemShadows !== "function") throw new Error("[tick] updateExtraSystemShadows requerido");
  if (typeof enforcePlanetCollision !== "function") throw new Error("[tick] enforcePlanetCollision requerido");
  if (typeof updateOrbits !== "function") throw new Error("[tick] updateOrbits requerido");
  if (typeof surfaceStep !== "function") throw new Error("[tick] surfaceStep requerido");
  if (typeof updateLabelVisibility !== "function") throw new Error("[tick] updateLabelVisibility requerido");
  if (typeof updateRings !== "function") throw new Error("[tick] updateRings requerido");

  // Throttle de debug DOM
  function updateDebug(chunks) {
    if (!scn._dbgT || (performance.now() - scn._dbgT) > 350) {
      scn._dbgT = performance.now();
      if (ui && ui.debugInfo) {
        ui.debugInfo.textContent = `Chunks activos: ${chunks} | FPS: ${engine.getFps().toFixed(0)}`;
      }
    }
  }

  function animateHalo() {
    const t = performance.now() * 0.001;
    if (halo && halo.scaling && halo.scaling.set) {
      halo.scaling.set(
        1 + Math.sin(t * 0.8) * 0.01,
        1 + Math.sin(t * 0.9) * 0.01,
        1 + Math.sin(t * 0.7) * 0.01
      );
    }
  }

  function updateRingsForAll(camPos) {
    if (!camPos) return;
    for (const [, b] of bodies.entries()) {
      if (!b || !b.farMesh || !b.ring) continue;
      const p = b.farMesh.getAbsolutePosition();
      const starRef = b.starRef || sunMesh;
      const sunPos = starRef ? starRef.getAbsolutePosition() : null;
      if (sunPos) updateRings(b.ring, p, sunPos, b.def.radius);
    }
  }

  function flySprint(input) {
    if (mode.value !== "fly" || !cameraFly) return;
    const base = cameraFly._flyBaseSpeed || 2.2;
    const spr  = cameraFly._flySprintSpeed || 7.5;
    cameraFly.speed = (input && input.sprint) ? spr : base;
  }

  function cheapCollisions() {
    if (mode.value === "fly") enforcePlanetCollision(cameraFly);
    if (mode.value === "orbit") enforcePlanetCollision(cameraOrbit);
  }

  function surfaceModeStep(dt) {
    let chunks = 0;
    if (mode.value === "surface") {
      surfaceStep(dt);
    }
    return chunks;
  }

  // Public: instala el loop
  function install({ input }) {
    scn.onBeforeRenderObservable.add(() => {
      const dt = engine.getDeltaTime() / 1000;
      const cam = scn.activeCamera;
      const camPos = getCameraWorldPos(cam);

      // LOD dinámico
      if (camPos) updateDynamicLOD(camPos);

      // Mantenimiento de luces/sombras
      if (camPos) {
        relinkAllBodyMeshesToLights();
        updateExtraSystemShadows();
      }

      // Atmósfera PP
      if (atmosphere && typeof atmosphere.tick === "function") {
        atmosphere.tick(camPos, performance.now() * 0.001);
      } else {
        // fallback legacy si aún no has creado ctx.services.atmosphere
        const pp = atmoPPRef && atmoPPRef.get ? atmoPPRef.get() : null;
        if (pp) enableAtmospherePP(pp, false);
      }

      // Sprint fly + colisión barata
      flySprint(input);
      cheapCollisions();

      // Rings + halo
      updateRingsForAll(camPos);
      animateHalo();

      // Órbitas siempre
      updateOrbits(dt);

      // Superficie
      const chunks = surfaceModeStep(dt);

      // Labels
      updateLabelVisibility(false);

      // Debug
      updateDebug(chunks);
    });
  }

  return { install };
}