// scene/cameraUtils.js
// Helpers compartidos de cámara (posición world consistente con parenting)

export function getCameraWorldPos(cam) {
  if (!cam) return null;
  // Babylon suele mantener globalPosition actualizado cada frame.
  if (cam.globalPosition) return cam.globalPosition;
  if (typeof cam.getAbsolutePosition === "function") return cam.getAbsolutePosition();
  return cam.position || null;
}