// scene/background.js
// Paso 7: fondo de estrellas (PCS) + star-dots (sprites) fuera del main.

import { throttleMs } from "../utils/throttle.js";
import { getCameraWorldPos } from "./cameraUtils.js";

export function createBackgroundSystem({
  scn,
  engine,
  starDotMgr,
  getGalaxyStarDots, // () => galaxyStarDots[]
  opts = {},
}) {
  const starCount = opts.starCount ?? 12000;
  const starRadius = opts.starRadius ?? 2800;
  const pointSize = opts.pointSize ?? 1.15;
  const targetPx = opts.targetPx ?? 1.25;
  const dotScaleMul = opts.dotScaleMul ?? 0.035;
  const updateMs = opts.updateMs ?? 250;

  // Background stars (point cloud)
  const starsPCS = new BABYLON.PointsCloudSystem("stars", 1, scn);
  let starsMesh = null;

  starsPCS.addPoints(starCount, (p) => {
    const u = Math.random();
    const v = Math.random();
    const theta = 2 * Math.PI * u;
    const phi = Math.acos(2 * v - 1);

    const r = starRadius * (0.35 + 0.65 * Math.pow(Math.random(), 0.35));
    p.position.x = r * Math.sin(phi) * Math.cos(theta);
    p.position.y = r * Math.cos(phi);
    p.position.z = r * Math.sin(phi) * Math.sin(theta);

    const a = 0.55 + Math.random() * 0.45;
    p.color = new BABYLON.Color4(1, 1, 1, a);
  });

  starsPCS.buildMeshAsync().then((m) => {
    starsMesh = m;
    starsMesh.isPickable = false;
    starsMesh.alwaysSelectAsActiveMesh = true;

    const starsMat = new BABYLON.StandardMaterial("starsMat", scn);
    starsMat.emissiveColor = new BABYLON.Color3(0.9, 0.9, 0.9);
    starsMat.disableLighting = true;
    starsMat.pointsCloud = true;
    starsMat.pointSize = pointSize;
    starsMesh.material = starsMat;
  });

  // Throttle: con 4–10Hz va perfecto
  const updateStarDotsSize = throttleMs(() => {
    const cam = scn.activeCamera;
    const dots = (typeof getGalaxyStarDots === "function") ? getGalaxyStarDots() : null;
    if (!cam || !dots || !dots.length) return;

    const vh = engine.getRenderHeight(true);
    const fov = (typeof cam.fov === "number") ? cam.fov : 0.8;
    const tanHalf = Math.tan(fov * 0.5);
    const camPos = cam.globalPosition || cam.position;

    for (const s of dots) {
      const dot = s.dot;
      if (!dot) continue;
      if (typeof dot.isDisposed === "function" && dot.isDisposed()) continue;

      // Mantener el dot en la posición real de la estrella
      if (s.star && dot.position && typeof dot.position.copyFrom === "function" && typeof s.star.getAbsolutePosition === "function") {
        dot.position.copyFrom(s.star.getAbsolutePosition());
      }

      const p = (typeof dot.getAbsolutePosition === "function")
        ? dot.getAbsolutePosition()
        : (dot.position || null);
      if (!p) continue;

      const dist = BABYLON.Vector3.Distance(camPos, p);
      const worldPerPx = (2 * dist * tanHalf) / Math.max(1, vh);
      const size = Math.max(worldPerPx * targetPx, s.radius * dotScaleMul);

      if (dot.scaling && typeof dot.scaling.setAll === "function") dot.scaling.setAll(size);
      else if (typeof dot.size === "number") dot.size = size;
    }
  }, updateMs);

  function install() {
    // Star-dots (sprites): deben renderizar como fondo y sin depthWrite
    try { if (starDotMgr) starDotMgr.renderingGroupId = 0; } catch(e) {}
    try { if (starDotMgr) starDotMgr.disableDepthWrite = true; } catch(e) {}

    scn.onBeforeRenderObservable.add(() => {
      const cam = scn.activeCamera;
      const camPos = getCameraWorldPos(cam);
      if (starsMesh && camPos) starsMesh.position.copyFrom(camPos);
      updateStarDotsSize();
    });
  }

  return {
    install,
    getStarsMesh: () => starsMesh,
  };
}