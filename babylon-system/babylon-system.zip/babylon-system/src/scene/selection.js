// scene/selection.js
// Paso 13: centralizar la selección/target body (selected vs surface-attached)

function isCtx(x) {
  return !!(x && x.ui && x.world && x.world.bodies && x.mode);
}

export function createSelectionSystem(optsOrCtx) {
  const opts = isCtx(optsOrCtx)
    ? {
        ui: optsOrCtx.ui,
        bodies: optsOrCtx.world.bodies,
        mode: optsOrCtx.mode,
        getSurfaceCtrl: () => (optsOrCtx.refs && optsOrCtx.refs.surfaceBodyRef) ? null : null, // fallback (no se usa si se pasa getSurfaceCtrl real)
        getSurfaceCtrlReal: null,
        ctx: optsOrCtx,
      }
    : { ...optsOrCtx, ctx: null };

  const {
    ui,
    bodies,
    mode,
    getSurfaceCtrl, // () => surfaceCtrl|null
  } = opts;

  if (!ui) throw new Error("[selection] ui required");
  if (!bodies) throw new Error("[selection] bodies required");
  if (!mode) throw new Error("[selection] mode required");

  // Si viene de ctx y ya existe ctx.services.approach con surfaceCtrl getter, lo usamos
  // (permite construir selection antes/después sin orden estricto)
  function _getSurfaceCtrl() {
    if (typeof getSurfaceCtrl === "function") return getSurfaceCtrl();
    const ctx = opts.ctx;
    const a = ctx && ctx.services && ctx.services.approach;
    return a && a.getSurfaceCtrl ? a.getSurfaceCtrl() : null;
  }

  function getSelectedId() {
    return ui.planetSelect ? ui.planetSelect.value : "";
  }

  function getSelectedBody() {
    const id = getSelectedId();
    return id ? bodies.get(id) : null;
  }

  function getAttachedBody() {
    const surfaceCtrl = _getSurfaceCtrl();
    return surfaceCtrl ? (surfaceCtrl.getAttachedBody ? surfaceCtrl.getAttachedBody() : null) : null;
  }

  // “Active body” = el que manda para surfaceStep y para acciones cuando estás en surface
  function getActiveBody() {
    const attached = getAttachedBody();
    if (mode.value === "surface" && attached) return attached;
    return getSelectedBody();
  }

  function selectByDisplayName(displayName) {
    try {
      const sel = String(displayName || "");
      if (!ui.planetSelect || !sel) return false;
      const opt = Array.from(ui.planetSelect.options).find(o => (o.textContent || o.innerText) === sel);
      if (!opt) return false;
      ui.planetSelect.value = opt.value;
      return true;
    } catch (e) {
      return false;
    }
  }

  return {
    getSelectedId,
    getSelectedBody,
    getAttachedBody,
    getActiveBody,
    selectByDisplayName,
  };
}