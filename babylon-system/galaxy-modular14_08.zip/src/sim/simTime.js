// sim/simTime.js
// Helpers de tiempo absoluto de simulación, desacoplados del frame loop local.

const DEFAULT_DAYS_PER_REAL_SECOND = 1.0 / 86400.0;

function _num(v, fb = 0) {
  return Number.isFinite(Number(v)) ? Number(v) : fb;
}

export function getAbsoluteSimDays(daysPerRealSecond = DEFAULT_DAYS_PER_REAL_SECOND, nowMs = Date.now()) {
  const rate = _num(daysPerRealSecond, DEFAULT_DAYS_PER_REAL_SECOND);
  const ms = _num(nowMs, Date.now());
  return (ms * 0.001) * rate;
}

export function getAbsoluteRealSeconds(nowMs = Date.now()) {
  return _num(nowMs, Date.now()) * 0.001;
}