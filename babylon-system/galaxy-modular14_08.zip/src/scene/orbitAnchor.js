
export function createCameraOrbitAnchor({
  bodyMaps = [],
  allowedKinds = ['planet', 'moon', 'asteroid', 'comet'],
  captureMul = 60.0,
  stickyMul = 120.0,
  minCaptureGap = 0.03,
  influenceHz = 2.0,
  offsetFollowHz = 5.0,
  carryFactor = 1.0,

  // Seguimiento del marco rotante del cuerpo:
  // - 100% en superficie / órbita muy baja
  // - fade progresivo en órbita baja-media
  frameFullMul = 0.05,
  frameFadeMul = 0.50,
  minFrameFullGap = 0.00005,
  minFrameFadeGap = 0.002,
  frameCarry = 1.0,
}) {
  const kinds = new Set(
    Array.isArray(allowedKinds)
      ? allowedKinds
      : ['planet', 'moon', 'asteroid', 'comet']
  );

  const prevCenters = new WeakMap();
  const prevRotations = new WeakMap();

  let lockedNode = null;
  let influence = 0.0;

  const smoothedOffset = new BABYLON.Vector3(0, 0, 0);
  const desiredOffset = new BABYLON.Vector3(0, 0, 0);
  const _currentOffset = new BABYLON.Vector3(0, 0, 0);
  const _rotatedOffset = new BABYLON.Vector3(0, 0, 0);
  const _rotatedSmoothed = new BABYLON.Vector3(0, 0, 0);
  const _rotM = new BABYLON.Matrix();

  const _tmpScale = new BABYLON.Vector3(1, 1, 1);
  const _tmpPos = new BABYLON.Vector3(0, 0, 0);
  const _qIdentity = BABYLON.Quaternion.Identity();
  const _qWorldCur = new BABYLON.Quaternion(0, 0, 0, 1);
  const _qWorldPrev = new BABYLON.Quaternion(0, 0, 0, 1);
  const _qWorldDelta = new BABYLON.Quaternion(0, 0, 0, 1);
  const _qWorldApplied = new BABYLON.Quaternion(0, 0, 0, 1);

  function alphaFromHz(hz, dtSec) {
    return 1.0 - Math.exp(-Math.max(0, hz) * Math.max(0, dtSec));
  }

  function clamp01(v) {
    return Math.max(0, Math.min(1, v));
  }

  function smoothstep01(t) {
    t = clamp01(t);
    return t * t * (3 - 2 * t);
  }

  function inverseSmoothBand(value, fullValue, fadeValue) {
    if (value <= fullValue) return 1.0;
    if (value >= fadeValue) return 0.0;
    const t = (value - fullValue) / Math.max(1e-8, (fadeValue - fullValue));
    return 1.0 - smoothstep01(t);
  }

  function computeFrameFollowFactor(radiusWorld, gap) {
    const fullGap = Math.max(minFrameFullGap, radiusWorld * frameFullMul);
    const fadeGap = Math.max(minFrameFadeGap, radiusWorld * frameFadeMul);
    return inverseSmoothBand(gap, fullGap, fadeGap);
  }

  function getNodeWorldRotationQuat(node, out = _qWorldCur) {
    try { node?.computeWorldMatrix?.(true); } catch (_) {}

    try {
      const wm = node?.getWorldMatrix?.();
      if (wm && typeof wm.decompose === 'function') {
        wm.decompose(_tmpScale, out, _tmpPos);
        if (typeof out.normalize === 'function') out.normalize();
        return out;
      }
    } catch (_) {}

    if (node?.rotationQuaternion) {
      out.copyFrom(node.rotationQuaternion);
      if (typeof out.normalize === 'function') out.normalize();
      return out;
    }

    const rx = Number(node?.rotation?.x || 0);
    const ry = Number(node?.rotation?.y || 0);
    const rz = Number(node?.rotation?.z || 0);
    const q = BABYLON.Quaternion.RotationYawPitchRoll(ry, rx, rz);
    out.copyFrom(q);
    if (typeof out.normalize === 'function') out.normalize();
    return out;
  }

  function rotateVectorByQuaternionToRef(vec, quat, out) {
    BABYLON.Matrix.FromQuaternionToRef(quat, _rotM);
    BABYLON.Vector3.TransformNormalToRef(vec, _rotM, out);
    return out;
  }

  function setPrevRotation(node, worldQ) {
    let prevQ = prevRotations.get(node);
    if (!prevQ) {
      prevQ = worldQ.clone();
      prevRotations.set(node, prevQ);
    } else prevQ.copyFrom(worldQ);
    return prevQ;
  }

  function eachBody(fn) {
    for (const map of bodyMaps) {
      if (!map || typeof map.values !== 'function') continue;
      for (const node of map.values()) {
        if (!node) continue;
        const md = node.metadata || {};
        if (!kinds.has(md.kind)) continue;

        const radiusWorld = Number(md.radiusWorld);
        if (!(radiusWorld > 0)) continue;

        fn(node, radiusWorld, md);
      }
    }
  }

  function getNodeWorldPos(node) {
    try { node.computeWorldMatrix?.(true); } catch (_) {}
    try {
      return (typeof node.getAbsolutePosition === 'function')
        ? node.getAbsolutePosition()
        : node.position;
    } catch (_) {
      return node.position;
    }
  }

  function chooseTarget(cam) {
    let best = null;

    eachBody((node, radiusWorld) => {
      const center = getNodeWorldPos(node);
      if (!center) return;

      const dx = cam.position.x - center.x;
      const dy = cam.position.y - center.y;
      const dz = cam.position.z - center.z;
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      const gap = Math.max(0, dist - radiusWorld);

      const captureGap = Math.max(minCaptureGap, radiusWorld * captureMul);
      const stickyGap = Math.max(captureGap * 2.0, radiusWorld * stickyMul);
      const limit = (node === lockedNode) ? stickyGap : captureGap;

      if (gap > limit) return;

      const score = gap + (node === lockedNode ? -0.01 : 0.0);
      if (!best || score < best.score) {
        best = { node, center, radiusWorld, gap, captureGap, stickyGap, score };
      }
    });

    return best;
  }

  function applyOrbitAnchor(cam, camCtrl, dtSec = 0, dtDays = 0) {
    if (!cam?.position) return null;

    if (camCtrl?.getMode?.() !== 'ship') {
      lockedNode = null;
      influence = 0.0;
      return null;
    }

    const target = chooseTarget(cam);

    if (!target) {
      const aOut = alphaFromHz(influenceHz, dtSec);
      influence += (0.0 - influence) * aOut;
      if (influence < 0.001) {
        influence = 0.0;
        lockedNode = null;
      }
      return null;
    }

    if (lockedNode !== target.node) {
      lockedNode = target.node;
      smoothedOffset.x = cam.position.x - target.center.x;
      smoothedOffset.y = cam.position.y - target.center.y;
      smoothedOffset.z = cam.position.z - target.center.z;
      setPrevRotation(target.node, getNodeWorldRotationQuat(target.node, _qWorldCur));
    }

    let prevCenter = prevCenters.get(target.node);
    if (!prevCenter) {
      prevCenter = target.center.clone();
      prevCenters.set(target.node, prevCenter);
    }
    
    // OJO: hay que leer la rotación previa ANTES de sobrescribirla con la actual.
    // Si no, deltaQ sale identidad y no seguimos realmente el frame rotante.
    let prevWorldQ = prevRotations.get(target.node);
    if (prevWorldQ) {
      _qWorldPrev.copyFrom(prevWorldQ);
      prevWorldQ = _qWorldPrev;
    } else {
      getNodeWorldRotationQuat(target.node, _qWorldPrev);
      prevWorldQ = _qWorldPrev;
    }
    const currentWorldQ = getNodeWorldRotationQuat(target.node, _qWorldCur);
    const bodyDx = target.center.x - prevCenter.x;
    const bodyDy = target.center.y - prevCenter.y;
    const bodyDz = target.center.z - prevCenter.z;

    const aInf = alphaFromHz(influenceHz, dtSec);
    const t = 1.0 - Math.min(1.0, target.gap / Math.max(target.captureGap, 1e-8));
    const wantedInfluence = smoothstep01(t);
    influence += (wantedInfluence - influence) * aInf;

    // 1) Viajar con el cuerpo
    cam.position.x += bodyDx * carryFactor * influence;
    cam.position.y += bodyDy * carryFactor * influence;
    cam.position.z += bodyDz * carryFactor * influence;

    // 1b) Seguir la ROTACIÓN REAL del cuerpo en mundo.
    // Esto hace que en superficie y órbita baja acompañes el spin del planeta/luna
    // con un frame local coherente, y además funciona bien aunque el tiempo sea absoluto.
    const frameFollow = clamp01(computeFrameFollowFactor(target.radiusWorld, target.gap) * influence * frameCarry);
    if (frameFollow > 1e-5) {
      const invPrevQ = BABYLON.Quaternion.Inverse(prevWorldQ);
      _qWorldDelta.copyFrom(currentWorldQ.multiply(invPrevQ));
      _qWorldDelta.normalize();

      let appliedQ = _qWorldDelta;
      if (frameFollow < 0.999) {
        if (typeof BABYLON.Quaternion.SlerpToRef === 'function') {
          BABYLON.Quaternion.SlerpToRef(_qIdentity, _qWorldDelta, frameFollow, _qWorldApplied);
        } else {
          _qWorldApplied.copyFrom(BABYLON.Quaternion.Slerp(_qIdentity, _qWorldDelta, frameFollow));
        }
        appliedQ = _qWorldApplied;
      }
      _currentOffset.x = cam.position.x - target.center.x;
      _currentOffset.y = cam.position.y - target.center.y;
      _currentOffset.z = cam.position.z - target.center.z;

      rotateVectorByQuaternionToRef(_currentOffset, appliedQ, _rotatedOffset);
      cam.position.x = target.center.x + _rotatedOffset.x;
      cam.position.y = target.center.y + _rotatedOffset.y;
      cam.position.z = target.center.z + _rotatedOffset.z;

      rotateVectorByQuaternionToRef(smoothedOffset, appliedQ, _rotatedSmoothed);
      smoothedOffset.copyFrom(_rotatedSmoothed);
    }

    // 2) Movimiento libre alrededor del cuerpo, suavizado
    desiredOffset.x = cam.position.x - target.center.x;
    desiredOffset.y = cam.position.y - target.center.y;
    desiredOffset.z = cam.position.z - target.center.z;

    const aOff = alphaFromHz(offsetFollowHz, dtSec);
    smoothedOffset.x += (desiredOffset.x - smoothedOffset.x) * aOff;
    smoothedOffset.y += (desiredOffset.y - smoothedOffset.y) * aOff;
    smoothedOffset.z += (desiredOffset.z - smoothedOffset.z) * aOff;

    const targetX = target.center.x + smoothedOffset.x;
    const targetY = target.center.y + smoothedOffset.y;
    const targetZ = target.center.z + smoothedOffset.z;

    cam.position.x += (targetX - cam.position.x) * influence;
    cam.position.y += (targetY - cam.position.y) * influence;
    cam.position.z += (targetZ - cam.position.z) * influence;

    prevCenter.copyFrom(target.center);
	setPrevRotation(target.node, currentWorldQ);
    return target;
  }

  function syncOffsetFromCamera(cam) {
    if (!lockedNode || !cam?.position) return;
    const center = getNodeWorldPos(lockedNode);
    if (!center) return;

    smoothedOffset.x = cam.position.x - center.x;
    smoothedOffset.y = cam.position.y - center.y;
    smoothedOffset.z = cam.position.z - center.z;

    desiredOffset.x = smoothedOffset.x;
    desiredOffset.y = smoothedOffset.y;
    desiredOffset.z = smoothedOffset.z;

    let prevCenter = prevCenters.get(lockedNode);
    if (!prevCenter) {
      prevCenter = center.clone();
      prevCenters.set(lockedNode, prevCenter);
    } else {
      prevCenter.copyFrom(center);
    }

    setPrevRotation(lockedNode, getNodeWorldRotationQuat(lockedNode, _qWorldCur));
  }
  
  function getBodyKey(node) {
    const md = node?.metadata || {};
    return String(md.bodyId || md.id || node?.name || '');
  }

  function findBodyById(bodyId) {
    if (!bodyId) return null;
    const wanted = String(bodyId);
    let found = null;

    eachBody((node) => {
      if (found) return;
      if (getBodyKey(node) === wanted) found = node;
    });

    return found;
  }

  function serializeState(cam) {
    if (!cam?.position) return null;

    let node = lockedNode;
    let center = node ? getNodeWorldPos(node) : null;

    // Si aún no estaba "locked", intenta usar el cuerpo candidato actual
    if (!node || !center) {
      const target = chooseTarget(cam);
      node = target?.node || null;
      center = target?.center || (node ? getNodeWorldPos(node) : null);
    }

    if (!node || !center) return null;

    const bodyId = getBodyKey(node);
    if (!bodyId) return null;

    const worldQ = getNodeWorldRotationQuat(node, _qWorldCur);
    _currentOffset.copyFromFloats(
      cam.position.x - center.x,
      cam.position.y - center.y,
      cam.position.z - center.z,
    );

    // Guardamos también el offset en espacio LOCAL del cuerpo para que,
    // al cargar más tarde, la posición siga siendo co-rotante con él.
    const invWorldQ = BABYLON.Quaternion.Inverse(worldQ);
    rotateVectorByQuaternionToRef(_currentOffset, invWorldQ, _rotatedOffset);

    return {
	  version: 2,
      bodyId,
      offset: {
        x: _currentOffset.x,
        y: _currentOffset.y,
        z: _currentOffset.z,
      },
      localOffset: {
        x: _rotatedOffset.x,
        y: _rotatedOffset.y,
        z: _rotatedOffset.z,
      },
      influence: Number.isFinite(influence) ? influence : 1.0,
    };
  }

  function applySavedState(saved, cam) {
    if (!saved || !cam?.position) return false;

    const bodyId = String(saved.bodyId || '');
    const ox = Number(saved?.offset?.x);
    const oy = Number(saved?.offset?.y);
    const oz = Number(saved?.offset?.z);
    const lox = Number(saved?.localOffset?.x);
    const loy = Number(saved?.localOffset?.y);
    const loz = Number(saved?.localOffset?.z);

    if (
      !bodyId ||
      (
        (!Number.isFinite(ox) || !Number.isFinite(oy) || !Number.isFinite(oz)) &&
        (!Number.isFinite(lox) || !Number.isFinite(loy) || !Number.isFinite(loz))
      )
    ) {
	return false;
    }

    const node = findBodyById(bodyId);
    if (!node) return false;

    const center = getNodeWorldPos(node);
    if (!center) return false;
	const worldQ = getNodeWorldRotationQuat(node, _qWorldCur);

    lockedNode = node;
    influence = clamp01(Number.isFinite(saved.influence) ? saved.influence : 1.0);

    // Saves nuevos: restauran posición en el marco ROTANTE del cuerpo.
    // Saves antiguos: caen al offset inercial viejo.
    if (Number.isFinite(lox) && Number.isFinite(loy) && Number.isFinite(loz)) {
      _currentOffset.copyFromFloats(lox, loy, loz);
      rotateVectorByQuaternionToRef(_currentOffset, worldQ, _rotatedOffset);
      smoothedOffset.copyFrom(_rotatedOffset);
      desiredOffset.copyFrom(_rotatedOffset);
    } else {
      smoothedOffset.copyFromFloats(ox, oy, oz);
      desiredOffset.copyFromFloats(ox, oy, oz);
    }

    cam.position.copyFromFloats(
      center.x + smoothedOffset.x,
      center.y + smoothedOffset.y,
      center.z + smoothedOffset.z,
    );

    let prevCenter = prevCenters.get(node);
    if (!prevCenter) {
      prevCenter = center.clone();
      prevCenters.set(node, prevCenter);
    } else {
      prevCenter.copyFrom(center);
    }

    setPrevRotation(node, worldQ);

    return true;
  }

  function clearOrbitAnchor() {
    lockedNode = null;
    influence = 0.0;
  }

  return {
    applyOrbitAnchor,
    syncOffsetFromCamera,
    clearOrbitAnchor,
    getLockedBody: () => lockedNode,
    findBodyById,
    serializeState,
    applySavedState,
  };
}