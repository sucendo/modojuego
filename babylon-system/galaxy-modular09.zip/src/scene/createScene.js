import { SYSTEMS } from '../data/systems.js';
import { GALAXY } from '../data/galaxy.js';
import { createEngine } from '../core/engine.js';
import { createFloatingOrigin } from '../core/floatingOrigin.js';
import { initHudToggles } from '../ui/hudToggles.js';
import { setupLights } from './lights.js';
import { setupCamera } from './camera.js';
import { createLabels } from '../ui/labels.js';
import { createEliteHud } from '../ui/eliteHud.js';
import { createNavigationGridController } from '../ui/navGrid.js';
import { buildSystemNodes } from '../bodies/systems.js';
import { buildStars } from '../bodies/stars.js';
import { buildPlanets } from '../bodies/planets.js';
import { updateOrbits } from '../bodies/orbitAnimator.js';
import { createSystemDotScaler } from '../ui/systemDots.js'

export function bootstrap() {
  const canvas = document.getElementById('renderCanvas');
  const engine = createEngine(canvas);

  const scene = new BABYLON.Scene(engine);
  // Perf: si no haces picking por “hover”, esto ahorra CPU
  scene.skipPointerMovePicking = true;
  scene.constantlyUpdateMeshUnderPointer = false;

  // ============================================================
  // TIME SCALE
  // Tiempo real: 1 segundo real = 1 segundo simulado.
  // Los orbitalPeriod/rotationPeriod están en *días*, así que convertimos:
  //   dtDays = dtSeconds / 86400
  // ============================================================
  const DAYS_PER_REAL_SECOND = 1.0 / 86400.0;

  // ============================================================
  // Fondo negro garantizado
  // ============================================================
  scene.autoClear = true;
  scene.autoClearDepthAndStencil = true;
  scene.clearColor = new BABYLON.Color4(0, 0, 0, 1);
  scene.environmentTexture = null;
  try { engine.getRenderingCanvas().style.background = '#000'; } catch (e) {}

  // ============================================================
  // ROOT del mundo
  // ============================================================
  const worldRoot = new BABYLON.TransformNode('worldRoot', scene);

  // ============================================================
  // Lights + Camera
  // ============================================================
  const lights = setupLights(scene, { hemiIntensity: 0.10 });
  const unitsPerLy =
    (GALAXY?.system && Number.isFinite(GALAXY.system.__LY)) ? GALAXY.system.__LY :
    (Number.isFinite(SYSTEMS?.__LY)) ? SYSTEMS.__LY :
    1_000_000;
  const camCfg = setupCamera(scene, canvas, {
    baseSpeed: 100.0,
    fastMult: 1000.0,
    unitsPerLy,
    // Evita que salga el mini panel antiguo de camera.js (ya tenemos HUD Elite)
    enableModeUI: false
  });
  const camera = camCfg.camera;
  
  const camCtrl = camCfg.controller;
  window.__camCtrl = camCtrl;

  // Shift/turbo ya lo gestiona camera.js (state.isFast). No duplicar handlers aquí.

  // Ajustes cámara (si setupCamera ya los fija, esto solo los sobreescribe)
  camera.position.set(2, 50, -540);
  camera.angularSensibility = 3500;
  camera.inertia = 0.0;
  camera.angularInertia = 0.0;
  camera.keysUp = [87];      // W
  camera.keysDown = [83];    // S
  camera.keysLeft = [65];    // A
  camera.keysRight = [68];   // D
  camera.keysUpward = [32];  // Space
  camera.keysDownward = [17];// Ctrl
  camera.minZ = 1e-6;
  camera.maxZ = 5e9;

  // ============================================================
  // Labels API
  // ============================================================
  const labelsApi = createLabels({ scene, camera, engine });

  // ============================================================
  // Builders (extraídos)
  // ============================================================
  const KM_PER_UNIT_LOCAL = 1e6;
  const starMeshById = new Map();

  const { systemNodes, lyUnits } = buildSystemNodes({ scene, worldRoot, GALAXY, SYSTEMS, labelsApi });
  camCtrl?.setUnitsPerLy?.(lyUnits);
  const starsApi = buildStars({ scene, systemNodes, GALAXY, lights, labelsApi, starMeshById, kmPerUnitLocal: KM_PER_UNIT_LOCAL });
  const { planetSystems } = buildPlanets({ scene, systemNodes, starMeshById, GALAXY, lights, labelsApi, kmPerUnitLocal: KM_PER_UNIT_LOCAL });

  const systemDotScaler = createSystemDotScaler({
    engine, camera, systemNodes,
    opts: { minPx: 2.0, throttleMs: 80 },
  });

  // ============================================================
  // Floating Origin
  // ============================================================
  const floating = createFloatingOrigin({ scene, camera, worldRoot });

  // ============================================================
  // NavGrid (UI helper): anclado al Sol/Al-Lat (NO sigue cámara)
  // ============================================================
  const navGrid = createNavigationGridController({
    scene, worldRoot, camera,
    opts: {
      autoCenter: false,
      followY: false,
      includeYZ: true,
      step: 250000,
      extent: 25000000,
      maxLinesPerAxis: 401,
      rebuildDistance: 0,
    }
  });

  function getSolAnchorLocal() {
    const it = systemNodes.find(s => s?.name === 'Al-Lat' || s?.name === 'Sol');
    return it?.system?.position || BABYLON.Vector3.Zero();
  }
  
  // ============================================================
  // Elite HUD (crea DOM: th/abs/cam/off + toggles + botones)
  // ============================================================
  const eliteHud = createEliteHud({
    camera,
    engine,
    floating,
    labelsApi,
    gridController: navGrid,
    camCtrl,
    // mountId: 'eliteHudMount', // opcional; si no existe, cae a document.body
  });

  // ============================================================
  // HUD toggles
  // ============================================================
  initHudToggles({
    setShowLabels: labelsApi.setShowLabels,
    gridController: navGrid,
  });


  scene.onBeforeRenderObservable.add(() => {
    camCtrl.update(engine.getDeltaTime() * 0.001);

    floating.apply();

    // Mantén el grid anclado al Sol SOLO si está ON
    if (navGrid?.enabled) {
      const a = getSolAnchorLocal();
      const meshes = navGrid.meshes || [];
      for (const m of meshes) {
        if (!m) continue;
        m.position.x = a.x;
        m.position.z = a.z;
      }
    }

    // Sombras dinámicas (si tu lights.js lo tiene)
    if (typeof lights.updateNearestSystemShadows === 'function') {
      lights.updateNearestSystemShadows();
    }

    systemDotScaler.update();
    labelsApi.update(false);

    // Binarios/trinarios (1 updater)
    starsApi?.updateBinaries?.(engine.getDeltaTime() * 0.001);

    // Órbitas
    const dtDays = (engine.getDeltaTime() * 0.001) * DAYS_PER_REAL_SECOND;
    updateOrbits(planetSystems, dtDays);

    // HUD debug floating origin
    if (typeof floating.updateHud === 'function') floating.updateHud();

    // Elite HUD (modo, velocidad, fullscreen icon, etc.)
    eliteHud?.update?.();
  });

  engine.runRenderLoop(() => scene.render());
  window.addEventListener('resize', () => engine.resize());
}