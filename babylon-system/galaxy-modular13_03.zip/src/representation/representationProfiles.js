// representation/representationProfiles.js
// Default pixel-based representation profiles per entity kind.
//
// States:
// - 'none'
// - 'dot'
// - 'sphere_low'
// - 'sphere_high'
//
// NOTE: thresholds are intentionally conservative; tune later.

export function getDefaultRepresentationProfiles() {
  return {
    star: {
      // Stars are always at least a dot, unless you explicitly change logic.
      // Use higher thresholds because stars are usually very bright.
      stateByDiamPx: [
        { max: 2.0, state: 'dot' },
        { max: 34.0, state: 'sphere_low' },
        { max: Infinity, state: 'sphere_high' },
      ],
      dotMinPx: 5.0,
      sphereLowSegments: 14,
      sphereHighSegments: 24,
      sphereDisableLighting: true,
      dotDisableLighting: true,
      lit: false,
    },

    planet: {
      stateByDiamPx: [
        // Always at least a dot (helps targeting/labels at realistic scales)
        { max: 0.8, state: 'dot' },
        { max: 6.0, state: 'dot' },
        { max: 26.0, state: 'sphere_low' },
        { max: Infinity, state: 'sphere_high' },
      ],
      dotMinPx: 3.0,
      sphereLowSegments: 14,
      sphereHighSegments: 22,
      // Max subdivisions to allow when upgrading a planet to planet-editor procedural mesh.
      // Set to 99 to match the editor's max (be aware it's heavy).
      planetEditorMaxSubdivisions: 99,
      // Auto subdivisions (distance + size): controlled by screen-space diameter (px)
      planetEditorAutoSubdiv: true,
      planetEditorSubdivPxMin: 40,     // <=40px: use low level
      planetEditorSubdivPxMax: 1600,   // >=1600px: can reach 99
      planetEditorSubdivLevels: [18, 24, 32, 42, 56, 72, 90, 99],
      planetEditorRefineCooldownMs: 1200,
      planetEditorRefineMinDelta: 8,   // only regen if +8 (or more)
      sphereDisableLighting: false,
      dotDisableLighting: true,
      lit: true,
    },

    moon: {
      stateByDiamPx: [
        { max: 1.0, state: 'dot' },
        { max: 5.0, state: 'dot' },
        { max: 18.0, state: 'sphere_low' },
        { max: Infinity, state: 'sphere_high' },
      ],
      dotMinPx: 3.0,
      sphereLowSegments: 10,
      sphereHighSegments: 16,
	  planetEditorMaxSubdivisions: 99,
      planetEditorAutoSubdiv: true,
      planetEditorSubdivPxMin: 35,
      planetEditorSubdivPxMax: 1200,
      planetEditorSubdivLevels: [18, 24, 32, 42, 56, 72, 90, 99],
      planetEditorRefineCooldownMs: 1200,
      planetEditorRefineMinDelta: 8,
      sphereDisableLighting: false,
      dotDisableLighting: true,
      lit: true,
    },

    asteroid: {
      stateByDiamPx: [
        { max: 1.2, state: 'none' },
        { max: 4.0, state: 'dot' },
        { max: 14.0, state: 'sphere_low' },
        { max: Infinity, state: 'sphere_high' },
      ],
      dotMinPx: 2.5,
      sphereLowSegments: 8,
      sphereHighSegments: 12,
      sphereDisableLighting: false,
      dotDisableLighting: true,
      lit: true,
    },

    comet: {
      stateByDiamPx: [
        { max: 1.2, state: 'none' },
        { max: 4.0, state: 'dot' },
        { max: 14.0, state: 'sphere_low' },
        { max: Infinity, state: 'sphere_high' },
      ],
      dotMinPx: 2.5,
      sphereLowSegments: 8,
      sphereHighSegments: 12,
      sphereDisableLighting: false,
      dotDisableLighting: true,
      lit: true,
    },

    artificialSatellite: {
      stateByDiamPx: [
        { max: 2.0, state: 'none' },
        { max: 8.0, state: 'dot' },
        { max: 20.0, state: 'sphere_low' },
        { max: Infinity, state: 'sphere_high' },
      ],
      dotMinPx: 2.0,
      sphereLowSegments: 8,
      sphereHighSegments: 12,
      sphereDisableLighting: false,
      dotDisableLighting: true,
      lit: true,
    },
  };
}
