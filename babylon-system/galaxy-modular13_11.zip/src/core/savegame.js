// src/core/savegame.js
// Guarda/recupera estado del viaje en localStorage:
// - floating origin offset
// - posición local de cámara
// - orientación de cámara (quaternion o euler)
// - simDays (opcional)

const KEY = "gm13_save_v1";

export function saveState({ floating, camera, simDays }) {
  try {
    const off = floating?.originOffset || { x: 0, y: 0, z: 0 };
    const p = camera?.position || { x: 0, y: 0, z: 0 };

    const q = camera?.rotationQuaternion || null;
    const r = camera?.rotation || null;

    const cameraRotQ = q ? { x: q.x, y: q.y, z: q.z, w: q.w } : null;
    // Fallback euler (en radianes)
    const cameraRotE = (!q && r) ? { x: r.x, y: r.y, z: r.z } : null;

    localStorage.setItem(KEY, JSON.stringify({
      v: 2,
      savedAt: Date.now(),
      originOffset: { x: off.x, y: off.y, z: off.z },
      cameraLocal: { x: p.x, y: p.y, z: p.z },
      cameraRotQ,
      cameraRotE,
      simDays: Number.isFinite(simDays) ? simDays : 0,
    }));
    return true;
  } catch (e) {
    console.warn("Save failed:", e);
    return false;
  }
}

export function loadState() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const s = JSON.parse(raw);
    if (!s) return null;
    // Aceptamos v1/v2 (v1 no tenía rotación)
    if (s.v !== 1 && s.v !== 2) return null;
    return s;
  } catch {
    return null;
  }
}

export function clearState() {
  try { localStorage.removeItem(KEY); } catch {}
}

/**
 * Reaplica un save sin depender del orden de arranque:
 *  - desplaza los hijos del worldRoot por el originOffset guardado (floatingfix)
 *  - fija originOffset y camera.position
 *  - fija orientación de cámara (quaternion/euler)
 *  - restaura simDays si se proporciona setter
 */
export function applyLoadedState({ state, worldRoot, floating, camera, setSimDays }) {
  if (!state) return false;

  const S = new BABYLON.Vector3(
    state.originOffset?.x || 0,
    state.originOffset?.y || 0,
    state.originOffset?.z || 0
  );

  // 1) Rebase del mundo: kids -= S  (evita jitter por locales enormes)
  const kids = worldRoot?.getChildren?.() || [];
  for (let i = 0; i < kids.length; i++) {
    const n = kids[i];
    if (n?.position?.subtractInPlace) n.position.subtractInPlace(S);
  }

  // 2) Set offset y cámara local
  if (floating?.originOffset?.copyFrom) floating.originOffset.copyFrom(S);

  if (camera?.position?.set) {
    const c = state.cameraLocal || { x: 0, y: 0, z: 0 };
    camera.position.set(c.x || 0, c.y || 0, c.z || 0);
  }

  // 3) Orientación cámara
  if (camera) {
    if (state.cameraRotQ) {
      if (!camera.rotationQuaternion) {
        camera.rotationQuaternion = new BABYLON.Quaternion(
          state.cameraRotQ.x, state.cameraRotQ.y, state.cameraRotQ.z, state.cameraRotQ.w
        );
      } else {
        camera.rotationQuaternion.set(
          state.cameraRotQ.x, state.cameraRotQ.y, state.cameraRotQ.z, state.cameraRotQ.w
        );
      }
    } else if (state.cameraRotE && camera.rotation) {
      camera.rotation.set(state.cameraRotE.x, state.cameraRotE.y, state.cameraRotE.z);
    }

    // Fuerza matrices actualizadas para evitar “salto” al primer frame
    try { camera.computeWorldMatrix(true); } catch (_) {}
  }

  // 4) Tiempo orbital (opcional)
  if (typeof setSimDays === "function" && Number.isFinite(state.simDays)) {
    setSimDays(state.simDays);
  }

  return true;
}