// bodies/orbitAnimator.js
// Anima órbitas y rotaciones.

export function updateOrbits(planetSystems, simDays) {
  if (!Array.isArray(planetSystems)) return;
  simDays = Number(simDays) || 0;
  
  const TAU = Math.PI * 2;

  function normAngle(a) {
    a = a % TAU;
    if (a < 0) a += TAU;
    return a;
  }

  // Kepler solver: E - e sin E = M
  function solveKeplerE(M, e) {
    M = normAngle(M);
    e = Math.max(0, Math.min(0.999999, e || 0));
    let E = (e < 0.8) ? M : Math.PI;
    for (let i = 0; i < 8; i++) {
      const f = E - e * Math.sin(E) - M;
      const fp = 1 - e * Math.cos(E);
      E = E - f / Math.max(1e-8, fp);
    }
    return E;
  }

  function applyOrbitPosition(orbitNode, bodyMesh) {
    const md = orbitNode?.metadata;
    if (!md) return;
    const a = Number(md.aU);
    const e = Number(md.e);
    const M = Number(md.mean);
    if (!Number.isFinite(a) || !Number.isFinite(e) || !Number.isFinite(M)) return;

    // PERF: circular fast-path (avoids Kepler iterations)
    let r = a;
    let nu = normAngle(M);
    if (Math.abs(e) >= 1e-4) {
      const E = solveKeplerE(M, e);
      const cosE = Math.cos(E);
      r = a * (1 - e * cosE);

      // True anomaly (cache sqrt terms per orbit)
      if (md._eCache !== e) {
        md._eCache = e;
        md._sq1pe = Math.sqrt(1 + e);
        md._sq1me = Math.sqrt(1 - e);
      }
      const sq1pe = md._sq1pe;
      const sq1me = md._sq1me;
      nu = 2 * Math.atan2(sq1pe * Math.sin(E * 0.5), sq1me * Math.cos(E * 0.5));
    }

    const x = r * Math.cos(nu);
    const z = r * Math.sin(nu);

    // En coords del plano orbital local (orbitArg ya contiene ω)
    if (bodyMesh) bodyMesh.position.set(x, 0, z);
    else orbitNode.position.set(x, 0, z);
  }

  function stepOrbitAbs(orbitNode, bodyMesh, tDays) {
    const md = orbitNode?.metadata;
    if (!md) return;
    const n = Number(md.n);
    const dir = Number(md.dir || 1);
    if (!Number.isFinite(n)) return;
    const mean0 = Number(md.mean0);
    const base = Number.isFinite(mean0) ? mean0 : Number(md.mean || 0);
    md.mean = base + (dir * n * tDays);
    applyOrbitPosition(orbitNode, bodyMesh);
  }

  function stepSpin(mesh, dt) {
    const md = mesh?.metadata;
    if (!md) return;
    const spin = Number(md.spin);
    if (!Number.isFinite(spin)) return;
    const axis = md.spinAxis || BABYLON.Axis.Y;
    mesh.rotate(axis, spin * dt, BABYLON.Space.LOCAL);
  }

  function updateSatelliteList(list, tDays, dtDays) {
    if (!Array.isArray(list)) return;
    for (const s of list) {
      const orbit = s?.orbit;
      const mesh = s?.mesh;
      if (orbit) stepOrbitAbs(orbit, mesh, tDays);
      if (mesh) stepSpin(mesh, dtDays);
      updateSatelliteList(s?.satellites || s?.moons, tDays, dtDays);
    }
  }

  for (const sys of planetSystems) {
    const planets = sys?.planets || [];
    for (const obj of planets) {
      const orbit = obj?.orbit;
      const planet = obj?.planet;

      if (orbit) stepOrbitAbs(orbit, planet, simDays);
      if (planet) stepSpin(planet, 0); // spin lo llevaremos desde createScene con dtDays real
 
      updateSatelliteList(obj?.satellites || obj?.moons, simDays, 0);
    }
  }
}