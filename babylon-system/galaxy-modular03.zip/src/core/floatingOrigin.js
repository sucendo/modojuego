export function createFloatingOrigin({ scene, camera, worldRoot, thresh, rebaseGrid }){
  const originOffset = new BABYLON.Vector3(0,0,0);

  let THRESH = (Number.isFinite(thresh) && thresh > 0) ? thresh : 20_000;
  let REBASE_GRID = (Number.isFinite(rebaseGrid) && rebaseGrid > 0) ? rebaseGrid : 1000;

  // Optional URL params: ?thresh=20000&grid=1000 (values in scene units)
  try{
    const u = new URL(location.href);
    const t = Number(u.searchParams.get("thresh"));
    const g = Number(u.searchParams.get("grid"));
    if (Number.isFinite(t) && t > 0) THRESH = t;
    if (Number.isFinite(g) && g > 0) REBASE_GRID = g;
  }catch(_){}

  const thEl  = document.getElementById("th");
  const offEl = document.getElementById("off");
  const camEl = document.getElementById("cam");
  const absEl = document.getElementById("abs");

  function updateHud(){
    if (thEl)  thEl.textContent  = `${THRESH.toLocaleString("es-ES")} (grid ${REBASE_GRID.toLocaleString("es-ES")})`;
    if (offEl) offEl.textContent = `${originOffset.x.toFixed(0)}, ${originOffset.y.toFixed(0)}, ${originOffset.z.toFixed(0)}`;
    if (camEl) camEl.textContent = `${camera.position.x.toFixed(0)}, ${camera.position.y.toFixed(0)}, ${camera.position.z.toFixed(0)}`;
    if (absEl){
      const a = getCameraAbsolute();
      absEl.textContent = `${a.x.toFixed(0)}, ${a.y.toFixed(0)}, ${a.z.toFixed(0)}`;
    }
  }

  function apply(){
    const p = camera.position;
    const len = p.length();
    if (len < THRESH) return;

    // Snap shift to grid (like many "infinite world" demos)
    const GRID = REBASE_GRID;
    const sx = Math.round(p.x / GRID) * GRID;
    const sy = Math.round(p.y / GRID) * GRID;
    const sz = Math.round(p.z / GRID) * GRID;
    const shift = new BABYLON.Vector3(sx, sy, sz);
    if (shift.lengthSquared() < 1e-9) return;

    originOffset.addInPlace(shift);
    worldRoot.position.subtractInPlace(shift);
    camera.position.subtractInPlace(shift);
  }

  function getCameraAbsolute(){
    return camera.position.add(originOffset);
  }

  return {
    originOffset,
    apply,
    updateHud,
    getCameraAbsolute,
    get thresh(){ return THRESH; },
    get rebaseGrid(){ return REBASE_GRID; },
  };
}
