// Labels (Elite-like arcs + glow) MOVED OUT of createScene.js
// DOM HUD labels: 1 HUD, anchored to the selected body (closest to screen center),
// resized by apparent size (projected radius), and placed around the body.
export function createLabels({ scene, camera, engine }){
  const labelsById = new Map(); // key -> { kind, mesh, text, system, planet }
  let showLabels = true;

  const HUD_ID = "sciHud";
  const STYLE_ID = "sciHudStyle";

  const AU_KM = 149597870.7;
  function formatAU(au){
    if (!isFinite(au)) return "—";
    const v = Math.abs(au);
    if (v >= 1000) return au.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",") + " AU";
    if (v >= 100)  return au.toFixed(1) + " AU";
    if (v >= 10)   return au.toFixed(2) + " AU";
    return au.toFixed(3) + " AU";
  }

  function ensureHud(){
    let root = document.getElementById(HUD_ID);
    if (!root){
      root = document.createElement("div");
      root.id = HUD_ID;
      document.body.appendChild(root);
    }

    if (!document.getElementById(STYLE_ID)){
      const st = document.createElement("style");
      st.id = STYLE_ID;
      st.textContent = `
        :root{
          --ui-color:#00ffcc;
          --glow: 0 0 10px rgba(0, 255, 204, 0.5), 0 0 20px rgba(0, 255, 204, 0.3);
        }
        #${HUD_ID}{
          position: fixed;
          left: 0;
          top: 0;
          z-index: 50;
          pointer-events: none;
          user-select: none;
          transform: translate(-50%, -50%);
          will-change: transform, left, top;
        }
        #${HUD_ID}[data-hidden="1"]{ display:none; }

        #${HUD_ID} .hud-container{
          position: relative;
          display: flex;
          align-items: center;
          gap: 18px;
          color: var(--ui-color);
          font-family: 'Courier New', Courier, monospace;
          animation: sciHudPulse 4s infinite ease-in-out;
        }

        /* scanner size is dynamic */
        #${HUD_ID} .scanner{
          position: relative;
          width: var(--scannerSize, 160px);
          height: var(--scannerSize, 160px);
          border: 2px solid rgba(0, 255, 204, 0.2);
          border-radius: 50%;
          display:flex;
          justify-content:center;
          align-items:center;
        }
        #${HUD_ID} .scanner::before{
          content:'';
          position:absolute;
          inset: 0;
          border:4px solid transparent;
          border-left-color: var(--ui-color);
          border-top-color: var(--ui-color);
          border-radius:50%;
          box-shadow: var(--glow);
          transform: rotate(-45deg);
        }
        #${HUD_ID} .star{
          width:4px;
          height:4px;
          background:#fff;
          border-radius:50%;
          box-shadow: 0 0 15px 2px #fff, var(--glow);
          position:relative;
        }
        #${HUD_ID} .star::before, #${HUD_ID} .star::after{
          content:'';
          position:absolute;
          background:white;
          top:50%;
          left:50%;
          transform: translate(-50%, -50%);
          box-shadow: var(--glow);
        }
        #${HUD_ID} .star::before{ width:64px; height:1px; }
        #${HUD_ID} .star::after{  width:1px; height:64px; }

        #${HUD_ID} .info-panel{
          border-left: 2px solid var(--ui-color);
          padding-left: 14px;
          position: relative;
          min-width: 220px;
        }
        #${HUD_ID} .info-panel::before{
          content:'';
          position:absolute;
          top: 32px;
          left: 0;
          width: 220px;
          height: 2px;
          background: var(--ui-color);
          box-shadow: var(--glow);
        }
        #${HUD_ID} .location{
          font-size: 18px;
          font-weight: bold;
          letter-spacing: 1px;
          margin-bottom: 14px;
          text-shadow: var(--glow);
          text-transform: uppercase;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 260px;
        }
        #${HUD_ID} .distance{
          font-size: 20px;
          display:block;
        }
        #${HUD_ID} .timer{
          font-size: 16px;
          opacity: 0.8;
          margin-top: 4px;
        }
        @keyframes sciHudPulse{
          0%{ opacity: 1; }
          50%{ opacity: .7; }
          100%{ opacity: 1; }
        }
      `;
      document.head.appendChild(st);
    }

    if (!root.dataset.ready){
      root.innerHTML = `
        <div class="hud-container" id="${HUD_ID}_c">
          <div class="scanner" id="${HUD_ID}_scanner"><div class="star"></div></div>
          <div class="info-panel">
            <div class="location" id="${HUD_ID}_name">—</div>
            <div class="data-row">
              <span class="distance" id="${HUD_ID}_dist">—</span>
              <div class="timer" id="${HUD_ID}_kind">—</div>
            </div>
          </div>
        </div>
      `;
      root.dataset.ready = "1";
    }

    return {
      root,
      cont: document.getElementById(`${HUD_ID}_c`),
      scanner: document.getElementById(`${HUD_ID}_scanner`),
      name: document.getElementById(`${HUD_ID}_name`),
      dist: document.getElementById(`${HUD_ID}_dist`),
      kind: document.getElementById(`${HUD_ID}_kind`),
    };
  }

  function registerLabel(id, text, kind, mesh, extra){
    if (!mesh) return null;
    let key = String(id || "");
    if (!key) return null;

    if (!key.includes(":")){
      const sys = extra && extra.system ? extra.system : "";
      const pl  = extra && extra.planet ? extra.planet : "";
      key = `${kind}:${sys}:${pl}:${key}`;
    }

    let meta = labelsById.get(key);
    if (!meta){
      meta = { kind, mesh, text: String(text || ""), system: extra && extra.system, planet: extra && extra.planet };
      labelsById.set(key, meta);
    } else {
      meta.kind = kind || meta.kind;
      meta.mesh = mesh || meta.mesh;
      meta.text = String(text || meta.text || "");
    }
    return key;
  }

  function setShowLabels(v){
    showLabels = !!v;
    const hud = ensureHud();
    if (hud && hud.root){
      hud.root.dataset.hidden = showLabels ? "0" : "1";
    }
  }

  function update(_debugFlag){
    if (!camera || !engine) return;
    const hud = ensureHud();
    if (!hud || !hud.root) return;

    if (!showLabels){
      hud.root.dataset.hidden = "1";
      return;
    }
    hud.root.dataset.hidden = "0";

    const w = engine.getRenderWidth(true);
    const h = engine.getRenderHeight(true);
    if (w <= 2 || h <= 2) return;

    const centerX = w * 0.5;
    const centerY = h * 0.5;

    let best = null;
    
    let bestD2 = Infinity;
    const proj = new BABYLON.Vector3();

    for (const meta of labelsById.values()){
      const m = meta && meta.mesh;
      if (!m || m.isDisposed?.()) continue;
      if (!m.isEnabled?.() || !m.isVisible) continue;

      const wp = (typeof m.getAbsolutePosition === "function") ? m.getAbsolutePosition() : m.position;

      BABYLON.Vector3.ProjectToRef(
        wp,
        BABYLON.Matrix.IdentityReadOnly,
        scene.getTransformMatrix(),
        camera.viewport.toGlobal(w, h),
        proj
      );

      if (!isFinite(proj.x) || !isFinite(proj.y) || proj.z < 0 || proj.z > 1) continue;
      if (proj.x < 0 || proj.x > w || proj.y < 0 || proj.y > h) continue;

      const dx = proj.x - centerX;
      const dy = proj.y - centerY;
      const d2 = dx*dx + dy*dy;
      if (d2 < bestD2){
        bestD2 = d2;
        best = meta;
      }
    }

    if (!best){
      hud.root.dataset.hidden = "1";
      return;
    }

    // 1) Anchor HUD around the target (screen-space)
    // Place HUD center on object center; the scanner ring will surround it.
    const m = best.mesh;
    const wp = (typeof m.getAbsolutePosition === "function") ? m.getAbsolutePosition() : m.position;
    BABYLON.Vector3.ProjectToRef(
      wp,
      BABYLON.Matrix.IdentityReadOnly,
      scene.getTransformMatrix(),
      camera.viewport.toGlobal(w, h),
      proj
    );

    hud.root.style.left = `${proj.x}px`;
    hud.root.style.top  = `${proj.y}px`;

    // 2) Autosize scanner based on apparent radius (like your star autosize)
    // scannerSize ~= projectedDiameter + margin
    let scannerPx = 160;
    try{
      const bi = (typeof m.getBoundingInfo === "function") ? m.getBoundingInfo() : null;
      const bs = bi && bi.boundingSphere ? bi.boundingSphere : null;
      if (bs){
        const rWorld = bs.radiusWorld;
        const camPos = camera.globalPosition || camera.position;
        const d = BABYLON.Vector3.Distance(camPos, wp);
        const vh = engine.getRenderHeight(true);
        const fov = (typeof camera.fov === "number") ? camera.fov : 0.8;
        const tanHalf = Math.tan(fov * 0.5);
        if (d > 1e-6){
          const projR = (rWorld / (d * tanHalf)) * (vh/2); // pixels
          const margin = 26; // ring margin around the object
          scannerPx = (projR * 2) + margin;
        }
      }
    }catch(_){}

    // clamp for readability / performance
    scannerPx = Math.max(110, Math.min(360, scannerPx));
    hud.root.style.setProperty("--scannerSize", `${scannerPx.toFixed(1)}px`);

    // 3) Update text
    const name = String(best.text || "—").toUpperCase();
    const kind = String(best.kind || "—").toUpperCase();

    const camPos = camera.globalPosition || camera.position;
    const dUnits = BABYLON.Vector3.Distance(camPos, wp);
    const kmPerUnit = m?.metadata?.kmPerUnit || 1e6;
    const au = (dUnits * kmPerUnit) / AU_KM;

    if (hud.name) hud.name.textContent = name;
    if (hud.dist) hud.dist.textContent = formatAU(au);
    if (hud.kind) hud.kind.textContent = kind;
  }

  return {
    registerLabel,
    setShowLabels,
    update,
    labelsById,
  };
}