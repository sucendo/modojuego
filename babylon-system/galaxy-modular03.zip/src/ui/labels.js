// labels.js
// Elite-like HUD (DOM) anchored to the selected target (closest to screen center),
// Orbitron + teal glow styling, AU distance, and scanner ring that auto-resizes
// based on the target's apparent size (projected bounding sphere).
//
// Performance: single DOM element (no per-object DOM nodes).
// Units: uses mesh.metadata.kmPerUnit; fallback 1e6 km/unit.

export function createLabels({ scene, camera, engine }) {
  const labelsById = new Map(); // key -> { kind, mesh, text, system, planet }
  let showLabels = true;

  const HUD_ID = "sciHud";
  const STYLE_ID = "sciHudStyle";

  const AU_KM = 149597870.7;

  function formatAU(au) {
    if (!isFinite(au)) return "—";
    const v = Math.abs(au);
    if (v >= 1000) return au.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",") + " AU";
    if (v >= 100)  return au.toFixed(1) + " AU";
    if (v >= 10)   return au.toFixed(2) + " AU";
    return au.toFixed(3) + " AU";
  }

  function ensureHud() {
    let root = document.getElementById(HUD_ID);
    if (!root) {
      root = document.createElement("div");
      root.id = HUD_ID;
      document.body.appendChild(root);
    }

    if (!document.getElementById(STYLE_ID)) {
      const st = document.createElement("style");
      st.id = STYLE_ID;
      st.textContent = `
@import url("https://fonts.googleapis.com/css2?family=Orbitron:wght@700&display=swap");

:root{
  --ui-color:#00ffcc;
  --glow: 0 0 5px #00ffcc, 0 0 10px #00ffcc, 0 0 15px #008080, 0 0 20px #008080;
}

#${HUD_ID}{
  position: fixed;
  left: 0;
  top: 0;
  z-index: 50;
  pointer-events: none;
  user-select: none;
  width: 0;
  height: 0;
  display: block;
}
#${HUD_ID}[data-hidden="1"]{ display:none; }

#${HUD_ID} .anchor{
  position: absolute;
  left: 0;
  top: 0;
  transform: translate(-50%, -50%);
  will-change: transform;
  animation: sciHudPulse 4s infinite ease-in-out;
}

#${HUD_ID} .scanner{
  position: absolute;
  left: 0;
  top: 0;
  width: var(--scannerSize, 160px);
  height: var(--scannerSize, 160px);
  border: 2px solid rgba(0, 255, 204, 0.18);
  border-radius: 50%;
  transform: translate(-50%, -50%);
  box-sizing: border-box;
}

#${HUD_ID} .scanner::before{
  content:'';
  position:absolute;
  inset: 0;
  border: 4px solid transparent;
  border-left-color: var(--ui-color);
  border-top-color: var(--ui-color);
  border-radius:50%;
  box-shadow: var(--glow);
  transform: rotate(-45deg);
  box-sizing: border-box;
}

/* Ticks around the ring (no central cross) */
#${HUD_ID} .ticks{
  position:absolute;
  inset:0;
  pointer-events:none;
}
#${HUD_ID} .t{
  position:absolute;
  background: rgba(255,255,255,0.95);
  box-shadow: var(--glow);
  opacity: 0.95;
}

/* Length and thickness scale with scanner size */
#${HUD_ID}{
  --tickLen: clamp(14px, calc(var(--scannerSize,160px) * 0.22), 90px);
  --tickTh:  clamp(1px,  calc(var(--scannerSize,160px) * 0.006), 3px);
}

/* North / South: horizontal ticks on the ring */
#${HUD_ID} .tN, #${HUD_ID} .tS{
  width: var(--tickLen);
  height: var(--tickTh);
  left: 50%;
  transform: translateX(-50%);
}
#${HUD_ID} .tN{ top: -1px; }
#${HUD_ID} .tS{ bottom: -1px; }

/* East / West: vertical ticks on the ring */
#${HUD_ID} .tE, #${HUD_ID} .tW{
  width: var(--tickTh);
  height: var(--tickLen);
  top: 50%;
  transform: translateY(-50%);
}
#${HUD_ID} .tE{ right: -1px; }
#${HUD_ID} .tW{ left: -1px; }
#${HUD_ID} .connector{
  position: absolute;
  left: calc(var(--scannerSize, 160px) * 0.5);
  top: 0;
  width: clamp(160px, 22vw, 320px);
  height: 0;
  border-top: 2px solid rgba(0,255,204,0.75);
  box-shadow: var(--glow);
  transform: translateY(-50%);
}
#${HUD_ID} .connector::before{
  content:'';
  position:absolute;
  left: 0;
  top: -18px;
  width: 2px;
  height: 36px;
  background: rgba(0,255,204,0.85);
  box-shadow: var(--glow);
}

#${HUD_ID} .info{
  position: absolute;
  left: calc(var(--scannerSize, 160px) * 0.5 + 18px);
  top: 0;
  transform: translateY(-50%);
  color: var(--ui-color);
  font-family: 'Orbitron', sans-serif;
  letter-spacing: 0.4px;
  text-shadow: var(--glow);
  min-width: 200px;
}

#${HUD_ID} .info .frame{
  position: relative;
  padding-left: 6px; /* tighter */
}

#${HUD_ID} .name{
  font-size: 13px;
  font-weight: 700;
  text-transform: uppercase;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 300px;
  display: inline-block;
  margin-top: 10px;
}

#${HUD_ID} .dist{
  font-size: 10px;
  display: block;
  letter-spacing: 0.4px;
  opacity: 0.95;
  margin-top: 6px;
}

#${HUD_ID} .kind{
  font-size: 10px;
  opacity: 0.8;
  margin-top: 4px;
  letter-spacing: 0.6px;
}


@keyframes sciHudPulse{
  0%{ opacity: 1; }
  50%{ opacity: .72; }
  100%{ opacity: 1; }
}
      `;
      document.head.appendChild(st);
    }

    if (!root.dataset.ready) {
      root.innerHTML = `
        <div class="anchor" id="${HUD_ID}_anchor">
          <div class="scanner" id="${HUD_ID}_scanner">
            <div class="ticks">
              <span class="t tN"></span><span class="t tS"></span>
              <span class="t tE"></span><span class="t tW"></span>
            </div>
          </div>
          <div class="connector" id="${HUD_ID}_connector"></div>
          <div class="info" id="${HUD_ID}_info">
            <div class="frame">
              <div class="name" id="${HUD_ID}_name">—</div>
              <div class="dist" id="${HUD_ID}_dist">—</div>
              <div class="kind" id="${HUD_ID}_kind">—</div>
            </div>
          </div>
        </div>
      `;
      root.dataset.ready = "1";
    }

    return {
      root,
      name: document.getElementById(`${HUD_ID}_name`),
      dist: document.getElementById(`${HUD_ID}_dist`),
      kind: document.getElementById(`${HUD_ID}_kind`),
    };
  }

  // Some registrations may pass TransformNodes. For sizing we want an AbstractMesh with bounding info.
  function resolveSizingMesh(node) {
    if (!node) return null;
    if (typeof node.getBoundingInfo === "function") return node;
    try {
      if (typeof node.getChildMeshes === "function") {
        const kids = node.getChildMeshes(false);
        for (const k of kids) {
          if (k && !k.isDisposed?.() && typeof k.getBoundingInfo === "function") return k;
        }
      }
    } catch (_) {}
    return null;
  }

  function registerLabel(id, text, kind, mesh, extra) {
    if (!mesh) return null;
    let key = String(id || "");
    if (!key) return null;

    if (!key.includes(":")) {
      const sys = extra && extra.system ? extra.system : "";
      const pl  = extra && extra.planet ? extra.planet : "";
      key = `${kind}:${sys}:${pl}:${key}`;
    }

    let meta = labelsById.get(key);
    if (!meta) {
      meta = { kind, mesh, text: String(text || ""), system: extra && extra.system, planet: extra && extra.planet };
      labelsById.set(key, meta);
    } else {
      meta.kind = kind || meta.kind;
      meta.mesh = mesh || meta.mesh;
      meta.text = String(text || meta.text || "");
    }
    return key;
  }

  function setShowLabels(v) {
    showLabels = !!v;
    const hud = ensureHud();
    if (hud && hud.root) hud.root.dataset.hidden = showLabels ? "0" : "1";
  }

  function computeScannerPx(sizingMesh, worldPos) {
    const BASE = 50;
    const MINP = 20;
    const MAXP = 420;
    let px = BASE;

    try {
      if (sizingMesh && sizingMesh.computeWorldMatrix) sizingMesh.computeWorldMatrix(true);

      const bi = (sizingMesh && typeof sizingMesh.getBoundingInfo === "function") ? sizingMesh.getBoundingInfo() : null;
      const bs = bi && bi.boundingSphere ? bi.boundingSphere : null;
      if (bs) {
        const rWorld = bs.radiusWorld || 0;
        const camPos = camera.globalPosition || camera.position;
        const d = BABYLON.Vector3.Distance(camPos, worldPos);

        const vh = engine.getRenderHeight(true);
        const fov = (typeof camera.fov === "number") ? camera.fov : 0.8;
        const tanHalf = Math.tan(fov * 0.5);

        if (d > 1e-6 && rWorld > 0) {
          const projR = (rWorld / (d * tanHalf)) * (vh / 2);
          const margin = 28;
          px = (projR * 2) + margin;
        }
      }
    } catch (_) {}

    return Math.max(MINP, Math.min(MAXP, px));
  }

  function update(_debugFlag) {
    if (!camera || !engine || !scene) return;

    const hud = ensureHud();
    if (!hud || !hud.root) return;

    if (!showLabels) {
      hud.root.dataset.hidden = "1";
      return;
    }
    hud.root.dataset.hidden = "0";

    const w = engine.getRenderWidth(true);
    const h = engine.getRenderHeight(true);
    if (w <= 2 || h <= 2) return;

    const centerX = w * 0.5;
    const centerY = h * 0.5;

    let best = null;
    let bestD2 = Infinity;
    const proj = new BABYLON.Vector3();

    for (const meta of labelsById.values()) {
      const node = meta && meta.mesh;
      if (!node) continue;

      const sizingMesh = resolveSizingMesh(node) || node;

      if (sizingMesh && sizingMesh.isDisposed?.()) continue;
      const visOK = (sizingMesh ? (sizingMesh.isEnabled?.() && sizingMesh.isVisible) : (node.isEnabled?.() && node.isVisible));
      if (!visOK) continue;

      const wp = (typeof node.getAbsolutePosition === "function")
        ? node.getAbsolutePosition()
        : ((sizingMesh && typeof sizingMesh.getAbsolutePosition === "function")
            ? sizingMesh.getAbsolutePosition()
            : (node.position || sizingMesh?.position));

      if (!wp) continue;

      BABYLON.Vector3.ProjectToRef(
        wp,
        BABYLON.Matrix.IdentityReadOnly,
        scene.getTransformMatrix(),
        camera.viewport.toGlobal(w, h),
        proj
      );

      if (!isFinite(proj.x) || !isFinite(proj.y) || proj.z < 0 || proj.z > 1) continue;
      if (proj.x < 0 || proj.x > w || proj.y < 0 || proj.y > h) continue;

      const dx = proj.x - centerX;
      const dy = proj.y - centerY;
      const d2 = dx * dx + dy * dy;

      if (d2 < bestD2) {
        bestD2 = d2;
        best = meta;
      }
    }

    if (!best) {
      hud.root.dataset.hidden = "1";
      return;
    }

    const node = best.mesh;
    const sizingMesh = resolveSizingMesh(node) || node;

    const wp = (typeof node.getAbsolutePosition === "function")
      ? node.getAbsolutePosition()
      : ((sizingMesh && typeof sizingMesh.getAbsolutePosition === "function")
          ? sizingMesh.getAbsolutePosition()
          : (node.position || sizingMesh?.position));

    BABYLON.Vector3.ProjectToRef(
      wp,
      BABYLON.Matrix.IdentityReadOnly,
      scene.getTransformMatrix(),
      camera.viewport.toGlobal(w, h),
      proj
    );

    hud.root.style.left = `${proj.x}px`;
    hud.root.style.top  = `${proj.y}px`;

    const scannerPx = computeScannerPx(sizingMesh, wp);
    hud.root.style.setProperty("--scannerSize", `${scannerPx.toFixed(1)}px`);

    const name = String(best.text || "—").toUpperCase();
    const kind = String(best.kind || "—").toUpperCase();

    const camPos = camera.globalPosition || camera.position;
    const dUnits = BABYLON.Vector3.Distance(camPos, wp);
    const kmPerUnit = (sizingMesh?.metadata?.kmPerUnit ?? node?.metadata?.kmPerUnit) || 1e6;
    const au = (dUnits * kmPerUnit) / AU_KM;

    if (hud.name) hud.name.textContent = name;
    if (hud.dist) hud.dist.textContent = formatAU(au);
    if (hud.kind) hud.kind.textContent = kind;
  }

  return { registerLabel, setShowLabels, update, labelsById };
}
