export function setupCamera(scene, canvas){
  const camera = new BABYLON.UniversalCamera(
    "cam",
    new BABYLON.Vector3(0, 3, -18),
    scene
  );
  camera.attachControl(canvas, true);

  camera.speed = 100.0;

  // Si ya tenías “modo rápido”, mantenemos los mismos valores y devolvemos helpers
  const BASE_SPEED = 100.0;
  const FAST_MULT = 20.0;

  // Pointer lock (si lo tenías en createScene)
  canvas.addEventListener("pointerdown", () => {
    canvas.requestPointerLock?.();
  });

  return { camera, BASE_SPEED, FAST_MULT };
}