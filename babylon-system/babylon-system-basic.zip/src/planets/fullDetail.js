// src/planets/fullDetail.js
// Paso 11: "Full detail on demand" fuera del main.js
// - Regenera SOLO el body rocky JSON objetivo a una subdivisión fija (surface mode)
// - No depende de helpers antiguos (applyShadows/linkToLight/createRings/orbitLockedBodyName)

export function createFullDetailSystem({
  BABYLON,
  scn,
  planetParamsByName,
  getDefaultPlanetParams,     // () => defaultPlanetParams
  buildRuntimePlanetParams,
  createJsonPlanet,
  includeMeshInBodyLight,
  shadowGen,
  relinkMoonsParent,          // (parentKey,newParentMesh)
  lockOrbitToBody,            // (body)
  getOrbitLockedBodyName,     // () => string|null
}) {
  function _isRockyJsonBody(b) {
    if (!b || !b.def) return false;
    if (!b.def.useJsonPlanet) return false;
    return !(b.def.gasGiant || b.def.rocky === false);
  }

  function _applyShadows(body, land, ocean) {
    // Mantén el mismo criterio que vienes usando:
    // - Core system: sombras reales
    // - Extra systems: sin coste de sombras
    const isCore = !!body?.isCore;
    try {
      if (isCore && shadowGen && land) {
        shadowGen.addShadowCaster(land);
        land.receiveShadows = true;
      } else if (land) {
        land.receiveShadows = false;
      }
    } catch (e) {}
    try { if (ocean) ocean.receiveShadows = false; } catch (e) {}
  }

  function _linkToLight(body, land, ocean) {
    try { if (land) includeMeshInBodyLight(land, body); } catch (e) {}
    try { if (ocean) includeMeshInBodyLight(ocean, body); } catch (e) {}
  }

  function ensureFullDetailJsonBody(b, forceSubdiv = 8) {
    try {
      if (!_isRockyJsonBody(b)) return;
      const defaultPlanetParams = getDefaultPlanetParams ? getDefaultPlanetParams() : null;
      if (!defaultPlanetParams) return;

      // Si ya tiene suficiente subdiv, no hacemos nada
      if (b.genParams && typeof b.genParams.subdivisions === "number" && b.genParams.subdivisions >= forceSubdiv) {
        return;
      }

      const hasSpecific = !!b.def.jsonFile && planetParamsByName && planetParamsByName.has(b.def.name);
      const base = hasSpecific ? planetParamsByName.get(b.def.name) : defaultPlanetParams;

      const hiParams = buildRuntimePlanetParams(base, b.def, {
        maxSubdiv: forceSubdiv,
        minSubdiv: forceSubdiv,
        forceSeedFromName: !hasSpecific,
      });

      const oldMesh = b.farMesh;
      const oldOcean = b.ocean;
      const oldRing = b.ring;
      const parentNode = b.orbitNode || (oldMesh ? oldMesh.parent : null);

      // Captura pose anterior para que no "salte"
      const oldPos = oldMesh ? oldMesh.position.clone() : new BABYLON.Vector3(0, 0, 0);
      const oldRot = oldMesh ? oldMesh.rotation.clone() : new BABYLON.Vector3(0, 0, 0);

      const created = createJsonPlanet(scn, b.def, parentNode, hiParams);
      const land = created.land;
      const ocean = created.ocean;

      land.isPickable = false;
      if (ocean) ocean.isPickable = false;

      // Mantener pose
      try { land.position.copyFrom(oldPos); } catch (e) {}
      try { land.rotation.copyFrom(oldRot); } catch (e) {}

      _applyShadows(b, land, ocean);
      _linkToLight(b, land, ocean);

      // Mantener rings sin reconstruir: reparent al mesh nuevo
      if (oldRing) {
        try {
          oldRing.parent = land;
          oldRing.position.set(0, 0, 0);
        } catch (e) {}
      }

      // Re-parent moons si es planeta
      try {
        if (b.def.kind === "planet" && relinkMoonsParent) relinkMoonsParent(b.id, land);
      } catch (e) {}

      // Swap
      b.farMesh = land;
      b.ocean = ocean;
      b.genParams = hiParams;
      b.mesh = b.hiMesh || b.surfaceMesh || b.landMesh || b.farMesh;
      b.landMesh = b.mesh;

      // Limpieza
      try { oldMesh && oldMesh.dispose(); } catch (e) {}
      try { oldOcean && oldOcean.dispose(); } catch (e) {}

      // Si la órbita estaba bloqueada a este body, refresca el target
      try {
        const lockedName = (typeof getOrbitLockedBodyName === "function") ? getOrbitLockedBodyName() : null;
        if (lockedName && lockedName === (b.def?.name || "")) {
          lockOrbitToBody && lockOrbitToBody(b);
        }
      } catch (e) {}
    } catch (e) {
      console.warn("ensureFullDetailJsonBody warn:", e);
    }
  }

  return { ensureFullDetailJsonBody };
}