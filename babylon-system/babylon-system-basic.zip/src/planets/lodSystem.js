// src/planets/lodSystem.js
// LOD progresivo por distancia para planetas/lunas JSON (subdivisions dinámicos)

function isCtx(x) {
  return !!(x && x.scn && x.world && x.world.bodies && x.mode && x.refs && x.refs.surfaceBodyRef);
}

function unpackFromCtx(ctx) {
  const lighting = ctx.services && ctx.services.lighting;
  const BABYLONRef = ctx.BABYLON || (typeof BABYLON !== "undefined" ? BABYLON : null);

  return {
    BABYLON: BABYLONRef,
    scn: ctx.scn,
    bodies: ctx.world.bodies,
    mode: ctx.mode,
    surfaceBodyRef: ctx.refs.surfaceBodyRef,

    getDefaultPlanetParams: ctx.data.getDefaultPlanetParams,
    planetParamsByName: ctx.data.planetParamsByName,
    labelsById: ctx.world.labelsById,

    includeMeshInBodyLight: lighting ? lighting.includeMeshInBodyLight : null,
    shadowGen: lighting ? lighting.shadowGen : null,

    createJsonPlanet: ctx.data.createJsonPlanet,
    buildRuntimePlanetParams: ctx.data.buildRuntimePlanetParams,
    relinkMoonsParent: ctx.data.relinkMoonsParent,
    ctx,
  };
}

export function createLodSystem(optsOrCtx) {
  const opts = isCtx(optsOrCtx) ? unpackFromCtx(optsOrCtx) : { ...optsOrCtx, ctx: null };

  const {
    BABYLON,
    scn,
    bodies,
    mode,
    surfaceBodyRef,
    getDefaultPlanetParams,
    planetParamsByName,
    labelsById,
    includeMeshInBodyLight,
    shadowGen,
    createJsonPlanet,
    buildRuntimePlanetParams,
    relinkMoonsParent,
  } = opts;

  if (!BABYLON) throw new Error("[lod] BABYLON missing (ctx.BABYLON o global)");
  if (!scn) throw new Error("[lod] scn required");
  if (!bodies) throw new Error("[lod] bodies required");
  if (!mode) throw new Error("[lod] mode required");
  if (!surfaceBodyRef) throw new Error("[lod] surfaceBodyRef required");
  if (typeof getDefaultPlanetParams !== "function") throw new Error("[lod] getDefaultPlanetParams required");
  if (!planetParamsByName) throw new Error("[lod] planetParamsByName required");
  if (typeof includeMeshInBodyLight !== "function") throw new Error("[lod] includeMeshInBodyLight required");
  if (typeof createJsonPlanet !== "function") throw new Error("[lod] createJsonPlanet required");
  if (typeof buildRuntimePlanetParams !== "function") throw new Error("[lod] buildRuntimePlanetParams required");
  if (typeof relinkMoonsParent !== "function") throw new Error("[lod] relinkMoonsParent required");

  // ------------------------------
  // Config
  // ------------------------------
  const LOD = {
    updateMs: 120,

    nearMul: 70,
    nearPad: 140,

    hiExitMul: 140,
    hiExitPad: 550,

    midMul: 170,
    midPad: 700,
    midExitMul: 230,
    midExitPad: 1000,

    farMul: 120,
    farPad: 200,

    hiCap: 99,
    hiFloor: 7,
    midCap: 14,
    midFloor: 5,
    lowCap: 2,

    curvePow: 0.75,

    regenCooldownMs: 400,
    minStep: 1,
    maxRegenPerTick: 10,
  };

  let _lodTick = 0;

  // ------------------------------
  // Helpers
  // ------------------------------
  function _clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function _smoothstep(t) { t = _clamp(t, 0, 1); return t * t * (3 - 2 * t); }

  function baseSubdivFromParams(baseParams) {
    const raw = (baseParams && typeof baseParams.subdivisions === "number") ? (baseParams.subdivisions | 0) : 8;
    return raw;
  }

  function isRockyJsonBody(b) {
    if (!b || !b.def) return false;
    const k = b.def.kind;
    if (k !== "planet" && k !== "moon") return false;
    if (!b.def.useJsonPlanet) return false;
    return !(b.def.gasGiant || b.def.rocky === false);
  }

  function desiredSubdivByDistance(dist, radius, baseRawSubdiv) {
    const near = radius * LOD.nearMul + LOD.nearPad;
    const far  = radius * LOD.farMul  + LOD.farPad;
    if (far <= near) return _clamp(baseRawSubdiv, LOD.hiFloor, LOD.hiCap);

    const t0 = _smoothstep((dist - near) / (far - near));
    const t = Math.pow(t0, (LOD.curvePow || 1));

    const hi = _clamp(baseRawSubdiv, LOD.hiFloor, LOD.hiCap);
    const lo = _clamp(LOD.lowCap, 2, hi);

    const f = hi + (lo - hi) * t;
    return Math.max(2, Math.round(f));
  }

  function _relinkLabelToMesh(bId, mesh) {
    try {
      if (!labelsById) return;
      const meta = labelsById.get(String(bId || ""));
      if (meta && meta.rect && meta.rect.linkWithMesh) {
        meta.rect.linkWithMesh(mesh);
        meta.mesh = mesh;
      }
    } catch (e) {}
  }

  function ensureLODSubdiv(b, targetSubdiv) {
    if (!b || !b.def || !b.def.useJsonPlanet) return;
    const isRocky = !(b.def.gasGiant || b.def.rocky === false);
    if (!isRocky) return;

    const defaultPlanetParams = getDefaultPlanetParams();
    if (!defaultPlanetParams) return;

    const now = performance.now();
    if (!b._lodLastRegen) b._lodLastRegen = 0;
    if (now - b._lodLastRegen < LOD.regenCooldownMs) return;

    const cur = (b.genParams && typeof b.genParams.subdivisions === "number") ? (b.genParams.subdivisions | 0) : null;
    if (cur !== null && Math.abs(cur - targetSubdiv) < LOD.minStep) return;

    const hasSpecific = !!b.def.jsonFile && planetParamsByName && planetParamsByName.has(b.def.name);
    const base = hasSpecific ? planetParamsByName.get(b.def.name) : defaultPlanetParams;

    const p = buildRuntimePlanetParams(base, b.def, {
      minSubdiv: targetSubdiv,
      maxSubdiv: targetSubdiv,
      forceSeedFromName: !hasSpecific,
    });

    const src = b.farMesh;
    const srcPos = src ? src.position.clone() : new BABYLON.Vector3(b.def.orbitR || 0, 0, 0);
    const srcRot = src ? src.rotation.clone() : new BABYLON.Vector3(0, 0, 0);

    const oldMesh = b.farMesh;
    const oldOcean = b.ocean;

    const created = createJsonPlanet(scn, b.def, b.orbitNode, p);
    const mesh = created.land;
    const ocean = created.ocean;

    mesh.isPickable = false;
    if (ocean) ocean.isPickable = false;

    mesh.position.copyFrom(srcPos);
    mesh.rotation.copyFrom(srcRot);

    includeMeshInBodyLight(mesh, b);
    if (ocean) includeMeshInBodyLight(ocean, b);

    if (b.ring) {
      try { b.ring.parent = mesh; b.ring.position.set(0,0,0); } catch(e) {}
    }
    if (b.def.kind === "planet") {
      relinkMoonsParent(b.id, mesh);
    }

    b.farMesh = mesh;
    b.ocean = ocean;
    b.genParams = p;
    b._lodLastRegen = now;

    // Mantener coherencia con "low*"
    b.lowMesh = mesh;
    b.lowOcean = ocean;
    b.lowGenParams = p;
    b.lod = "low";

    _relinkLabelToMesh(b.id, mesh);

    try { oldMesh && oldMesh.dispose(); } catch(e) {}
    try { oldOcean && oldOcean.dispose(); } catch(e) {}
  }

  // ------------------------------
  // Public API
  // ------------------------------
  function updateDynamicLOD(camPos) {
    const now = performance.now();
    if ((now - _lodTick) < LOD.updateMs) return;
    _lodTick = now;

    const defaultPlanetParams = getDefaultPlanetParams();
    if (!defaultPlanetParams) return;

    // Construye candidatos con distancia (solo JSON rocosos)
    const candidates = [];
    for (const [, b] of bodies.entries()) {
      if (!isRockyJsonBody(b) || !b.farMesh) continue;

      const p = b.farMesh.getAbsolutePosition();
      const dist = BABYLON.Vector3.Distance(camPos, p);

      const r =
        (b.genParams && typeof b.genParams.radius === "number") ? b.genParams.radius :
        (b.def && typeof b.def.radius === "number") ? b.def.radius :
        6;

      const far = r * LOD.farMul + LOD.farPad;
      if (dist > far * 1.25) continue;

      candidates.push({ b, dist, r });
    }

    candidates.sort((a, c) => a.dist - c.dist);

    // Surface: fuerza max detalle para el cuerpo de surface
    const sb = (surfaceBodyRef && surfaceBodyRef.get) ? surfaceBodyRef.get() : null;
    if (mode.value === "surface" && sb && isRockyJsonBody(sb)) {
      const already = candidates.find(x => x.b && x.b.id === sb.id);
      if (!already && sb.farMesh) {
        const activeMesh = sb.surfaceMesh || sb.hiMesh || sb.mesh || sb.landMesh || sb.farMesh;
        const p = activeMesh.getAbsolutePosition();
        const dist = BABYLON.Vector3.Distance(camPos, p);
        const r =
          (sb.genParams && typeof sb.genParams.radius === "number") ? sb.genParams.radius :
          (sb.def && typeof sb.def.radius === "number") ? sb.def.radius :
          6;
        candidates.unshift({ b: sb, dist, r, forceSurface: true });
      } else if (already) {
        already.forceSurface = true;
      }
    }

    let regenCount = 0;
    for (const it of candidates) {
      if (regenCount >= LOD.maxRegenPerTick) break;
      const b = it.b;
      if (!b || !b.def) continue;

      const hasSpecific = !!b.def.jsonFile && planetParamsByName && planetParamsByName.has(b.def.name);
      const base = hasSpecific ? planetParamsByName.get(b.def.name) : defaultPlanetParams;
      const baseRaw = baseSubdivFromParams(base);

      let targetSubdiv;
      if (it.forceSurface) {
        targetSubdiv = _clamp(baseRaw, LOD.hiFloor, LOD.hiCap);
      } else {
        targetSubdiv = desiredSubdivByDistance(it.dist, it.r, baseRaw);
      }

      const before = (b.genParams && typeof b.genParams.subdivisions === "number") ? (b.genParams.subdivisions | 0) : null;
      ensureLODSubdiv(b, targetSubdiv);
      const after = (b.genParams && typeof b.genParams.subdivisions === "number") ? (b.genParams.subdivisions | 0) : null;
      if (before !== null && after !== null && before !== after) regenCount++;

      // coherencia para PP atmósfera (lo usas en tick)
      b.mesh = b.hiMesh || b.surfaceMesh || b.landMesh || b.farMesh;
      b.landMesh = b.mesh;
    }
  }

  return {
    LOD,
    isRockyJsonBody,
    updateDynamicLOD,
  };
}
