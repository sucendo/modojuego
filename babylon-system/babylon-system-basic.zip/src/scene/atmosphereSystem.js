// scene/atmosphereSystem.js
// Paso 18: atmósfera (PP) aislada, con look del generador:
// - respeta atmoRadiusMul del JSON (fallback 1.25)
// - no hay popping por distancia: hysteresis + fade
// - depth estable aunque tengas clip planes dinámicos: suaviza minZ/maxZ
// - target visual suave: usa mesh más detallado (evita borde “a mordiscos”)

import {
  createAtmospherePostProcess,
  attachDepthForAtmosphere,
  setAtmosphereTarget,
  enableAtmospherePP,
} from "../planets/atmospherePP.js";

import { applyAtmosphereParamsToPP } from "../planets/jsonPlanet.js";

// Escala galaxia (si no hay atmoRange en JSON)
const ATMO_DEFAULT_RANGE_MUL = 80000;
const ATMO_MIN_RANGE = 50000;

function clamp01(x){ return Math.max(0, Math.min(1, x)); }
function lerp(a,b,t){ return a + (b-a)*t; }
function smoothstep(a,b,x){
  const t = clamp01((x - a) / (b - a));
  return t*t*(3 - 2*t);
}

function isCtx(x){
  return !!(x && x.scn && x.world && x.world.bodies && x.mode && x.refs);
}

function unpackFromCtx(ctx){
  return {
    scn: ctx.scn,
    bodies: ctx.world.bodies,
    mode: ctx.mode,
    surfaceBodyRef: ctx.refs.surfaceBodyRef,
    sunMeshRef: ctx.refs.sunMeshRef,
  };
}

export function createAtmosphereSystem(optsOrCtx){
  const opts = isCtx(optsOrCtx) ? unpackFromCtx(optsOrCtx) : optsOrCtx;
  const { scn, bodies, mode, surfaceBodyRef, sunMeshRef } = opts;

  if (!scn) throw new Error("[atmoSystem] scn required");
  if (!bodies) throw new Error("[atmoSystem] bodies required");
  if (!mode) throw new Error("[atmoSystem] mode required");

  let pp = null;
  let ppCam = null;
  let currentBody = null;
  let currentDist = Infinity;
  
  // Hysteresis: entra con range, sale con range*exitMul
  const exitMul = 1.18;
  // Fade: empieza a aparecer cerca del borde del rango, y llega a 1.0 más cerca
  const fadeNearMul = 0.70;  // a 70% del range = full
  const fadeFarMul  = 1.00;  // a 100% del range = 0

  function getSurfaceBody(){
    try { return surfaceBodyRef && surfaceBodyRef.get ? surfaceBodyRef.get() : null; } catch(e){ return null; }
  }

  function getSunMesh(){
    try { return sunMeshRef && sunMeshRef.get ? sunMeshRef.get() : null; } catch(e){ return null; }
  }

  function ensureForCamera(cam){
    if (!cam) return null;
    if (pp && ppCam === cam) return pp;

    try { if (pp && ppCam) ppCam.detachPostProcess(pp); } catch(e){}
    try { if (pp) pp.dispose(); } catch(e){}

    pp = createAtmospherePostProcess(scn, cam);
    ppCam = cam;
    // CLAVE: createAtmospherePostProcess lo deja DETACH. Hay que adjuntarlo.
    enableAtmospherePP(pp, true);
    pp._fade = 0.0;

    try { attachDepthForAtmosphere(scn, cam, pp); } catch(e){}

    // init smooth clip
    pp._minZSm = cam.minZ || 0.1;
    pp._maxZSm = cam.maxZ || 10000;

    currentBody = null;
    currentDist = Infinity;
    return pp;
  }

  function bodyRange(b){
    const p = b && b.genParams;
    if (p && typeof p.atmoRange === "number") return p.atmoRange;
    const r = (p && typeof p.radius === "number") ? p.radius : ((b.def && b.def.radius) ? b.def.radius : 6);
    // Escala galaxia: r*2000 suele ser MUY corto. Asegura un mínimo absoluto.
    return Math.max(ATMO_MIN_RANGE, r * ATMO_DEFAULT_RANGE_MUL);
  }
  
  function hasAtmoParams(p){
    if (!p) return false;
    // Si existe cualquiera de estos, tratamos el planeta como “atmósfera configurable”
    // aunque atmoEnabled no venga seteado.
    return (
      typeof p.atmoStrength === "number" ||
      typeof p.mieStrength === "number" ||
      typeof p.upperStrength === "number" ||
      typeof p.atmoSteps === "number" ||
      typeof p.c0 === "string" || typeof p.c1 === "string" || typeof p.c2 === "string"
    );
  }

  function pickBody(camPos){
    const sb = getSurfaceBody();
    if (mode.value === "surface" && sb) return sb;

    let best = null;
    let bestDist = Infinity;
    for (const [, b] of bodies.entries()){
      if (!b || !b.genParams) continue;
      // Acepta atmoEnabled OR parámetros presentes
      if (!(b.genParams.atmoEnabled || hasAtmoParams(b.genParams))) continue;
      // IMPORTANTE: usar el mesh "activo" (b.mesh) para que coincida con lo que se renderiza
      // y evitar mismatches con depth/silueta al cambiar LOD.
      const m = b.mesh || b.surfaceMesh || b.hiMesh || b.hiPlanetMesh || b.landMesh || b.farMesh;
      if (!m) continue;
      const dist = BABYLON.Vector3.Distance(camPos, m.getAbsolutePosition());
      // No cortamos por rango: elegimos el más cercano y el fade controla visibilidad.
      if (dist < bestDist){
        best = b; bestDist = dist;
      }
    }
    return best;
  }

  function tick(camPos, timeSeconds){
    const cam = scn.activeCamera;
    const _pp = ensureForCamera(cam);
    if (!_pp) return;

    // suaviza clip planes (clave si tienes clip dinámico)
    const minZ = cam.minZ || 0.1;
    const maxZ = cam.maxZ || 10000;
    _pp._minZSm = (_pp._minZSm == null) ? minZ : lerp(_pp._minZSm, minZ, 0.18);
    _pp._maxZSm = (_pp._maxZSm == null) ? maxZ : lerp(_pp._maxZSm, maxZ, 0.12);

    if (!camPos){
      _pp._fade = 0.0;
      return;
    }

    // 1) body candidato por rango (entrada)
    let b = pickBody(camPos);
    if (scn._atmoDbgOnce !== true) {
      scn._atmoDbgOnce = true;
      console.log("[ATMO] bodies:", bodies.size);
      for (const [, bb] of bodies.entries()) {
        if (!bb || !bb.genParams) continue;
        if (bb.genParams.atmoEnabled || (typeof bb.genParams.atmoStrength === "number")) {
          console.log("[ATMO] candidate:", bb.def?.name, "atmoEnabled:", bb.genParams.atmoEnabled, "range:", bb.genParams.atmoRange);
          break;
        }
      }
    }

    // 2) hysteresis: si ya había body activo, no lo sueltes hasta salir más lejos
    if (!b && currentBody){
      const m = currentBody.farMesh || currentBody.mesh || currentBody.landMesh || currentBody.hiMesh || currentBody.surfaceMesh;
      if (m){
        const dist = BABYLON.Vector3.Distance(camPos, m.getAbsolutePosition());
        const exitRange = bodyRange(currentBody) * exitMul;
        if (dist <= exitRange) b = currentBody;
      }
    }

    if (!b || !b.genParams || !(b.genParams.atmoEnabled || hasAtmoParams(b.genParams))){
      currentBody = null;
      currentDist = Infinity;
      _pp._fade = lerp(_pp._fade || 0.0, 0.0, 0.20);
      return;
    }

    // Target visual (como en el generador):
    // usar el mesh con silueta más suave cuando exista, para evitar borde “a mordiscos”.
    // farMesh solo como último recurso.
    // IMPORTANTE: mismo criterio que arriba: target = b.mesh (lo que se ve)
    const targetMesh = b.mesh || b.surfaceMesh || b.hiMesh || b.hiPlanetMesh || b.landMesh || b.farMesh;
    if (!targetMesh){
      _pp._fade = lerp(_pp._fade || 0.0, 0.0, 0.25);
      return;
    }

    const params = b.genParams;
    const planetRadius = (typeof params.radius === "number") ? params.radius : ((b.def && b.def.radius) ? b.def.radius : 6);
    const atmoMul = (typeof params.atmoRadiusMul === "number") ? params.atmoRadiusMul : 1.25; // look generador
    const atmoRadius = planetRadius * atmoMul;

    const dist = BABYLON.Vector3.Distance(camPos, targetMesh.getAbsolutePosition());
    currentBody = b;
    currentDist = dist;
	
    // Key del planeta (para logs y para detectar cambio de objetivo)
    const key = (b.def && b.def.name) ? b.def.name : (targetMesh.name || "body");

    // Fade por distancia (sin popping)
    // Fade "tipo generador": empieza a verse a partir de cierta distancia y no desaparece a saltos.
    // Si no hay atmoRange, usamos un rango grande pero estable.
    const range = bodyRange(b);
    const fade = 1.0 - smoothstep(range * fadeNearMul, range * fadeFarMul, dist);

    // Importante: mínimo visible cerca del planeta para evitar “nunca aparece”
    // Si quieres look 100% “generador”, puedes bajar el minVisible en fly/orbit a 0.0
    // (el generador no suele forzar mínimo).
    const minVisible = (mode.value === "surface") ? 0.65 : 0.0;
    const fadeFinal = clamp01(Math.max(fade, minVisible));
    _pp._fade = lerp(_pp._fade || 0.0, fadeFinal, 0.22);
	
    // Debug 1 vez: ver dist/range/fade y estado del PP
    if (!scn._atmoDbg2) {
      scn._atmoDbg2 = true;
      console.log("[ATMO] pick:", {
        name: key,
        dist,
        range,
        fade,
        planetRadius,
        atmoRadius,
        atmoMul,
        camMinZ: cam.minZ,
        camMaxZ: cam.maxZ,
        attached: _pp._attached,
        enabled: _pp._enabled,
      });
    }

    // Apply params solo al cambiar planeta
    if (_pp._lastDefName !== key){
      _pp._lastDefName = key;
      applyAtmosphereParamsToPP(_pp, params);
    }

    // sunPos
    const star = b.starRef || getSunMesh();
    let sunPos = star ? star.getAbsolutePosition() : BABYLON.Vector3.Zero();
    const planetPos = targetMesh.getAbsolutePosition();
    if (BABYLON.Vector3.DistanceSquared(sunPos, planetPos) < 1e-6){
      sunPos = planetPos.add(new BABYLON.Vector3(1000,0,0));
    }

    setAtmosphereTarget(_pp, targetMesh, planetRadius, atmoRadius, sunPos);
    // time (para nubes)
    _pp._time = (typeof timeSeconds === "number") ? timeSeconds : (performance.now() * 0.001);
  }

  return { ensureForCamera, tick, getPP: () => pp };
}