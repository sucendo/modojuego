// scene/approach.js
// Paso 12: extraer approachTarget + selección + wiring de UI fuera del main.js

function isCtx(x) {
  return !!(x && x.scn && x.ui && x.world && x.world.bodies && x.mode && x.cameras);
}

export function createApproachSystem(optsOrCtx) {
  const opts = isCtx(optsOrCtx)
    ? {
        BABYLON: optsOrCtx.BABYLON,
        scn: optsOrCtx.scn,
        ui: optsOrCtx.ui,
        selection: optsOrCtx.services && optsOrCtx.services.selection,
        mode: optsOrCtx.mode,
        setMode: optsOrCtx.setMode,
        lockOrbitToBody: optsOrCtx.lockOrbitToBody,
        cameraOrbit: optsOrCtx.cameras.cameraOrbit,
        cameraFly: optsOrCtx.cameras.cameraFly,
        cameraSurface: optsOrCtx.cameras.cameraSurface,
        playerRoot: optsOrCtx.playerRoot,
        fullDetailSys: optsOrCtx.services && optsOrCtx.services.fullDetail,
        sunMeshRef: optsOrCtx.refs && optsOrCtx.refs.sunMeshRef,
        getSurfaceCtrl: () => (optsOrCtx.services && optsOrCtx.services.surface ? optsOrCtx.services.surface.get() : null),
      }
    : optsOrCtx;

  const {
    BABYLON,
    scn,
    ui,
    selection,
    mode,
    setMode,
    lockOrbitToBody,
    cameraOrbit,
    cameraFly,
    cameraSurface,
    playerRoot,
    fullDetailSys,
    sunMeshRef,
    getSurfaceCtrl,
  } = opts;

  if (!ui) throw new Error("[approach] ui required");
  if (!selection) throw new Error("[approach] selection required");

  function getSelectedBody() {
    return selection.getSelectedBody();
  }

  function getTargetBody() {
    return selection.getActiveBody();
  }

  function approachTarget(preferredMode = null) {
    const b = selection.getSelectedBody();
    if (!b || !b.farMesh) return;

    // Si piden superficie en gas giant => forzamos vuelo
    if (preferredMode === "surface" && (b.def.gasGiant || b.def.rocky === false)) {
      ui.debugInfo.textContent = `⚠️ ${b.def.name}: gigante gaseoso (sin superficie). Usando modo vuelo.`;
      preferredMode = "fly";
    }

    const targetPos = b.farMesh.getAbsolutePosition().clone();
    const r = b.def.radius || 6;

    if (preferredMode) setMode(preferredMode);

    // Teleport cerca del planeta
    const dir = new BABYLON.Vector3(0.2, 0.25, -1).normalize();
    const camPos = targetPos.add(dir.scale(r * 4.2));

    if (mode.value === "orbit") {
      lockOrbitToBody(b);
      return;
    }

    if (mode.value === "fly") {
      cameraFly.position.copyFrom(camPos);
      cameraFly.setTarget(targetPos);
      return;
    }

    // ---- Surface mode ----
    if (b.def.gasGiant || b.def.rocky === false) {
      setMode("fly");
      cameraFly.position.copyFrom(camPos);
      cameraFly.setTarget(targetPos);
      return;
    }

    const surfaceCtrl = (typeof getSurfaceCtrl === "function") ? getSurfaceCtrl() : null;
    if (!surfaceCtrl) {
      // Si todavía no existe, degradamos a vuelo para evitar crash
      setMode("fly");
      cameraFly.position.copyFrom(camPos);
      cameraFly.setTarget(targetPos);
      return;
    }

    // Full detail ONLY when we go surface (regenerate mesh once)
    try { fullDetailSys && fullDetailSys.ensureFullDetailJsonBody && fullDetailSys.ensureFullDetailJsonBody(b, 8); } catch(e) {}

    // Enganchar el jugador al planeta (para rotación)
    surfaceCtrl.attachPlayerToBody(b);
    surfaceCtrl.setSurfaceBody(b);

    // 2) Punto cerca del terminador (se aprecia mejor la atmósfera)
    const starRef = (b.starRef) ? b.starRef : (sunMeshRef && sunMeshRef.get ? sunMeshRef.get() : null);
    const center = targetPos.clone();
    let N = new BABYLON.Vector3(0, 1, 0);

    if (starRef) {
      const L = starRef.getAbsolutePosition().subtract(center);
      if (L.length() > 1e-6) {
        L.normalize();
        const axis = (Math.abs(L.y) < 0.9) ? BABYLON.Axis.Y : BABYLON.Axis.X;
        const perp = BABYLON.Vector3.Cross(L, axis);
        if (perp.length() > 1e-6) {
          perp.normalize();
          N = BABYLON.Vector3.Cross(perp, L).normalize(); // dot(N,L)=0 => terminador
        }
      }
    }

    // 3) Raycast hacia el planeta para clavar el suelo y aparecer a ~eyeH sobre el terreno
    const eyeH = 0.25;
    const rayO = center.add(N.scale(r * 2.2));
    const rayD = N.scale(-1);
    const ray = new BABYLON.Ray(rayO, rayD, r * 3.0);
    const hit = scn.pickWithRay(ray, (mesh) => mesh === b.farMesh);

    if (hit && hit.hit && hit.pickedPoint) {
      const up = hit.pickedPoint.subtract(center);
      if (up.length() > 1e-6) up.normalize();
      playerRoot.setAbsolutePosition(hit.pickedPoint.add(up.scale(eyeH)));
    } else {
      playerRoot.setAbsolutePosition(center.add(N.scale(r + eyeH)));
    }

    // Reset de dinámica / orientación
    surfaceCtrl.resetDynamics();
  }

  function install() {
    ui.approachBtn.addEventListener("click", () => {
      // Aproximar respeta el modo actual (orbit/fly/surface)
      approachTarget(null);
    });

    ui.camSurfaceBtn.addEventListener("click", () => {
      const b = selection.getSelectedBody();
      if (b && (b.def.gasGiant || b.def.rocky === false)) {
        ui.debugInfo.textContent = `⚠️ ${b.def.name}: gigante gaseoso (sin superficie).`;
        if (mode.value === "orbit") setMode("fly");
        approachTarget(null);
        return;
      }
      setMode("surface");
      approachTarget("surface");
    });

    ui.planetSelect.addEventListener("change", () => {
      if (mode.value !== "surface") return;
      const sel = selection.getSelectedBody();
      if (sel && (sel.def.gasGiant || sel.def.rocky === false)) {
        ui.debugInfo.textContent = `ℹ️ ${sel.def.name}: sin superficie. Pulsa Aproximar para ir en modo vuelo.`;
      } else {
        ui.debugInfo.textContent = "ℹ️ En superficie: selecciona otro cuerpo y pulsa Aproximar (o Superficie) para viajar.";
      }
    });

    // initial approach nice view
    approachTarget(null);
  }

  return { install, approachTarget, getSelectedBody, getTargetBody };
}