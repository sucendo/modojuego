// scene/input.js
// Paso 8: sistema de input desacoplado (teclado).
// - Futuro: aquí puedes añadir móvil/gamepad sin tocar main.js

export function createInputSystem(target = window) {
  const input = {
    forward: false,
    back: false,
    left: false,
    right: false,
    sprint: false,
    jump: false,
  };

  function onKeyDown(e) {
    if (e.code === "KeyW") input.forward = true;
    if (e.code === "KeyS") input.back = true;
    if (e.code === "KeyA") input.left = true;
    if (e.code === "KeyD") input.right = true;
    if (e.code === "ShiftLeft" || e.code === "ShiftRight") input.sprint = true;
    if (e.code === "Space") input.jump = true;
  }

  function onKeyUp(e) {
    if (e.code === "KeyW") input.forward = false;
    if (e.code === "KeyS") input.back = false;
    if (e.code === "KeyA") input.left = false;
    if (e.code === "KeyD") input.right = false;
    if (e.code === "ShiftLeft" || e.code === "ShiftRight") input.sprint = false;
    if (e.code === "Space") input.jump = false;
  }

  function install() {
    target.addEventListener("keydown", onKeyDown);
    target.addEventListener("keyup", onKeyUp);
  }

  function dispose() {
    target.removeEventListener("keydown", onKeyDown);
    target.removeEventListener("keyup", onKeyUp);
  }

  return { input, install, dispose };
}