// scene/tickFromCtx.js
// Paso 14: adaptador para poder llamar a createTickSystem(ctx)
// sin reescribir todavía scene/tick.js

import { createTickSystem } from "./tick.js";

export function createTickSystemFromCtx(ctx) {
  if (!ctx || !ctx.scn || !ctx.engine) throw new Error("[tickFromCtx] ctx inválido");

  const sunMesh = ctx.refs?.sunMeshRef?.get ? ctx.refs.sunMeshRef.get() : null;
  const halo = ctx.refs?.haloRef?.get ? ctx.refs.haloRef.get() : null;

  // Traducción ctx -> params legacy
  return createTickSystem({
    engine: ctx.engine,
    scn: ctx.scn,
    ui: ctx.ui,
    bodies: ctx.world.bodies,
    mode: ctx.mode,              // se setea desde main
    uiState: ctx.uiState,

    sunMesh,
    halo,
    surfaceBodyRef: ctx.refs.surfaceBodyRef,
    surfaceAttachedToRef: ctx.refs.surfaceAttachedToRef,

    cameraFly: ctx.cameras.cameraFly,
    cameraOrbit: ctx.cameras.cameraOrbit,
    cameraSurface: ctx.cameras.cameraSurface,

    updateDynamicLOD: ctx.systems.updateDynamicLOD,
    relinkAllBodyMeshesToLights: ctx.systems.relinkAllBodyMeshesToLights,
    updateExtraSystemShadows: ctx.systems.updateExtraSystemShadows,
    enforcePlanetCollision: ctx.systems.enforcePlanetCollision,
    updateOrbits: ctx.systems.updateOrbits,
    surfaceStep: ctx.systems.surfaceStep,
    updateLabelVisibility: ctx.systems.updateLabelVisibility,

    updateRings: ctx.systems.updateRings,
    atmoPPRef: ctx.refs.atmoPPRef,
    setAtmosphereTarget: ctx.systems.setAtmosphereTarget,
    enableAtmospherePP: ctx.systems.enableAtmospherePP,
    updateAtmospherePP: ctx.systems.updateAtmospherePP,
  });
}