// scene/tick.js
// Paso 6: sacar el "bucle gordo" del main.js a un módulo
// - Mantiene el mismo comportamiento, pero deja main.js como orquestador.
// FIX v6: floating-origin con "grid snap" + hard-recalc de anchors para eliminar deriva acumulada.

import { getCameraWorldPos } from "./cameraUtils.js";

function isCtx(x) {
  return !!(x && x.scn && x.engine && x.world && x.refs && x.systems && x.cameras);
}

function unpackFromCtx(ctx) {
  const sunMesh = ctx.refs?.sunMeshRef?.get ? ctx.refs.sunMeshRef.get() : null;
  const halo = ctx.refs?.haloRef?.get ? ctx.refs.haloRef.get() : null;

  return {
    engine: ctx.engine,
    scn: ctx.scn,
    ui: ctx.ui,

	systemRoots: ctx.world.systemRoots,
    bodies: ctx.world.bodies,
    galaxyRoot: ctx.world.galaxyRoot,
    originOffset: ctx.world.originOffset,
    enableFloatingOrigin: ctx.world.enableFloatingOrigin,
    lyScale: ctx.world.lyScale,
    pendingRebaseRef: { get: () => ctx.world.pendingRebase, set: (v) => { ctx.world.pendingRebase = v; } },
    galaxyStarDots: ctx.world.galaxyStarDots,
    sunMeshRef: ctx.world.sunMeshRef || ctx.sunMeshRef,
    haloRef: ctx.world.haloRef || ctx.haloRef,
    mode: ctx.mode,
    uiState: ctx.uiState,

    sunMesh,
    halo,
    surfaceBodyRef: ctx.refs.surfaceBodyRef,
    surfaceAttachedToRef: ctx.refs.surfaceAttachedToRef,

    cameraFly: ctx.cameras.cameraFly,
    cameraOrbit: ctx.cameras.cameraOrbit,
    cameraSurface: ctx.cameras.cameraSurface,

    updateDynamicLOD: ctx.systems.updateDynamicLOD,
    relinkAllBodyMeshesToLights: ctx.systems.relinkAllBodyMeshesToLights,
    updateExtraSystemShadows: ctx.systems.updateExtraSystemShadows,
    enforcePlanetCollision: ctx.systems.enforcePlanetCollision,
    updateOrbits: ctx.systems.updateOrbits,
    surfaceStep: ctx.systems.surfaceStep,
    updateLabelVisibility: ctx.systems.updateLabelVisibility,

    updateRings: ctx.systems.updateRings,

    atmoPPRef: ctx.refs.atmoPPRef,
    atmosphere: (ctx.services && ctx.services.atmosphere) ? ctx.services.atmosphere : null,
    setAtmosphereTarget: ctx.systems.setAtmosphereTarget,
    enableAtmospherePP: ctx.systems.enableAtmospherePP,
    updateAtmospherePP: ctx.systems.updateAtmospherePP,
  };
}

export function createTickSystem(optsOrCtx) {
  const opts = isCtx(optsOrCtx) ? unpackFromCtx(optsOrCtx) : optsOrCtx;

  const {
    engine,
    scn,
    ui,
	
	systemRoots,
    // State / refs
    bodies,
    galaxyRoot,
    originOffset,
    enableFloatingOrigin,
    lyScale,
    pendingRebaseRef,
    galaxyStarDots,
    sunMeshRef,
    haloRef,
    mode,
    uiState,
    sunMesh,
    halo,
    surfaceBodyRef,          // { get(): body|null }
    surfaceAttachedToRef,    // { get(): body|null }

    // Cameras
    cameraFly,
    cameraOrbit,
    cameraSurface,

    // Systems
    updateDynamicLOD,
    relinkAllBodyMeshesToLights,
    updateExtraSystemShadows,
    enforcePlanetCollision,
    updateOrbits,
    surfaceStep,
    updateLabelVisibility,

    // Rings
    updateRings,

    // Atmosphere PP (screen-space)
    atmoPPRef,               // { get(): pp|null }
	atmosphere,
    setAtmosphereTarget,
    enableAtmospherePP,
    updateAtmospherePP,
  } = opts;

  // Guardrails (para fallar pronto si falta wiring en ctx)
  if (!engine || !scn) throw new Error("[tick] engine/scn requeridos");
  if (!bodies) throw new Error("[tick] bodies requerido");
  if (!mode) throw new Error("[tick] mode requerido");
  if (typeof updateDynamicLOD !== "function") throw new Error("[tick] updateDynamicLOD requerido");
  if (typeof relinkAllBodyMeshesToLights !== "function") throw new Error("[tick] relinkAllBodyMeshesToLights requerido");
  if (typeof updateExtraSystemShadows !== "function") throw new Error("[tick] updateExtraSystemShadows requerido");
  if (typeof enforcePlanetCollision !== "function") throw new Error("[tick] enforcePlanetCollision requerido");
  if (typeof updateOrbits !== "function") throw new Error("[tick] updateOrbits requerido");
  if (typeof surfaceStep !== "function") throw new Error("[tick] surfaceStep requerido");
  if (typeof updateLabelVisibility !== "function") throw new Error("[tick] updateLabelVisibility requerido");
  if (typeof updateRings !== "function") throw new Error("[tick] updateRings requerido");

  // Throttle de debug DOM
  function updateDebug(chunks) {
    if (!scn._dbgT || (performance.now() - scn._dbgT) > 350) {
      scn._dbgT = performance.now();
      if (ui && ui.debugInfo) {
        ui.debugInfo.textContent = `Chunks activos: ${chunks} | FPS: ${engine.getFps().toFixed(0)}`;
      }
    }
  }

  function animateHalo() {
    const t = performance.now() * 0.001;
    if (halo && halo.scaling && halo.scaling.set) {
      halo.scaling.set(
        1 + Math.sin(t * 0.8) * 0.01,
        1 + Math.sin(t * 0.9) * 0.01,
        1 + Math.sin(t * 0.7) * 0.01
      );
    }
  }
  
  // --- Helpers: snap del rebase a una rejilla para evitar "drift" ---
  function _snapToGrid(v, grid) {
    if (!v || !isFinite(grid) || grid <= 0) return null;
    const sx = Math.round(v.x / grid) * grid;
    const sy = Math.round(v.y / grid) * grid;
    const sz = Math.round(v.z / grid) * grid;
    // Si el snap da (casi) cero, no rebases
    if ((Math.abs(sx) + Math.abs(sy) + Math.abs(sz)) < 1e-9) return null;
    // Reutiliza Vector3 si existe BABYLON en scope global, si no, clona y set
    try {
      // activeCam.position suele ser BABYLON.Vector3
      const out = v.clone();
      out.set(sx, sy, sz);
      return out;
    } catch (e) {
      // fallback
      return { x: sx, y: sy, z: sz };
    }
  }

  // "Hard recalc" de anchors desde coordenadas galácticas absolutas.
  // Esto elimina cualquier error acumulado por múltiples shifts incrementales.
  function _hardRecalcGalaxyAnchors() {
    if (!originOffset) return;

    // 1) Systems: root.position = galaxyPos - originOffset
    if (systemRoots) {
      for (const [, root] of systemRoots.entries()) {
        if (!root || !root.position) continue;
        const gp = root.metadata && root.metadata.galaxyPos;
        if (!gp) continue;
        try {
          root.position.copyFrom(gp).subtractInPlace(originOffset);
        } catch (e) {}
      }
    }

    // 2) Star dots: dot.position = basePos - originOffset
    if (galaxyStarDots && galaxyStarDots.length) {
      for (const s of galaxyStarDots) {
        const dot = s && s.dot;
        if (!dot || !dot.position) continue;
        const bp = s.basePos || (dot.metadata && dot.metadata.galaxyPos);
        if (!bp) continue;
        try {
          dot.position.copyFrom(bp).subtractInPlace(originOffset);
        } catch (e) {}
      }
    }
  }
  
  // Floating origin ABSOLUTO (solo vuelo/superficie):
  // - La cámara viaja "de verdad" (acumula originOffset).
  // - Reposiciona los sistemas a (galaxyPos - originOffset) cuando hay shift.
  function applyAbsoluteFloatingOrigin(activeCam) {
    if (!enableFloatingOrigin) return;
    if (!activeCam) return;
    if (!originOffset) return;
    if (!systemRoots) return;

    // Floating origin (absolute): keep local coordinates near (0,0,0) to avoid
    // float precision jitter when you are very far from the origin.
    // - fly/surface: shift by camera position
    // - orbit (ArcRotate): shift by locked target when available

    // Umbral adaptativo:
    // - en "fly" puedes permitir coordenadas locales enormes sin jitter perceptible (no estás cerca de superficies)
    // - en "orbit/surface" conviene rebajar antes para evitar vibración en planetas
    const __LY = (typeof lyScale === "number" && lyScale > 0) ? lyScale : 1000;
    const THRESH = (mode && mode.value === "fly") ? (__LY * 250) : (__LY * 25);
    // Tamaño de la rejilla para snap del rebase.
    // Recomendación: 1 LY en unidades de escena. (Si quieres menos frecuencia: 2*__LY o 5*__LY)
    const GRID = __LY * 1.0;

    let shift = null;

    // One-shot rebase requested by other systems (e.g. when locking orbit)
    // This prevents the "Sol" (or any other star) from appearing to follow you.
    try {
      const pr = pendingRebaseRef && pendingRebaseRef.get ? pendingRebaseRef.get() : null;
      if (pr && (Math.abs(pr.x) + Math.abs(pr.y) + Math.abs(pr.z)) > 1e-9) {
        // Snap también los rebases "forzados"
        shift = _snapToGrid(pr, GRID) || pr.clone();
        pendingRebaseRef.set(null);
      }
    } catch (e) {}

    const isOrbit = (activeCam === cameraOrbit);
    const isFree  = (activeCam === cameraFly) || (activeCam === cameraSurface);

    if (!shift && isOrbit) {
      // Prefer shifting by the focused body position (more stable than camera position)
      const lt = cameraOrbit && cameraOrbit.lockedTarget;
      if (lt && typeof lt.getAbsolutePosition === "function") {
        const tp = lt.getAbsolutePosition();
        const len = Math.sqrt(tp.x*tp.x + tp.y*tp.y + tp.z*tp.z);
        if (len >= THRESH) shift = _snapToGrid(tp, GRID) || tp.clone();
      }
      if (!shift && cameraOrbit && cameraOrbit.position) {
        const p = cameraOrbit.position;
        const len = Math.sqrt(p.x*p.x + p.y*p.y + p.z*p.z);
        if (len >= THRESH) shift = _snapToGrid(p, GRID) || p.clone();
      }
    } else if (!shift && isFree) {
      const p = activeCam.position;
      if (!p) return;
      const len = Math.sqrt(p.x*p.x + p.y*p.y + p.z*p.z);
      if (len >= THRESH) shift = _snapToGrid(p, GRID) || p.clone();
    } else {
      // other cameras not handled
      return;
    }

    if (!shift) return;
    // Seguridad: si tras snap queda en cero, no hagas nada.
    if ((Math.abs(shift.x) + Math.abs(shift.y) + Math.abs(shift.z)) < 1e-9) return;

    // 1) accumulate galactic offset
    originOffset.addInPlace(shift);

    // 2) recenter active camera local coords
    try {
      activeCam.position.subtractInPlace(shift);
    } catch (e) {}

    // For ArcRotate, also shift its target so it keeps looking at the same local point
    if (isOrbit && cameraOrbit) {
      try {
        const t = cameraOrbit.getTarget ? cameraOrbit.getTarget() : cameraOrbit.target;
        if (t) cameraOrbit.setTarget(t.subtract(shift));
      } catch (e) {}
    }

    // 3) Hard recalc de anchors (sin drift):
    // root.position = galaxyPos - originOffset
    // dot.position  = basePos - originOffset
    _hardRecalcGalaxyAnchors();
  }

  function updateRingsForAll(camPos) {
    if (!camPos) return;
    for (const [, b] of bodies.entries()) {
      if (!b || !b.farMesh || !b.ring) continue;
      const p = b.farMesh.getAbsolutePosition();
      const starRef = b.starRef || sunMesh;
      const sunPos = starRef ? starRef.getAbsolutePosition() : null;
      if (sunPos) updateRings(b.ring, p, sunPos, b.def.radius);
    }
  }

  function flySprint(input) {
    if (mode.value !== "fly" || !cameraFly) return;
    const base = cameraFly._flyBaseSpeed || 2.2;
    const spr  = cameraFly._flySprintSpeed || 7.5;
    cameraFly.speed = (input && input.sprint) ? spr : base;
  }

  function cheapCollisions() {
    if (mode.value === "fly") enforcePlanetCollision(cameraFly);
    if (mode.value === "orbit") enforcePlanetCollision(cameraOrbit);
  }

  function surfaceModeStep(dt) {
    let chunks = 0;
    if (mode.value === "surface") {
      surfaceStep(dt);
    }
    return chunks;
  }

  // Public: instala el loop
  function install({ input }) {
    scn.onBeforeRenderObservable.add(() => {
      const dt = engine.getDeltaTime() / 1000;
      const cam = scn.activeCamera;

      // Floating origin (opcional): antes de calcular camPos / LOD)
      applyAbsoluteFloatingOrigin(cam);

      const camPosLocal = getCameraWorldPos(cam);
      // Posición "real" galáctica = local + originOffset acumulado
      // (Esto es lo que debe usarse para distancias a sistemas/LOD/approach)
      const camPos = (camPosLocal && originOffset)
        ? camPosLocal.clone().addInPlace(originOffset)
        : camPosLocal;

      // LOD dinámico
      if (camPos) updateDynamicLOD(camPos);

      // Mantenimiento de luces/sombras
      if (camPos) {
        relinkAllBodyMeshesToLights();
        updateExtraSystemShadows();
      }

      // Atmósfera PP
      if (atmosphere && typeof atmosphere.tick === "function") {
        atmosphere.tick(camPos, performance.now() * 0.001);
      } else {
        // fallback legacy si aún no has creado ctx.services.atmosphere
        const pp = atmoPPRef && atmoPPRef.get ? atmoPPRef.get() : null;
        if (pp) enableAtmospherePP(pp, false);
      }

      // Sprint fly + colisión barata
      flySprint(input);
      cheapCollisions();

      // Rings + halo
      updateRingsForAll(camPos);
      animateHalo();

      // Órbitas siempre
      updateOrbits(dt);

      // Superficie
      const chunks = surfaceModeStep(dt);

      // Labels
      updateLabelVisibility(false);

      // Debug
      updateDebug(chunks);
    });
  }

  return { install };
}