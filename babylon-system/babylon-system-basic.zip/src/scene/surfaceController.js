// scene/surfaceController.js
// Paso 8: sacar surface movement + gravity + attach/detach del main.js

export function createSurfaceController({
  scn,
  playerRoot,
  cameraSurface,
  input,
  getTargetBody,          // () => body (en surface debe devolver el body actual/attached)
}) {
  if (!scn) throw new Error("[surfaceController] scn required");
  if (!playerRoot) throw new Error("[surfaceController] playerRoot required");
  if (!cameraSurface) throw new Error("[surfaceController] cameraSurface required");
  if (!input) throw new Error("[surfaceController] input required");
  if (typeof getTargetBody !== "function") throw new Error("[surfaceController] getTargetBody() required");

  // Permite actualizar el getter después (Paso 12.1)
  // Así evitamos hacks en main y mantenemos el controller desacoplado del wiring.
  let _getTargetBody = getTargetBody;
  function setGetTargetBody(fn) {
    if (typeof fn !== "function") throw new Error("[surfaceController] setGetTargetBody(fn) requiere una función");
    _getTargetBody = fn;
  }

  // Body currently used for surface mode (player attached)
  let surfaceBody = null;
  // Surface attachment: si el planeta rota, el jugador debe heredar esa rotación.
  let surfaceAttachedTo = null;

  // Dinámica
  let playerVel = new BABYLON.Vector3(0, 0, 0);
  let onGround = false;
  let surfaceYaw = 0;

  // Ajustes (toca aquí)
  const surfaceCfg = {
    walkSpeed: 8.0,
    runSpeed: 14.0,
    jumpSpeed: 7.0,
    gravity: 9.8,
    vSmoothTime: 0.10,
    airSmoothTime: 0.50,
    stickToGround: 8.0,
    eyeHeight: 0.25,
    pitchMin: -0.75,
    pitchMax: 1.35,
    rotSharpness: 14.0,
    groundRayUp: 1.2,
    groundEps: 0.22,
    snapSharpness: 18.0,
  };

  function getSurfaceBody() { return surfaceBody; }
  function getAttachedBody() { return surfaceAttachedTo; }

  function setSurfaceBody(b) {
    surfaceBody = b || null;
  }

  function resetDynamics() {
    try { playerVel.set(0, 0, 0); } catch (e) {}
    onGround = false;
    surfaceYaw = 0;
    playerRoot.rotationQuaternion = BABYLON.Quaternion.Identity();
    cameraSurface.rotation.set(0, 0, 0);
  }

  function attachPlayerToBody(b) {
    // Opción A (compatible con Floating Origin):
    // NO parentar playerRoot a meshes del mundo (que cuelgan de galaxyRoot),
    // porque entonces el rebase mueve cámara+mundo a la vez y "todo se desplaza contigo".
    if (!b || !playerRoot) return;
    if (!b.farMesh) return;
    surfaceAttachedTo = b;
  }

  function detachPlayerFromBody() {
    // Mantener world transform tal cual; solo desenganchar.
    surfaceAttachedTo = null;
  }

  // ------------------------------------------------------------
  // surfaceStep(dt) — copiado 1:1 del main, pero encapsulado
  // ------------------------------------------------------------
  function surfaceStep(dt) {
    const b = _getTargetBody();
    if (!b || !b.farMesh) return;

    // --- Temps reutilizables (evita GC stutter) ---
    if (!surfaceStep._t) {
      surfaceStep._t = {
        center: new BABYLON.Vector3(),
        pos: new BABYLON.Vector3(),
        toCenter: new BABYLON.Vector3(),
        down: new BABYLON.Vector3(),
        up: new BABYLON.Vector3(),
        forward: new BABYLON.Vector3(),
        right: new BABYLON.Vector3(),
        m: new BABYLON.Matrix(),
        desiredQ: new BABYLON.Quaternion(),
        ray: new BABYLON.Ray(BABYLON.Vector3.Zero(), BABYLON.Vector3.Up(), 1),
        targetPos: new BABYLON.Vector3(),
        refF: new BABYLON.Vector3(),
        proj: new BABYLON.Vector3(),
        qYaw: new BABYLON.Quaternion(),
        targetTangVel: new BABYLON.Vector3(),
        tangVel: new BABYLON.Vector3(),
        radVel: new BABYLON.Vector3(),
        tmp: new BABYLON.Vector3(),
        move: new BABYLON.Vector3(),
        prevRight: new BABYLON.Vector3(1, 0, 0),
      };
    }
    const t = surfaceStep._t;

    // center of planet in world
    const center = t.center;
    center.copyFrom(b.farMesh.getAbsolutePosition());

    // pos = player (world)
    const pos = t.pos;
    pos.copyFrom(playerRoot.getAbsolutePosition());

    // toCenter = center - pos
    t.toCenter.copyFrom(center).subtractInPlace(pos);
    const dist = t.toCenter.length();

    // down = normalize(toCenter)
    t.down.copyFrom(t.toCenter);
    if (dist > 1e-6) t.down.scaleInPlace(1 / dist);
    const down = t.down;

    // up = -down
    t.up.copyFrom(down).scaleInPlace(-1);
    const up = t.up;

    // --- Mouse: yaw al jugador, pitch a la cámara ---
    if (cameraSurface.rotation.y) {
      surfaceYaw += cameraSurface.rotation.y;
      cameraSurface.rotation.y = 0;
    }
    cameraSurface.rotation.x = BABYLON.Scalar.Clamp(cameraSurface.rotation.x, surfaceCfg.pitchMin, surfaceCfg.pitchMax);
    cameraSurface.rotation.z = 0;

    // --- Forward estable (sin flips en polos) ---
    t.refF.copyFrom(BABYLON.Axis.Z);
    const dzu = BABYLON.Vector3.Dot(t.refF, up);
    t.proj.copyFrom(up).scaleInPlace(dzu);
    t.refF.subtractInPlace(t.proj);
    if (t.refF.lengthSquared() < 1e-8) {
      t.refF.copyFrom(BABYLON.Axis.X);
      const dxu = BABYLON.Vector3.Dot(t.refF, up);
      t.proj.copyFrom(up).scaleInPlace(dxu);
      t.refF.subtractInPlace(t.proj);
    }
    t.refF.normalize();

    // forward = rotate(refF, around up, surfaceYaw)
    BABYLON.Quaternion.RotationAxisToRef(up, surfaceYaw, t.qYaw);
    t.refF.rotateByQuaternionToRef(t.qYaw, t.forward);
    t.forward.normalize();
    const forward = t.forward;

    BABYLON.Vector3.CrossToRef(up, forward, t.right);
    const rl = t.right.length();
    if (rl > 1e-6) t.right.scaleInPlace(1 / rl);
    const right = t.right;

    // Evita roll flip (180º) al cruzar polos
    const prevR = t.prevRight;
    if (BABYLON.Vector3.Dot(prevR, right) < 0) {
      right.scaleInPlace(-1);
      forward.scaleInPlace(-1);
    }
    prevR.copyFrom(BABYLON.Vector3.Lerp(prevR, right, 0.35));
    prevR.normalize();
    right.copyFrom(prevR);

    // rotation quaternion from basis (manual matrix)
    const m = t.m;
    const mm = m.m;
    mm[0] = right.x;   mm[1] = right.y;   mm[2] = right.z;   mm[3] = 0;
    mm[4] = up.x;      mm[5] = up.y;      mm[6] = up.z;      mm[7] = 0;
    mm[8] = forward.x; mm[9] = forward.y; mm[10] = forward.z; mm[11] = 0;
    mm[12] = 0;        mm[13] = 0;        mm[14] = 0;        mm[15] = 1;

    BABYLON.Quaternion.FromRotationMatrixToRef(m, t.desiredQ);
    const rotAlpha = 1 - Math.exp(-surfaceCfg.rotSharpness * dt);
    playerRoot.rotationQuaternion = BABYLON.Quaternion.Slerp(playerRoot.rotationQuaternion, t.desiredQ, rotAlpha);

    // --- Raycast suelo ---
    const rayLen = Math.max(60, b.def.radius * 6);
    const ray = t.ray;
    t.tmp.copyFrom(up).scaleInPlace(surfaceCfg.groundRayUp);
    ray.origin.copyFrom(pos).addInPlace(t.tmp);
    ray.direction.copyFrom(down);
    ray.length = rayLen;

    const hit = scn.pickWithRay(ray, (mesh) => mesh === b.farMesh);

    // --- Grounded + objetivo de altura ---
    onGround = false;
    const eyeHeight = surfaceCfg.eyeHeight;

    if (hit && hit.hit && hit.pickedPoint) {
      const dGround = BABYLON.Vector3.Distance(pos, hit.pickedPoint);
      onGround = (dGround <= (eyeHeight + surfaceCfg.groundEps));

      t.tmp.copyFrom(up).scaleInPlace(eyeHeight);
      t.targetPos.copyFrom(hit.pickedPoint).addInPlace(t.tmp);
    }

    // --- Movimiento tangencial ---
    const mv = t.move;
    mv.set(0, 0, 0);
    if (input.forward) mv.addInPlace(forward);
    if (input.back) mv.subtractInPlace(forward);
    if (input.left) mv.subtractInPlace(right);
    if (input.right) mv.addInPlace(right);

    const speed = input.sprint ? surfaceCfg.runSpeed : surfaceCfg.walkSpeed;
    if (mv.lengthSquared() > 1e-10) {
      mv.normalize();
      t.targetTangVel.copyFrom(mv).scaleInPlace(speed);
    } else {
      t.targetTangVel.set(0, 0, 0);
    }

    // separar vel radial/tangencial
    const vRad = BABYLON.Vector3.Dot(playerVel, down);
    t.radVel.copyFrom(down).scaleInPlace(vRad);
    t.tangVel.copyFrom(playerVel).subtractInPlace(t.radVel);

    const smoothT = onGround ? surfaceCfg.vSmoothTime : surfaceCfg.airSmoothTime;
    const velAlpha = 1 - Math.exp(-dt / Math.max(1e-4, smoothT));
    BABYLON.Vector3.LerpToRef(t.tangVel, t.targetTangVel, velAlpha, t.tangVel);

    playerVel.copyFrom(t.tangVel).addInPlace(t.radVel);

    // --- Gravedad + stickToGround + salto ---
    if (onGround) {
      if (input.jump) {
        t.tmp.copyFrom(up).scaleInPlace(surfaceCfg.jumpSpeed);
        playerVel.addInPlace(t.tmp);
        onGround = false;
      } else {
        t.tmp.copyFrom(down).scaleInPlace(surfaceCfg.stickToGround * dt);
        playerVel.addInPlace(t.tmp);
      }
    } else {
      t.tmp.copyFrom(down).scaleInPlace(surfaceCfg.gravity * dt);
      playerVel.addInPlace(t.tmp);
    }

    // Integrate
    t.tmp.copyFrom(playerVel).scaleInPlace(dt);
    const newPos = pos.add(t.tmp);
    playerRoot.setAbsolutePosition(newPos);

    // Snap a suelo
    if (hit && hit.hit && hit.pickedPoint) {
      const snapA = 1 - Math.exp(-surfaceCfg.snapSharpness * dt);
      const cur = playerRoot.getAbsolutePosition();
      playerRoot.setAbsolutePosition(BABYLON.Vector3.Lerp(cur, t.targetPos, snapA));

      const into = BABYLON.Vector3.Dot(playerVel, down);
      if (into > 0) {
        t.tmp.copyFrom(down).scaleInPlace(into);
        playerVel.subtractInPlace(t.tmp);
      }
    }
  }

  return {
    // refs / state
    getSurfaceBody,
    getAttachedBody,
    setSurfaceBody,

    // attach/detach
    attachPlayerToBody,
    detachPlayerFromBody,

    // dynamics
    resetDynamics,
    surfaceStep,

    // Paso 12.1
    setGetTargetBody,

    // config access (por si lo quieres editar desde UI más adelante)
    surfaceCfg,
  };
}