// galaxy/builder.js
// Deterministic pseudo-random [0,1) from a string seed.
// Uses FNV-1a 32-bit hash (fast, stable across platforms).
function rand01FromString(str) {
  let h = 0x811c9dc5; // FNV offset basis
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    // h *= 16777619 (with overflow)
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  // Map to [0,1)
  return (h >>> 0) / 4294967296;
}

export function createGalaxyBuilder({
  BABYLON,
  scn,

  // Optional: parent for everything renderable (for floating-origin)
  WORLD_ROOT = null,

  // Data
  extraSystems,

  // Shared runtime state
  bodies,
  orbitNodes,
  moonOrbitNodes,
  systemRoots,
  galaxyStarDots,

  // Assets / visuals
  starDotMgr,
  createStarDotSprite,
  makeRings,
  loadTextureOrNull,

  // Planet generation
  defaultPlanetParams,
  planetParamsByName,
  buildRuntimePlanetParams,
  createJsonPlanet,
  createLowPolyFarPlanet,

  // Lighting
  sunLight,
  shadowGen,
  mainLitMeshes,
  registerStarLight,
  createLocalSystemLight,
  includeMeshInBodyLight,

  // Scene-wide refs (output)
  sunMeshRef,   // { get():Mesh|null, set(m) }
  haloRef,      // { get():Mesh|null, set(m) }

  // Config
  mapsByName = {},
  SYSTEM_POS_SCALE = 2.8,
  // Global scaling
  // - DIST_SCALE: scales distances (system positions + orbits)
  // - BODY_SCALE: scales radii (stars/planets/moons spheres)
  DIST_SCALE = 1.0,
  BODY_SCALE = 1.0,
  simpleBuildOnly = false, // if true: do NOT generate oceans/rings/hi meshes; spheres only
  GALAXY_LAYOUT = {
    holeRadius: 1200,
    radialStep: 700,
    angleStep: 0.92,
    verticalJitter: 140,
    globalScale: 0.75,
  },
}) {
  // -----------------------------
  // Helpers (ids / names)
  // -----------------------------
  function _normName(s) {
    return (typeof s === "string") ? s.trim() : "";
  }
  const _bodyKey = (systemId, kind, name, parentKey = "") =>
    `${systemId || ""}|${kind || ""}|${parentKey || ""}|${name || ""}`;

  function _hashToColor3(seedStr){
    // Deterministic pseudo-color from string (no allocations in hot paths)
    // Keep this file self-contained (no external rand helpers)
    const t = _galRand01(String(seedStr || ""));
    const r = 0.25 + 0.60 * ((t * 1.37) % 1);
    const g = 0.25 + 0.60 * ((t * 2.11) % 1);
    const b = 0.25 + 0.60 * ((t * 3.03) % 1);
    return new BABYLON.Color3(r, g, b);
  }

  // ------------------------------------------------------------
  // Simple bodies helpers (hide everything except one PBR sphere)
  // ------------------------------------------------------------
  function _setEnabledRemember(mesh, enabled, tag = "_simpleTogglePrev") {
    if (!mesh || typeof mesh.setEnabled !== "function") return;
    if (!mesh.metadata) mesh.metadata = {};
    if (!(tag in mesh.metadata)) {
      mesh.metadata[tag] = mesh.isEnabled();
    }
    mesh.setEnabled(!!enabled);
  }

  function _restoreEnabled(mesh, tag = "_simpleTogglePrev") {
    if (!mesh || typeof mesh.setEnabled !== "function" || !mesh.metadata) return;
    if (tag in mesh.metadata) {
      mesh.setEnabled(!!mesh.metadata[tag]);
      delete mesh.metadata[tag];
    }
  }

  function createSimpleBodySphere(def, parentNode){
    const name = (def && def.name ? String(def.name) : "Body") + "_simple";
    const r0 = (def && typeof def.radius === "number") ? def.radius : 5;
    const r = r0 * (typeof BODY_SCALE === "number" ? BODY_SCALE : 1.0);
    const seg = Math.max(16, Math.min(48, Math.floor(r * 1.2)));
    const m = BABYLON.MeshBuilder.CreateSphere(name, { diameter: r * 2, segments: seg }, scn);
    m.parent = parentNode;
    // Sitúala igual que el mesh real (que se coloca en def.orbitR)
    m.position.set((def && typeof def.orbitR === "number") ? def.orbitR : 0, 0, 0);
    m.isPickable = false;
    m.checkCollisions = false;

    // PBR: permite brillos especulares + reflejos (si hay environmentTexture en la escena)
    const pbr = new BABYLON.PBRMaterial(name + "_pbr", scn);

    // Color: usa el asignado en la definición si existe, si no, uno determinista por nombre.
    // Soporta: number (0xRRGGBB), string "#RRGGBB"/"0xRRGGBB", o BABYLON.Color3.
    const _toColor3 = (c) => {
      if (!c) return null;
      // Babylon Color3
      if (c.r != null && c.g != null && c.b != null && typeof c.r === "number") return new BABYLON.Color3(c.r, c.g, c.b);
      // number 0xRRGGBB
      if (typeof c === "number" && isFinite(c)) {
        const n = (c >>> 0);
        const rr = ((n >> 16) & 255) / 255;
        const gg = ((n >> 8) & 255) / 255;
        const bb = (n & 255) / 255;
        return new BABYLON.Color3(rr, gg, bb);
      }
      // string
      if (typeof c === "string") {
        const s = c.trim();
        // #RRGGBB
        if (s[0] === "#" && (s.length === 7 || s.length === 9)) {
          const hex = s.slice(1, 7);
          const n = parseInt(hex, 16);
          if (!isNaN(n)) return new BABYLON.Color3(((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255);
        }
        // 0xRRGGBB
        if (s.startsWith("0x") || s.startsWith("0X")) {
          const n = parseInt(s.slice(2), 16);
          if (!isNaN(n)) return new BABYLON.Color3(((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255);
        }
      }
      return null;
    };

    pbr.albedoColor = _toColor3(def && def.color) || _hashToColor3(def && def.name);
	// Ajusta "metallic/roughness" para controlar brillo y reflejo
    // (más “reflectante”/con brillo visible bajo luces)
    pbr.metallic = 0.05;
    pbr.roughness = 0.18;
    pbr.environmentIntensity = 1.2;
    m.material = pbr;

    // En builds "solo simples", se ven siempre desde el arranque.
    // En modo híbrido (simpleBodies toggle), arrancan ocultas.
    m.isVisible = !!simpleBuildOnly;

    // keep cheap
    // BUGFIX: era "mat" -> debe ser "pbr"
    if (pbr.freeze) pbr.freeze();
    m.alwaysSelectAsActiveMesh = true;
    m.doNotSyncBoundingInfo = true;
    return m;
  }


  // pseudo-random determinista (0..1) a partir de un string
  function _galRand01(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    h >>>= 0;
    return (h % 100000) / 100000;
  }

  function buildGalaxySystemPositions(systems) {
    const map = new Map();
    let spiralIndex = 0;

    // 1 LY -> unidades de escena (según galaxy.js)
    const LY_UNIT =
      (typeof GALAXY !== "undefined" &&
       GALAXY && GALAXY.system &&
       typeof GALAXY.system.__LY === "number")
        ? GALAXY.system.__LY
        : 1000;

    for (const sys of systems) {
      // Prioridad: sys.pos (ya en unidades de escena) > sys.posLY (en LY)
      if (sys && sys.pos && typeof sys.pos.x === "number" && typeof sys.pos.y === "number" && typeof sys.pos.z === "number") {
        // sys.pos ya está en unidades de escena: NO aplicar LY_UNIT aquí
        map.set(sys.id, sys.pos.clone().scale((typeof DIST_SCALE === "number" ? DIST_SCALE : 1.0)));
        continue;
      }

      if (sys && sys.posLY && typeof sys.posLY.x === "number" && typeof sys.posLY.y === "number" && typeof sys.posLY.z === "number") {
        // posLY está en años luz -> convertir a unidades de escena
        const scenePos = sys.posLY.clone().scale(
          LY_UNIT *
          (typeof SYSTEM_POS_SCALE === "number" ? SYSTEM_POS_SCALE : 1.0) *
          (typeof DIST_SCALE === "number" ? DIST_SCALE : 1.0)
        );
        // Unificamos: a partir de aquí sys.pos SIEMPRE en unidades de escena
        sys.pos = scenePos.clone();
        map.set(sys.id, scenePos);
        continue;
      }

      const i = spiralIndex++;
      const r = (GALAXY_LAYOUT.holeRadius + i * GALAXY_LAYOUT.radialStep) * (typeof DIST_SCALE === "number" ? DIST_SCALE : 1.0);
      const a = i * GALAXY_LAYOUT.angleStep;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;

      const j = (_galRand01("GALAXY_Y_" + sys.id) - 0.5) * 2.0;
      const y = j * GALAXY_LAYOUT.verticalJitter * (typeof DIST_SCALE === "number" ? DIST_SCALE : 1.0);

      map.set(sys.id, new BABYLON.Vector3(x, y, z).scale(GALAXY_LAYOUT.globalScale * (typeof DIST_SCALE === "number" ? DIST_SCALE : 1.0)));
    }
    return map;
  }

  const galaxyPosBySystemId = buildGalaxySystemPositions(extraSystems);

  // Debug / performance mode: render only a simple sphere per body
  let simpleBodiesEnabled = false;

  // -----------------------------
  // Lookup helpers
  // -----------------------------
  function findBodyByNameInSystem(name, systemId, preferredKind = "planet") {
    const n = _normName(name);
    if (!n) return null;
    for (const b of bodies.values()) {
      if (!b || !b.def) continue;
      if (b.def.systemId !== systemId) continue;
      if (_normName(b.def.name) !== n) continue;
      if (b.def.kind === preferredKind) return b;
    }
    for (const b of bodies.values()) {
      if (!b || !b.def) continue;
      if (b.def.systemId !== systemId) continue;
      if (_normName(b.def.name) === n) return b;
    }
    return null;
  }

  // Used by LOD module
  function relinkMoonsParent(parentKey, newParentMesh) {
    if (!parentKey || !newParentMesh) return;
    for (const [, mb] of bodies.entries()) {
      if (!mb || !mb.def) continue;
      if (mb.def.kind !== "moon") continue;
      if (mb.def.parentKey !== parentKey) continue;
      if (mb.orbitNode) mb.orbitNode.parent = newParentMesh;
    }
  }

  // -----------------------------
  // Per-system builders
  // -----------------------------
  function linkToLight(mesh, ocean, bodyRef) {
    if (!mesh) return;
    includeMeshInBodyLight(mesh, bodyRef);
    if (ocean) includeMeshInBodyLight(ocean, bodyRef);
  }

  function applyShadows(mesh, ocean, isCore) {
    if (!mesh) return;
    if (isCore) {
      shadowGen.addShadowCaster(mesh);
      mesh.receiveShadows = true;
      if (ocean) ocean.receiveShadows = false;
    } else {
      mesh.receiveShadows = false;
      if (ocean) ocean.receiveShadows = false;
    }
  }

  function createRings(def, planetMesh) {
    if (!def || !planetMesh) return null;
    if (!def.rings) return null;

    let rt = null;
    if (typeof def.ringTex === "string" && def.ringTex.startsWith("proc:")) {
      const mode = def.ringTex.split(":")[1] || "ion";
      const dyn = new BABYLON.DynamicTexture(def.name + "_ringDyn", { width: 512, height: 512 }, scn, false);
      const ctx = dyn.getContext();
      ctx.clearRect(0,0,512,512);

      const cx = 256, cy = 256;
      for (let y=0; y<512; y++) {
        for (let x=0; x<512; x++) {
          const dx = (x-cx)/256;
          const dy = (y-cy)/256;
          const r = Math.sqrt(dx*dx + dy*dy);
          if (mode === "dust") {
            if (r < 0.58 || r > 0.86) continue;
          } else {
            if (r < 0.40 || r > 1.02) continue;
          }

          let a = 0.0;
          if (mode === "dust") {
            a += Math.max(0, 1 - Math.abs(r - 0.70)/0.06) * 0.22;
            a += Math.max(0, 1 - Math.abs(r - 0.80)/0.05) * 0.16;
          } else {
            a += Math.max(0, 1 - Math.abs(r - 0.62)/0.10) * 0.35;
            a += Math.max(0, 1 - Math.abs(r - 0.78)/0.12) * 0.25;
            a += Math.max(0, 1 - Math.abs(r - 0.92)/0.06) * 0.18;
          }

          const stripe = (Math.sin((r*(mode === "dust" ? 180 : 120)) + (dx*18)) * 0.5 + 0.5);
          a *= (mode === "dust") ? (0.35 + stripe*0.35) : (0.55 + stripe*0.55);

          if (mode === "ion") {
            const speck = (Math.sin((x*12.9898 + y*78.233)) * 43758.5453);
            const rnd = speck - Math.floor(speck);
            if (rnd > 0.985) a += 0.25;
          }
          if (mode === "dust") {
            const speck = (Math.sin((x*7.9898 + y*23.233)) * 15731.5453);
            const rnd = speck - Math.floor(speck);
            if (rnd > 0.996) a += 0.08;
          }

          if (a <= 0.005) continue;
          let rr, gg, bb;
          if (mode === "dust") {
            rr = 210; gg = 190; bb = 145;
            a *= 0.55;
          } else {
            rr = 120; gg = 170; bb = 255;
          }
          ctx.fillStyle = `rgba(${rr},${gg},${bb},${Math.min(1,a)})`;
          ctx.fillRect(x,y,1,1);
        }
      }
      dyn.update();
      rt = dyn;
    } else {
      rt = loadTextureOrNull(scn, def.ringTex, { hasAlpha: true });
    }

    if (!rt) return null;

    const ringRadiusMul = (typeof def.ringRadiusMul === "number") ? def.ringRadiusMul : 3.3;
    const ringAlpha = (typeof def.ringAlpha === "number") ? def.ringAlpha : 0.95;
    const ringTint = def.ringTint || new BABYLON.Color3(0.95, 0.90, 0.80);

    const ring = makeRings(scn, planetMesh, {
      name: def.name + "_Rings",
      radius: def.radius * ringRadiusMul,
      tessellation: 128,
      tilt: (typeof def.ringTilt === "number") ? def.ringTilt : 0,
      texture: rt,
      alpha: ringAlpha,
      tint: ringTint,
      planetRadius: def.radius,
      shadowSoftness: (typeof def.ringShadowSoftness === "number") ? def.ringShadowSoftness : 0.04,
      shadowMin: (typeof def.ringShadowMin === "number") ? def.ringShadowMin : 0.12,
    });

    return ring;
  }

  function createStarSystem(sys, opts = {}) {
    const isCore = !!opts.core || sys.id === "Canopus";
    const root = new BABYLON.TransformNode("sys_" + sys.id, scn);
    if (WORLD_ROOT) root.parent = WORLD_ROOT;

    // ----------------------------------------------------------
    // NORMALIZA sys.star:
    // - Tu formato: sys.star = { "Sol": { ...props... } }
    // - Formato esperado aquí: sys.star = { name, radius, ... }
    // ----------------------------------------------------------
    if (!sys.star) sys.star = {};
    // Si sys.star parece un "mapa" con 1 única estrella ("Sol"), lo aplanamos.
    if (!sys.star.radius && !sys.star.name) {
      const keys = Object.keys(sys.star || {}).filter(k => k !== "kind" && k !== "systemId");
      if (keys.length === 1 && sys.star[keys[0]] && typeof sys.star[keys[0]] === "object") {
        const k = keys[0];
        const starDef = sys.star[k];
        sys.star = starDef;
        if (!sys.star.name) sys.star.name = k; // <- "Sol"
      }
    }
    if (!sys.star.kind) sys.star.kind = "sun";
    if (typeof sys.star.radius !== "number") sys.star.radius = 26;
    const _rawStarName = (typeof sys.star.name === "string") ? sys.star.name.trim() : "";
    const starName = _rawStarName || (sys.id ? (sys.id + " Star") : "Unknown Star");
    sys.star.name = starName;

    const gpos = galaxyPosBySystemId.has(sys.id)
      ? galaxyPosBySystemId.get(sys.id)
      : ((sys.pos || sys.posLY) || BABYLON.Vector3.Zero());
    root.position.copyFrom(gpos);

    // Guardar coordenada ABSOLUTA (galáctica) para floating origin “correcto”
    root.metadata = root.metadata || {};
    root.metadata.galaxyPos = gpos.clone();
    systemRoots.set(sys.id, root);

    const starSeg = isCore ? 64 : 48;
    const starRadius = (typeof sys.star.radius === "number" ? sys.star.radius : 26) * (typeof BODY_SCALE === "number" ? BODY_SCALE : 1.0);
    const star = BABYLON.MeshBuilder.CreateSphere(starName, { diameter: starRadius * 2, segments: starSeg }, scn);
    star.parent = root;
    star.position.set(0,0,0);
    star.isPickable = false;
    star.checkCollisions = false;
    star.alwaysSelectAsActiveMesh = true;
    star.doNotSyncBoundingInfo = true;

    if (isCore) {
      const sunMat = new BABYLON.PBRMaterial("sunMat", scn);
      sunMat.unlit = true;
      sunMat.emissiveColor = new BABYLON.Color3(1, 0.6, 0.1);
      const sunNoise = new BABYLON.NoiseProceduralTexture("sunNoise", 512, scn);
      sunNoise.animationSpeedFactor = 0.8;
      sunNoise.brightness = 0.5;
      sunMat.emissiveTexture = sunNoise;
      star.material = sunMat;

      const halo = BABYLON.MeshBuilder.CreatePlane("Canopus_Halo", { size: starRadius * 3.6 }, scn);
      halo.parent = star;
      halo.isPickable = false;
      halo.billboardMode = BABYLON.Mesh.BILLBOARDMODE_ALL;

      const haloTex = new BABYLON.DynamicTexture("haloTex", { width: 512, height: 512 }, scn, false);
      const ctx = haloTex.getContext();
      const g = ctx.createRadialGradient(256,256,0,256,256,256);
      g.addColorStop(0.00, "rgba(255,210,140,0.55)");
      g.addColorStop(0.25, "rgba(255,165, 70,0.22)");
      g.addColorStop(0.55, "rgba(255,120, 40,0.10)");
      g.addColorStop(1.00, "rgba(0,0,0,0.00)");
      ctx.fillStyle = g; ctx.fillRect(0,0,512,512);
      haloTex.update();

      const haloMat = new BABYLON.StandardMaterial("haloMat", scn);
      haloMat.diffuseTexture = haloTex;
      haloMat.emissiveTexture = haloTex;
      haloMat.opacityTexture = haloTex;
      haloMat.disableLighting = true;
      haloMat.backFaceCulling = false;
      haloMat.alpha = 0.75;
      haloMat.alphaMode = BABYLON.Engine.ALPHA_ADD;
      haloMat.needDepthPrePass = true;
      halo.material = haloMat;

      sunMeshRef.set(star);
      haloRef.set(halo);

      mainLitMeshes.push(star);
      sunLight.parent = star;
      sunLight.position.set(0,0,0);
      registerStarLight(star, sunLight);
    } else {
      const starMat = new BABYLON.StandardMaterial(starName + "_mat", scn);
      starMat.emissiveColor = sys.star.emissive || new BABYLON.Color3(1,0.9,0.7);
      starMat.diffuseColor = BABYLON.Color3.Black();
      starMat.specularColor = BABYLON.Color3.Black();
      starMat.disableLighting = true;
      star.material = starMat;
    }

    // Star dot sprite
    let starDot = null;
    if (starDotMgr) {
      const col = sys.star.emissive || new BABYLON.Color3(1, 0.9, 0.7);
      // OJO: root.position puede cambiar por floating origin -> guardamos basePos absoluta
      const spr = createStarDotSprite(starDotMgr, starName + "_dot", gpos, col, 1.0);
      spr.metadata = spr.metadata || {};
      spr.metadata.galaxyPos = gpos.clone();
      spr.renderingGroupId = 0;
      starDot = spr;
    }
    galaxyStarDots.push({ dot: starDot, star, radius: sys.star.radius, basePos: gpos.clone() });

    // Stable key for star
    sys.star.kind = sys.star.kind || "sun";
    sys.star.systemId = sys.id;
    const starKey = _bodyKey(sys.id, "sun", starName, "");
    sys.star._key = starKey;

    bodies.set(starKey, {
      id: starKey,
      def: sys.star,
      farMesh: star,
      ocean: null,
      atmo: null,
      ring: null,
      starRef: star,
      systemId: sys.id,
      orbitAngle: 0,
      orbitNode: null,
      proc: null,
    });

    if (!isCore) {
      createLocalSystemLight({
        systemId: sys.id,
        starMesh: star,
        root,
        intensity: sys.star.lightIntensity,
        range: sys.star.lightRange,
      });
    }

    // Planets
    // Asegura separación mínima entre órbitas para que no se monten (cuando los radios son grandes)
    const _starR = (typeof sys.star.radius === "number" ? sys.star.radius : 26) * (typeof BODY_SCALE === "number" ? BODY_SCALE : 1.0);
    let _lastOrbitR = _starR * 3.0;
    let _lastClear = _starR * 0.25;
    const _orbitMargin = 12;
    for (const pDef of (sys.planets || [])) {
      pDef._sysSpeed = sys.speedScale || 1;
      pDef.kind = "planet";
      pDef.systemId = sys.id;
      pDef.name = _normName(pDef.name);
      if (!pDef.name) { console.warn("[skip] planet sin nombre:", pDef, "en", sys.id); continue; }
      pDef.parentKey = starKey;
      pDef.parent = starName;

      // --- anti-solape: ajusta orbitR si es demasiado pequeña para el tamaño del planeta/anillos ---
      const rr0 = (typeof pDef.radius === "number") ? pDef.radius : 5;
      const rr = rr0 * (typeof BODY_SCALE === "number" ? BODY_SCALE : 1.0);
      const ringMul = (typeof pDef.ringRadiusMul === "number") ? pDef.ringRadiusMul : 0;
      const ringReach = ringMul > 0 ? (rr * ringMul * 1.05) : 0;
      const bodyReach = Math.max(rr * 2.2, ringReach);
      const wantMin = _lastOrbitR + _lastClear + bodyReach + _orbitMargin;
      if (typeof pDef.orbitR !== "number") pDef.orbitR = wantMin;
      else pDef.orbitR = Math.max(pDef.orbitR, wantMin);

      // Escala global de distancias (órbitas)
      if (typeof DIST_SCALE === "number" && isFinite(DIST_SCALE) && DIST_SCALE !== 1.0) {
        pDef.orbitR *= DIST_SCALE;
      }
      _lastOrbitR = pDef.orbitR;
      _lastClear = bodyReach;

      const pKey = _bodyKey(sys.id, "planet", pDef.name, starKey);
      pDef._key = pKey;

      const orbitNode = new BABYLON.TransformNode(pDef.name + "_orbit", scn);
      orbitNode.parent = root;
      orbitNode.position.set(0, 0, 0);
      orbitNodes.set(pKey, orbitNode);

let created = null;
let runtimeParams = null;

// Always create a cheap sphere (used either as fallback or as the only mesh in simpleBuildOnly)
const simpleMesh = createSimpleBodySphere(pDef, orbitNode);

let mesh = simpleMesh;
let ocean = null;

const isRocky = !(pDef.gasGiant || pDef.rocky === false);

if (!simpleBuildOnly) {
  if (isRocky && defaultPlanetParams) {
    const hasSpecific = !!pDef.jsonFile && planetParamsByName.has(pDef.name);
    const base = hasSpecific ? planetParamsByName.get(pDef.name) : defaultPlanetParams;
    runtimeParams = buildRuntimePlanetParams(base, pDef, {
      maxSubdiv: (isCore || hasSpecific) ? 7 : 5,
      minSubdiv: 2,
      forceSeedFromName: !hasSpecific,
      lockJsonParams: hasSpecific,
    });
    created = createJsonPlanet(scn, pDef, orbitNode, runtimeParams);
    pDef.useJsonPlanet = true;
  } else {
    created = createLowPolyFarPlanet(scn, pDef, orbitNode);
  }

  mesh  = created.land;
  ocean = created.ocean;
}

const bodyRefForLight = { starRef: star, systemId: sys.id };
const ring = (!simpleBuildOnly && isCore) ? createRings(pDef, mesh) : null;
      mesh.isPickable = false;
      if (ocean) ocean.isPickable = false;
      if (ring) ring.isPickable = false;

      applyShadows(mesh, ocean, isCore);
      linkToLight(mesh, ocean, bodyRefForLight);
	  
      // Si el modo simple está activado ya, no dejes visibles los meshes detallados
      if (simpleBodiesEnabled) {
        if (mesh) mesh.isVisible = false;
        if (ocean) ocean.isVisible = false;
        if (ring) ring.isVisible = false;
        if (simpleMesh) simpleMesh.isVisible = true;
      }


      bodies.set(pKey, {
        id: pKey,
        def: pDef,
        farMesh: mesh,
        simpleMesh: simpleMesh,
        ocean,
        ring,
        starRef: star,
        systemId: sys.id,
        orbitAngle: Math.random() * Math.PI * 2,
        orbitNode,
        proc: null,
        genParams: (isRocky && defaultPlanetParams) ? runtimeParams : null,

        isCore: !!isCore,
        lod: "low",
        lowMesh: mesh,
		lowSimpleMesh: simpleMesh,
        lowOcean: ocean,
        lowGenParams: (isRocky && defaultPlanetParams) ? runtimeParams : null,
        hiMesh: null,
        hiOcean: null,
      });

      if (!isCore) {
        if (mesh.material && mesh.material.freeze) mesh.material.freeze();
        if (ocean && ocean.material && ocean.material.freeze) ocean.material.freeze();
        if (ring && ring.material && ring.material.freeze) ring.material.freeze();
      }
    }

    // Moons
	const _lastMoonByParent = new Map(); // parentKey -> { r, clear }
    for (const mDef of (sys.moons || [])) {
      if (!mDef.parent) continue;
      mDef._sysSpeed = sys.speedScale || 1;

      mDef.kind = "moon";
      mDef.systemId = sys.id;
      mDef.name = _normName(mDef.name);
      mDef.parent = _normName(mDef.parent);
      if (!mDef.name || !mDef.parent) { console.warn("[skip] moon sin nombre/parent:", mDef, "en", sys.id); continue; }

      const parentBody = findBodyByNameInSystem(mDef.parent, sys.id, "planet");
      if (!parentBody) {
        console.warn("[moon] parent no encontrado:", mDef.parent, "para", mDef.name, "en", sys.id);
        continue;
      }

      const parentKey = parentBody.id || (parentBody.def && parentBody.def._key) || "";
      mDef.parentKey = parentKey;

      // --- anti-solape lunas: asegura orbitR suficiente alrededor del planeta ---
      const pr0 = (parentBody.def && typeof parentBody.def.radius === "number") ? parentBody.def.radius : 10;
      const pr = pr0 * (typeof BODY_SCALE === "number" ? BODY_SCALE : 1.0);
      const state = _lastMoonByParent.get(parentKey) || { r: pr * 1.8, clear: pr * 0.35 };
      const mr0 = (typeof mDef.radius === "number") ? mDef.radius : 1.0;
      const mr = mr0 * (typeof BODY_SCALE === "number" ? BODY_SCALE : 1.0);
      const mReach = mr * 2.4;
      const mMin = state.r + state.clear + mReach + 3.0;
      if (typeof mDef.orbitR !== "number") mDef.orbitR = mMin;
      else mDef.orbitR = Math.max(mDef.orbitR, mMin);

      // Escala global de distancias (órbitas)
      if (typeof DIST_SCALE === "number" && isFinite(DIST_SCALE) && DIST_SCALE !== 1.0) {
        mDef.orbitR *= DIST_SCALE;
      }
      state.r = mDef.orbitR;
      state.clear = mReach;
      _lastMoonByParent.set(parentKey, state);

      const mKey = _bodyKey(sys.id, "moon", mDef.name, parentKey);
      mDef._key = mKey;

      const moonOrbitNode = new BABYLON.TransformNode(mDef.name + "_moonOrbit", scn);
      moonOrbitNode.parent = parentBody.farMesh;
      moonOrbitNode.position.set(0,0,0);
      moonOrbitNodes.set(mKey, moonOrbitNode);

let created = null;
let runtimeParams = null;

const simpleMesh = createSimpleBodySphere(mDef, moonOrbitNode);

let mesh = simpleMesh;
let ocean = null;

const isRockyMoon = !(mDef.gasGiant || mDef.rocky === false);

if (!simpleBuildOnly) {
  if (isRockyMoon && defaultPlanetParams) {
    const hasSpecificMoon = !!mDef.jsonFile && planetParamsByName.has(mDef.name);
    const baseMoon = hasSpecificMoon ? planetParamsByName.get(mDef.name) : defaultPlanetParams;
    runtimeParams = buildRuntimePlanetParams(baseMoon, mDef, {
      maxSubdiv: (isCore || hasSpecificMoon) ? 6 : 4,
      minSubdiv: 2,
      forceSeedFromName: !hasSpecificMoon,
      lockJsonParams: hasSpecificMoon,
    });
    created = createJsonPlanet(scn, mDef, moonOrbitNode, runtimeParams);
    mDef.useJsonPlanet = true;
  } else {
    created = createLowPolyFarPlanet(scn, mDef, moonOrbitNode);
  }

  mesh  = created.land;
  ocean = created.ocean;
}

const bodyRefForLight = { starRef: star, systemId: sys.id };
      mesh.isPickable = false;
      if (ocean) ocean.isPickable = false;

      applyShadows(mesh, ocean, isCore);
      linkToLight(mesh, ocean, bodyRefForLight);
	  
      if (simpleBodiesEnabled) {
        if (mesh) mesh.isVisible = false;
        if (ocean) ocean.isVisible = false;
        if (simpleMesh) simpleMesh.isVisible = true;
      }

      bodies.set(mKey, {
        id: mKey,
        def: mDef,
        farMesh: mesh,
        simpleMesh: simpleMesh,
        landMesh: mesh,
        mesh: mesh,
        ocean,
        ring: null,
        starRef: star,
        systemId: sys.id,
        orbitAngle: Math.random() * Math.PI * 2,
        orbitNode: moonOrbitNode,
        proc: null,
        genParams: (isRockyMoon && defaultPlanetParams) ? runtimeParams : null,

        isCore: !!isCore,
        lod: "low",
        lowMesh: mesh,
        lowOcean: ocean,
        lowGenParams: (isRockyMoon && defaultPlanetParams) ? runtimeParams : null,
        hiMesh: null,
        hiOcean: null,
      });

      if (!isCore) {
        if (mesh.material && mesh.material.freeze) mesh.material.freeze();
        if (ocean && ocean.material && ocean.material.freeze) ocean.material.freeze();
      }
    }

    if (!isCore) {
      star.freezeWorldMatrix();
      star.doNotSyncBoundingInfo = true;
      if (star.material && star.material.freeze) star.material.freeze();
    }
  }

  
  
  function setSimpleBodies(enabled){
    simpleBodiesEnabled = !!enabled;

    // If we built ONLY simple spheres, just ensure they stay visible.
    // (No detailed meshes exist to show/hide.)
    const builtOnlySimple = !!simpleBuildOnly;

    for (const b of bodies.values()) {
      if (!b) continue;
      // No tocar estrellas (o si quieres, dime y también las convierto a esfera simple)
      if (b.def && (b.def.kind === "sun" || b.def.kind === "star")) continue;

      const sm = b.simpleMesh || null;
      const mesh = b.farMesh || null;
      const ocean = b.ocean || null;
      const ring = b.ring || null;
	  const on = b.orbitNode || null;

      // If farMesh is the same object as simpleMesh (simpleBuildOnly),
      // do not accidentally hide it.
      const hasSeparateDetailed = (mesh && sm && mesh !== sm);

      if (builtOnlySimple) {
        if (sm) sm.isVisible = true;
        if (hasSeparateDetailed) mesh.isVisible = false;
        if (ocean) ocean.isVisible = false;
        if (ring) ring.isVisible = false;
        continue;
      }

      if (!sm) continue;

      if (simpleBodiesEnabled) {
        // 1) Desactiva absolutamente todo lo que cuelga del orbitNode (atmósferas, nubes, LODs, etc.)
        // Usamos setEnabled(false) para que NO se “re-encienda” por otros sistemas (LOD/atmo updates).
        if (on && typeof on.getChildMeshes === "function") {
          const children = on.getChildMeshes(false);
          for (const cm of children) {
            if (cm === sm) continue;
            _setEnabledRemember(cm, false);
          }
        }

        // 2) Desactiva explícitamente los conocidos (por si no cuelgan del orbitNode)
        if (mesh && mesh !== sm) _setEnabledRemember(mesh, false);
        if (ocean) _setEnabledRemember(ocean, false);
        if (ring) _setEnabledRemember(ring, false);

        // 3) Asegura la esfera simple encendida
        _setEnabledRemember(sm, true);
        sm.isVisible = true;
      } else {
        // Volver a modo normal: restauramos enabled state previo y escondemos la esfera simple
        if (on && typeof on.getChildMeshes === "function") {
          const children = on.getChildMeshes(false);
          for (const cm of children) _restoreEnabled(cm);
        }
        _restoreEnabled(mesh);
        _restoreEnabled(ocean);
        _restoreEnabled(ring);

        // La esfera simple queda apagada (pero no destruida)
        _setEnabledRemember(sm, false);
        sm.isVisible = false;
      }
    }
  }

function buildAll() {
    for (const sys of extraSystems) {
      createStarSystem(sys, { core: sys.id === "Canopus" });
    }
    return {
      galaxyPosBySystemId,
      relinkMoonsParent,
      normName: _normName,
      bodyKey: _bodyKey,
    };
  }

  return { buildAll, setSimpleBodies, relinkMoonsParent, normName: _normName, bodyKey: _bodyKey };
}