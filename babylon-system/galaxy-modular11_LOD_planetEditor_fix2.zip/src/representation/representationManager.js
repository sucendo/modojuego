// representation/representationManager.js
// Universal pixel-size LOD manager.
//
// Rules (diameter in pixels):
//   <3px        -> OFF (labels disabled)
//   3–10px      -> IMPOSTOR (billboard)
//   10–40px     -> MESH LOW
//   40–120px    -> JSON PLANET LOW
//   120–240px   -> JSON PLANET MED
//   >=240px     -> JSON PLANET HIGH
//
// Notes:
// - Integrates with orbitAnimator by targeting stable TransformNodes (bodyNode).
// - Does NOT recalc all entities every frame (round-robin + budgets).
// - Uses a transition queue and a planet-editor job queue with budgets.

import { getDefaultRepresentationProfiles } from './representationProfiles.js';
import { computeDiameterPx } from './screenSpace.js';
import { createImpostorRep, createMeshLowRep } from './repFactories.js';
import { createPlanetEditorProvider } from './planetEditorProvider.js';

const BABYLON = globalThis.BABYLON;
if (!BABYLON) throw new Error('[repMgr] BABYLON global is required');

function _keyOf(kind, systemName, bodyId) {
  return `${kind}:${systemName || ''}:${String(bodyId)}`;
}

function _safeColor3(c) {
  try { if (c && c.r !== undefined) return c; } catch (_) {}
  return null;
}

const STATE_ORDER = {
  off: 0,
  impostor: 1,
  mesh_low: 2,
  json_low: 3,
  json_med: 4,
  json_high: 5,
};

function isUpgrade(from, to) {
  return (STATE_ORDER[to] || 0) > (STATE_ORDER[from] || 0);
}

function clamp(v, a, b) {
  return Math.max(a, Math.min(b, v));
}

function decideUniversalState(dpx, thr) {
  if (dpx < thr.off) return 'off';
  if (dpx < thr.impostor) return 'impostor';
  if (dpx < thr.meshLow) return 'mesh_low';
  if (dpx < thr.jsonLow) return 'json_low';
  if (dpx < thr.jsonMed) return 'json_med';
  return 'json_high';
}

function applyHysteresis(entry, desired, dpx, thr, hRatio) {
  const cur = entry.activeState || 'off';
  if (cur === desired) return desired;

  const h = clamp(Number(hRatio || 0.12), 0, 0.5);

  // Map states to their boundary thresholds.
  // Each boundary is the upper limit of the previous state.
  const boundaryOf = {
    off: thr.off,
    impostor: thr.impostor,
    mesh_low: thr.meshLow,
    json_low: thr.jsonLow,
    json_med: thr.jsonMed,
    json_high: Infinity,
  };

  // Moving up: require crossing above current boundary by +h.
  if (isUpgrade(cur, desired)) {
    const b = boundaryOf[cur];
    if (Number.isFinite(b) && dpx < (b * (1 + h))) return cur;
    return desired;
  }

  // Moving down: require crossing below desired boundary by -h.
  const b2 = boundaryOf[desired];
  if (Number.isFinite(b2) && dpx > (b2 * (1 - h))) return cur;
  return desired;
}

function setEnabledSafe(nodeOrMesh, enabled) {
  if (!nodeOrMesh) return;
  try {
    if (typeof nodeOrMesh.setEnabled === 'function') nodeOrMesh.setEnabled(!!enabled);
    else if (typeof nodeOrMesh.isVisible === 'boolean') nodeOrMesh.isVisible = !!enabled;
  } catch (_) {}
}

function setLabelEnabled(labelsApi, key, enabled) {
  if (!labelsApi || !key) return;
  if (typeof labelsApi.setLabelEnabled === 'function') {
    try { labelsApi.setLabelEnabled(key, !!enabled); } catch (_) {}
  }
}

function tagLabelKey(nodeOrMesh, labelKey) {
  if (!nodeOrMesh || !labelKey) return;
  try {
    nodeOrMesh.metadata = Object.assign({}, nodeOrMesh.metadata, { labelKey });
  } catch (_) {}
}

function tagLabelOnHierarchy(root, labelKey) {
  if (!root || !labelKey) return;
  // Root itself
  tagLabelKey(root, labelKey);
  // Child meshes
  try {
    const kids = root.getChildMeshes ? root.getChildMeshes(false) : null;
    if (kids && kids.length) {
      for (const m of kids) tagLabelKey(m, labelKey);
    }
  } catch (_) {}
}

export function createRepresentationManager({ scene, engine, camera, labelsApi, lights, profiles, opts = {} }) {
  if (!scene || !engine || !camera) throw new Error('[repMgr] scene/engine/camera required');

  const PROFILES = profiles || getDefaultRepresentationProfiles();
  const THR = PROFILES.__thresholdsPx || { off: 3, impostor: 10, meshLow: 40, jsonLow: 120, jsonMed: 240 };

  const CONFIG = {
    // Evaluation scheduling
    evalIntervalMs: (typeof opts.evalIntervalMs === 'number') ? opts.evalIntervalMs : 50,
    evalBudgetMs: (typeof opts.evalBudgetMs === 'number') ? opts.evalBudgetMs : 0.8,
    evalMaxPerTick: (typeof opts.evalMaxPerTick === 'number') ? opts.evalMaxPerTick : 250,

    // Transition scheduling
    transitionBudgetMs: (typeof opts.transitionBudgetMs === 'number') ? opts.transitionBudgetMs : 1.5,
    transitionMaxPerTick: (typeof opts.transitionMaxPerTick === 'number') ? opts.transitionMaxPerTick : 6,

    hysteresisRatio: (typeof opts.hysteresisRatio === 'number') ? opts.hysteresisRatio : 0.12,

    // Planet-editor JSON base URL (where jsonFile is served)
    planetEditorBaseUrl: (typeof opts.planetEditorBaseUrl === 'string') ? opts.planetEditorBaseUrl : './',

    // Whether OFF disables the mesh too (recommended)
    offDisablesMesh: (typeof opts.offDisablesMesh === 'boolean') ? opts.offDisablesMesh : true,
    // OFF always disables labels per your rules
    offDisablesLabels: true,

    // Initial representation (cheap)
    initialState: opts.initialState || 'impostor',
    createInitialRep: (typeof opts.createInitialRep === 'boolean') ? opts.createInitialRep : true,
  };

  const entries = new Map();
  const keyList = [];
  let rrCursor = 0;

  const transitionQueue = [];

  const planetProvider = createPlanetEditorProvider({
    scene,
    lights,
    baseUrl: CONFIG.planetEditorBaseUrl,
    profiles: PROFILES,
    opts: { maxCached: 24 },
  });

  let _lastEval = 0;

  function getProfile(kind) {
    return (PROFILES && PROFILES[kind]) ? PROFILES[kind] : (PROFILES.__defaults || {});
  }

  function canUsePlanetEditor(entry) {
    return !!(entry && entry.planetEditorJsonFile);
  }

  function mapStateToCapabilities(entry, desired) {
    // JSON LOD requires jsonFile.
    if ((desired === 'json_low' || desired === 'json_med' || desired === 'json_high') && !canUsePlanetEditor(entry)) {
      return 'mesh_low';
    }
    return desired;
  }

  function ensureRep(entry, state) {
    if (!entry || !state) return null;
    if (entry.reps[state]) return entry.reps[state];

    const prof = entry.profile;
    let rep = null;

    if (state === 'impostor') {
      rep = createImpostorRep({ scene, entry, profile: prof });
      rep.parent = entry.bodyNode;
      rep.billboardMode = BABYLON.Mesh.BILLBOARDMODE_ALL;
      rep.isPickable = false;
      // Scale to physical diameter (so the swap to mesh_low doesn't pop)
      const d = Math.max(0.001, entry.radiusWorld * 2);
      try { rep.scaling.set(d, d, 1); } catch (_) {}
    } else if (state === 'mesh_low') {
      rep = createMeshLowRep({ scene, entry, profile: prof });
      rep.parent = entry.bodyNode;
      rep.isPickable = false;
    } else if (state === 'json_low' || state === 'json_med' || state === 'json_high') {
      // Built by provider, async + job queue.
      rep = null;
    }

    if (rep) {
      // metadata
      rep.metadata = Object.assign({}, rep.metadata, {
        kmPerUnit: entry.kmPerUnit,
        systemName: entry.systemName,
        bodyId: entry.bodyId,
        kind: entry.kind,
        repState: state,
      });
      if (entry.label?.key) rep.metadata.labelKey = entry.label.key;

      setEnabledSafe(rep, false);

      // Light linking (meshes only)
      if (lights && typeof lights.includeMesh === 'function' && entry.profile?.lit !== false) {
        try { lights.includeMesh(entry.systemName, rep); } catch (_) {}
      }

      entry.reps[state] = rep;
    }

    return rep;
  }

  function disableAllReps(entry) {
    if (!entry) return;
    for (const st of Object.keys(entry.reps)) {
      const r = entry.reps[st];
      if (!r) continue;
      setEnabledSafe(r, false);
    }
    // Provider root (JSON) is enabled/disabled via provider
    if (canUsePlanetEditor(entry)) {
      planetProvider.setEnabled(entry, false);
    }
  }

  function activateState(entry, state) {
    if (!entry) return;

    // Labels rule
    if (entry.label?.key) {
      if (state === 'off' && CONFIG.offDisablesLabels) setLabelEnabled(labelsApi, entry.label.key, false);
      else setLabelEnabled(labelsApi, entry.label.key, true);
    }

    if (state === 'off') {
      if (CONFIG.offDisablesMesh) {
        disableAllReps(entry);
      }
      entry.activeState = 'off';
      return;
    }

    // Ensure rep exists for cheap states
    if (state === 'impostor' || state === 'mesh_low') {
      disableAllReps(entry);
      const r = ensureRep(entry, state);
      if (r) {
        setEnabledSafe(r, true);
        tagLabelOnHierarchy(r, entry.label?.key);
      }
      entry.activeState = state;
      return;
    }

    // JSON states
    const quality = (state === 'json_low') ? 'low' : (state === 'json_med') ? 'med' : 'high';
    planetProvider.request(entry, quality);

    // If ready, enable and switch
    const root = planetProvider.getRootIfReady(entry, quality);
    if (root) {
      disableAllReps(entry);
      planetProvider.setEnabled(entry, true);
      tagLabelOnHierarchy(root, entry.label?.key);
      entry.activeState = state;
    } else {
      // Not ready: fallback to mesh_low but keep desired json in entry.desiredState
      const fallback = (entry.lastDpx >= THR.meshLow) ? 'mesh_low' : 'impostor';
      if (entry.activeState !== fallback) {
        activateState(entry, fallback);
      }
    }
  }

  function enqueueTransition(entry, nextState) {
    if (!entry) return;
    // De-dup by entry key (keep latest request)
    const k = entry.key;
    const idx = transitionQueue.findIndex(t => t.entryKey === k);
    const item = { entryKey: k, nextState };
    if (idx >= 0) transitionQueue[idx] = item;
    else transitionQueue.push(item);
  }

  function runTransitions() {
    const t0 = performance.now();
    let done = 0;

    // Prioritize downgrades first
    transitionQueue.sort((a, b) => {
      const ea = entries.get(a.entryKey);
      const eb = entries.get(b.entryKey);
      const ca = ea?.activeState || 'off';
      const cb = eb?.activeState || 'off';
      const da = isUpgrade(ca, a.nextState) ? 1 : 0;
      const db = isUpgrade(cb, b.nextState) ? 1 : 0;
      return da - db;
    });

    while (transitionQueue.length && done < CONFIG.transitionMaxPerTick) {
      if ((performance.now() - t0) > CONFIG.transitionBudgetMs) break;
      const t = transitionQueue.shift();
      const e = entries.get(t.entryKey);
      if (!e) continue;
      if (e.activeState === t.nextState) continue;

      activateState(e, t.nextState);
      done++;
    }

    // Planet-editor heavy jobs
    planetProvider.runJobs({ budgetMs: CONFIG.transitionBudgetMs, maxJobs: 1 });
  }

  function registerEntity(params) {
    const {
      kind,
      systemName,
      bodyId,
      bodyNode,
      radiusKm,
      kmPerUnit,
      color,
      label,
      // NEW: planet-editor json file name / URL
      planetEditorJsonFile,
    } = params || {};

    if (!kind || !bodyNode) throw new Error('[repMgr] registerEntity requires kind/bodyNode');

    const kmPU = (typeof kmPerUnit === 'number' && kmPerUnit > 0) ? kmPerUnit : (bodyNode?.metadata?.kmPerUnit || 1e6);
    const rKm = Number(radiusKm);
    const rWorld = (Number.isFinite(rKm) && rKm > 0) ? (rKm / kmPU) : (bodyNode?.metadata?.radiusWorld || 0.001);

    const entry = {
      key: _keyOf(kind, systemName, bodyId),
      kind,
      systemName: systemName || (bodyNode?.metadata?.systemName || ''),
      bodyId: bodyId || bodyNode?.metadata?.bodyId,
      bodyNode,
      kmPerUnit: kmPU,
      radiusKm: Number.isFinite(rKm) ? rKm : null,
      radiusWorld: Number.isFinite(rWorld) ? rWorld : 0.001,
      color: _safeColor3(color) || null,
      profile: getProfile(kind),
      label: label || null,
      planetEditorJsonFile: planetEditorJsonFile || null,

      reps: {
        impostor: null,
        mesh_low: null,
        // json states are managed by provider
        json_low: null,
        json_med: null,
        json_high: null,
      },

      activeState: 'off',
      desiredState: 'off',
      lastDpx: 0,
    };

    // Ensure physical metadata always present
    try {
      bodyNode.metadata = Object.assign({}, bodyNode.metadata, {
        kmPerUnit: entry.kmPerUnit,
        systemName: entry.systemName,
        bodyId: entry.bodyId,
        kind: entry.kind,
        radiusKm: entry.radiusKm,
        radiusWorld: entry.radiusWorld,
      });
    } catch (_) {}

    entries.set(entry.key, entry);
    keyList.push(entry.key);

    // Initial state
    if (CONFIG.createInitialRep) {
      const init = mapStateToCapabilities(entry, CONFIG.initialState);
      activateState(entry, init);
      entry.desiredState = init;
    }

    // Ensure label is initially enabled (unless OFF)
    if (entry.label?.key) setLabelEnabled(labelsApi, entry.label.key, entry.activeState !== 'off');

    return entry;
  }

  function update(dtSec = 0) {
    // Provider runtime updates (cloud animation, etc.)
    try { planetProvider.updateActiveClouds(dtSec); } catch (_) {}

    const now = performance.now();
    if ((now - _lastEval) < CONFIG.evalIntervalMs) {
      runTransitions();
      return;
    }
    _lastEval = now;

    const t0 = performance.now();
    const n = keyList.length;
    if (!n) {
      runTransitions();
      return;
    }

    let checked = 0;
    while (checked < CONFIG.evalMaxPerTick) {
      if ((performance.now() - t0) > CONFIG.evalBudgetMs) break;

      const key = keyList[rrCursor];
      rrCursor = (rrCursor + 1) % n;
      checked++;

      const entry = entries.get(key);
      if (!entry) continue;

      const bodyNode = entry.bodyNode;
      const worldPos = bodyNode.getAbsolutePosition ? bodyNode.getAbsolutePosition() : bodyNode.position;
      if (!worldPos) continue;

      const dpx = computeDiameterPx({ engine, camera, worldPos, radiusWorld: entry.radiusWorld });
      entry.lastDpx = dpx;

      let desired = decideUniversalState(dpx, THR);
      desired = mapStateToCapabilities(entry, desired);
      desired = applyHysteresis(entry, desired, dpx, THR, CONFIG.hysteresisRatio);

      entry.desiredState = desired;

      if (desired !== entry.activeState) {
        enqueueTransition(entry, desired);
      }
    }

    runTransitions();
  }

  function getEntry(kind, systemName, bodyId) {
    return entries.get(_keyOf(kind, systemName, bodyId)) || null;
  }

  return {
    registerEntity,
    update,
    getEntry,
    config: CONFIG,
    profiles: PROFILES,
  };
}
