// representation/representationProfiles.js
// Profiles and caps used by the pixel-size LOD system.
//
// IMPORTANT:
// - LOD decision is UNIVERSAL and based ONLY on screen-space diameter in pixels.
// - Profiles here are used only for capabilities and quality caps (segments, json presets, etc.).

export function getDefaultRepresentationProfiles() {
  return {
    // Universal thresholds (diameter in pixels)
    __thresholdsPx: {
      off: 3,         // <3px
      impostor: 10,   // 3–10
      meshLow: 40,    // 10–40
      jsonLow: 120,   // 40–120
      jsonMed: 240,   // 120–240
      // >=240 => jsonHigh
    },

    // Defaults used when a kind is missing
    __defaults: {
      impostorDisableLighting: true,
      meshLowSegments: 10,
      lit: true,
      // Planet-editor quality caps (subdivisions are VERY expensive)
      jsonSubdivCap: {
        low: 18,
        med: 32,
        high: 64,
      },
      // Feature toggles applied on top of loaded planet-editor params
      jsonPreset: {
        low: {
          ringsEnabled: false,
          atmoEnabled: false,
          cloudLayerEnabled: false,
          wireframe: false,
        },
        med: {
          ringsEnabled: true,
          atmoEnabled: false,
          cloudLayerEnabled: false,
          wireframe: false,
        },
        high: {
          ringsEnabled: true,
          atmoEnabled: false,
          cloudLayerEnabled: true,
          wireframe: false,
        },
      },
    },

    // Stars: we never build JSON planets; just impostor/mesh.
    star: {
      lit: false,
      impostorDisableLighting: true,
      meshLowSegments: 14,
    },

    // Planets/moons: can use planet-editor JSON if jsonFile exists.
    planet: {
      lit: true,
      meshLowSegments: 12,
    },
    moon: {
      lit: true,
      meshLowSegments: 10,
    },

    // Small bodies (fallback to impostor/mesh unless you provide jsonFile).
    asteroid: {
      lit: true,
      meshLowSegments: 8,
    },
    comet: {
      lit: true,
      meshLowSegments: 8,
    },
    artificialSatellite: {
      lit: true,
      meshLowSegments: 8,
    },
  };
}
