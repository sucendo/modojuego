import { SYSTEMS } from '../data/systems.js';
import { GALAXY } from '../data/galaxy.js';
import { createEngine } from '../core/engine.js';
import { createFloatingOrigin } from '../core/floatingOrigin.js';
import { initHudToggles } from '../ui/hudToggles.js';
import { setupLights } from './lights.js';
import { setupCamera } from './camera.js';
import { createLabels } from '../ui/labels.js';
import { createEliteHud } from '../ui/eliteHud.js';
import { createNavigationGridController } from '../ui/navGrid.js';
import { buildSystemNodes } from '../bodies/systems.js';
import { buildStars } from '../bodies/stars.js';
import { buildPlanets } from '../bodies/planets.js';
import { updateOrbits } from '../bodies/orbitAnimator.js';
import { createSystemDotScaler } from '../ui/systemDots.js'
import { createRepresentationManager } from '../representation/representationManager.js';

export function bootstrap() {
  const canvas = document.getElementById('renderCanvas');
  const engine = createEngine(canvas);

  const scene = new BABYLON.Scene(engine);
  // Perf: si no haces picking por “hover”, esto ahorra CPU
  scene.skipPointerMovePicking = true;
  scene.constantlyUpdateMeshUnderPointer = false;

  // ============================================================
  // TIME SCALE
  // Tiempo real: 1 segundo real = 1 segundo simulado.
  // Los orbitalPeriod/rotationPeriod están en *días*, así que convertimos:
  //   dtDays = dtSeconds / 86400
  // ============================================================
  const DAYS_PER_REAL_SECOND = 1.0 / 86400.0;

  // ============================================================
  // Fondo negro garantizado
  // ============================================================
  scene.autoClear = true;
  scene.autoClearDepthAndStencil = true;
  scene.clearColor = new BABYLON.Color4(0, 0, 0, 1);
  scene.environmentTexture = null;
  try { engine.getRenderingCanvas().style.background = '#000'; } catch (e) {}

  // ============================================================
  // ROOT del mundo
  // ============================================================
  const worldRoot = new BABYLON.TransformNode('worldRoot', scene);

  // ============================================================
  // Lights + Camera
  // ============================================================
  const lights = setupLights(scene, { hemiIntensity: 0.10 });
  const unitsPerLy =
    (GALAXY?.system && Number.isFinite(GALAXY.system.__LY)) ? GALAXY.system.__LY :
    (Number.isFinite(SYSTEMS?.__LY)) ? SYSTEMS.__LY :
    1_000_000;
  const camCfg = setupCamera(scene, canvas, {
    baseSpeed: 100.0,
    fastMult: 1000.0,
    unitsPerLy,
    // Evita que salga el mini panel antiguo de camera.js (ya tenemos HUD Elite)
    enableModeUI: false
  });
  const camera = camCfg.camera;
  
  const camCtrl = camCfg.controller;
  window.__camCtrl = camCtrl;

  // Shift/turbo ya lo gestiona camera.js (state.isFast). No duplicar handlers aquí.

  // Ajustes cámara (si setupCamera ya los fija, esto solo los sobreescribe)
  camera.position.set(2, 50, -540);
  camera.angularSensibility = 3500;
  camera.inertia = 0.0;
  camera.angularInertia = 0.0;
  camera.keysUp = [87];      // W
  camera.keysDown = [83];    // S
  camera.keysLeft = [65];    // A
  camera.keysRight = [68];   // D
  camera.keysUpward = [32];  // Space
  camera.keysDownward = [17];// Ctrl
  camera.minZ = 1e-6;
  camera.maxZ = 5e9;

  // ============================================================
  // Labels API
  // ============================================================
  const labelsApi = createLabels({ scene, camera, engine });

  // ============================================================
  // Representation Manager (pixel-based visual LOD)
  // - Keeps physics/orbits untouched (targets TransformNodes)
  // - Swaps visual meshes under each body node
  // ============================================================
  const repMgr = createRepresentationManager({
    scene,
    engine,
    camera,
    labelsApi,
    lights,
    opts: {
      evalIntervalMs: 50,
      evalBudgetMs: 0.8,
      evalMaxPerTick: 250,
      transitionBudgetMs: 2.5,
      transitionMaxPerTick: 4,
      hysteresisRatio: 0.12,
      initialState: 'impostor',
      createInitialRep: true,
      planetEditorBaseUrl: './',
      offDisablesMesh: true,
    },
  });

  // ============================================================
  // Builders (extraídos)
  // ============================================================
  const KM_PER_UNIT_LOCAL = 1e6;
  const starMeshById = new Map();

  const { systemNodes, lyUnits } = buildSystemNodes({ scene, worldRoot, GALAXY, SYSTEMS, labelsApi });
  camCtrl?.setUnitsPerLy?.(lyUnits);
  const starsApi = buildStars({ scene, systemNodes, GALAXY, lights, labelsApi, starMeshById, repMgr, kmPerUnitLocal: KM_PER_UNIT_LOCAL });
  const { planetSystems } = buildPlanets({ scene, systemNodes, starMeshById, GALAXY, lights, labelsApi, repMgr, kmPerUnitLocal: KM_PER_UNIT_LOCAL });

  const systemDotScaler = createSystemDotScaler({
    engine, camera, systemNodes,
    opts: { minPx: 2.0, throttleMs: 80 },
  });

  // ============================================================
  // Floating Origin
  // ============================================================
  const floating = createFloatingOrigin({ scene, camera, worldRoot });

  // ============================================================
  // NavGrid (UI helper): anclado al Sol/Al-Lat (NO sigue cámara)
  // ============================================================
  const solIt = systemNodes.find(s => s?.name === 'Al-Lat' || s?.name === 'Sol') || null;
  const navGrid = createNavigationGridController({
    scene, worldRoot, camera,
    opts: {
      // PERF: usa el modo fixedAnchor del controller para evitar trabajo por frame.
      fixedAnchor: true,
      getAnchorPosition: () => solIt?.system?.getAbsolutePosition?.() || BABYLON.Vector3.Zero(),
      throttleMs: 120,
      autoCenter: false,
      followY: false,
      includeYZ: true,
      step: 250000,
      extent: 25000000,
      maxLinesPerAxis: 401,
      rebuildDistance: 0,
    }
  });
  
  // ============================================================
  // Elite HUD (crea DOM: th/abs/cam/off + toggles + botones)
  // ============================================================
  const eliteHud = createEliteHud({
    camera,
    engine,
    floating,
    labelsApi,
    gridController: navGrid,
    camCtrl,
    // mountId: 'eliteHudMount', // opcional; si no existe, cae a document.body
  });

  // ============================================================
  // HUD toggles
  // ============================================================
  initHudToggles({
    setShowLabels: labelsApi.setShowLabels,
    gridController: navGrid,
  });

  // ============================================================
  // Planet Editor (integrated, separate app)
  // Shift+P opens ./tools/planet-editor/index.html
  // ============================================================
  function __openPlanetEditor(){
    try {
      window.open('./tools/planet-editor/index.html', '_blank', 'noopener');
    } catch (_) {}
  }
  window.addEventListener('keydown', (e) => {
    if (!e) return;
    if (e.code === 'KeyP' && e.shiftKey) {
      e.preventDefault();
      __openPlanetEditor();
    }
  });


  // Throttles for heavy tickers
  let orbitAccDays = 0;
  let orbitLastT = 0;
  const ORBIT_MS = 33; // ~30Hz
  let binAccSec = 0;
  let binLastT = 0;
  const BIN_MS = 33;

  scene.onBeforeRenderObservable.add(() => {
    const dtSec = engine.getDeltaTime() * 0.001;
    camCtrl.update(dtSec);

    floating.apply();

    // Grid anclado (internamente hace early-exit si no hay cambios)
    if (navGrid?.enabled) navGrid.update();

    // Sombras dinámicas (si tu lights.js lo tiene)
    if (typeof lights.updateNearestSystemShadows === 'function') {
      lights.updateNearestSystemShadows();
    }


    // Binarios/trinarios (throttle)
    if (starsApi?.updateBinaries) {
      const now = performance.now();
      binAccSec += dtSec;
      if ((now - binLastT) >= BIN_MS) {
        starsApi.updateBinaries(binAccSec);
        binAccSec = 0;
        binLastT = now;
      }
    }

    // Órbitas
    const dtDays = dtSec * DAYS_PER_REAL_SECOND;
    orbitAccDays += dtDays;
    const nowO = performance.now();
    if ((nowO - orbitLastT) >= ORBIT_MS) {
      // Estrellas binarias/trinarias con órbita kepleriana
      if (starsApi?.starSystems?.length) updateOrbits(starsApi.starSystems, orbitAccDays);
      updateOrbits(planetSystems, orbitAccDays);
      orbitAccDays = 0;
      orbitLastT = nowO;
    }

    // LOD + labels after orbits (fresh positions)
    systemDotScaler.update();
    repMgr.update();

    // HUD debug floating origin
    if (typeof floating.updateHud === 'function') floating.updateHud();

    // Elite HUD (modo, velocidad, fullscreen icon, etc.)
    eliteHud?.update?.();
  });

  engine.runRenderLoop(() => scene.render());
  window.addEventListener('resize', () => engine.resize());
}
