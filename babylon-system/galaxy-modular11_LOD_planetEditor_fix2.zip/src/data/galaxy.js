import { SYSTEMS } from './systems.js';

export const GALAXY = {
      // ============================================================
      // SYSTEMS: coordenadas fijas en LY (1 LY = __LY unidades de escena)
      // ============================================================
      system: SYSTEMS,
    
      // ============================================================
      // STARS: una o varias por system (binarios/trinarios: añades más)
      // starId es la KEY. "orbits" apunta SIEMPRE al systemId.
      // ============================================================
      star: {
        "Sol": {
          // orbital
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          // physical / visual
          size: 696340,
          color: 0xf6f6f6,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 7.25,
          rotationPeriod: 27.5,
    
          // hierarchy
          orbits: "Al-Lat",
    
          // engine extras
          kind: "sun",
          radius: 20,
          emissive: new BABYLON.Color3(0.95, 0.90, 0.78),
        },
    
        "Canopus": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
    	  // Ajustado para que Arrakis (a 87M km) esté fuera y sea habitable
    	  // Un radio de ~15M km permite una visualización épica sin "comerse" al planeta
    	  // Radio escalado (9M es el límite de Seban; usamos 7.65M para dejar espacio)
          size: 7650000,
          color: 0xffffff, // Blanco puro (Supergigante Clase A)
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 300,
    
          orbits: "Canopus",
    
          kind: "sun",
          radius: 152.3,
          emissive: new BABYLON.Color3(1.0, 0.95, 0.85),
        },
    
		"Alpha Centauri A": {
		  periapsis: 0,
		  apoapsis: 0,
		  orbitalPeriod: 0,
		  inclination: 0,
		  argumentOfPeriapsis: 0,
		  longitudeOfAscendingNode: 0,
		  lastPerihelion: "2024-01-01",

		  // Radio físico: 1.2234 R☉ ≈ 851,119 km
		  size: 851119,
		  color: 0xffffee,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,

		  // Aproximado (hay dispersión en la literatura)
		  rotationPeriod: 22,

		  orbits: "Alpha Centauri",
		  kind: "sun",
		  radius: 41,
		  emissive: new BABYLON.Color3(1.0, 1.0, 0.92),
		},

		"Alpha Centauri B": {
		  // Separación A–B: ~11.2 AU a ~35.6 AU (en km)
		  periapsis: 1675496152,
		  apoapsis: 5325684197,

		  // ~79.9 años ≈ 29,196 días (tu 29,183 también es razonable)
		  orbitalPeriod: 29196,

		  // Elementos orbitales típicos (solución clásica tipo Pourbaix)
		  inclination: 79.20,
		  argumentOfPeriapsis: 231.65,
		  longitudeOfAscendingNode: 204.85,

		  // OJO: último periastron (no el próximo)
		  lastPerihelion: "1955-08-01",

		  // Radio físico: 0.8632 R☉ ≈ 600,528 km
		  size: 600528,
		  color: 0xffd799,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,

		  // ~36 días (no 27)
		  rotationPeriod: 36.2,

		  orbits: "Alpha Centauri",
		  kind: "sun",
		  radius: 34,
		  emissive: new BABYLON.Color3(1.0, 0.84, 0.60),
		},
    
		"Proxima Centauri": {
		  // Periastron/apastron: 4.3 kAU y 13.0 kAU (en km)
		  periapsis: 643270844010,
		  apoapsis: 1944772319100,

		  // Periodo: ~547,000 años ≈ 199,791,750 días
		  orbitalPeriod: 199791750,

		  // Orientación orbital (Kervella+ 2017)
		  inclination: 107.6,
		  argumentOfPeriapsis: 72.3,
		  longitudeOfAscendingNode: 126.0,

		  // En realidad el “epoch of periastron” está a cientos de miles de años;
		  // si tu motor necesita una fecha, mejor tratarlo como placeholder.
		  lastPerihelion: "2024-01-01",

		  // Radio físico: 0.1542 R☉ ≈ 107,277 km
		  size: 107277,
		  color: 0xff4c33,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,

		  // ~83 días (bien)
		  rotationPeriod: 83.1,

		  orbits: "Alpha Centauri",
		  kind: "sun",
		  radius: 7,
		  emissive: new BABYLON.Color3(1.0, 0.3, 0.1),
		},
    
        "Eridani A": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 864900,
          color: 0xffd700,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Eridani A",
    
          kind: "sun",
          radius: 28,
          emissive: new BABYLON.Color3(1.0, 0.92, 0.75),
        },
    
        "Alkalurops": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 720000,
          color: 0xe8f3ff,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Alkalurops",
    
          kind: "sun",
          radius: 30,
          emissive: new BABYLON.Color3(0.92, 0.95, 1.0),
        },
    
        "Delta Pavonis": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 864900,
          color: 0xffd7aa,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Delta Pavonis",
    
          kind: "sun",
          radius: 32,
          emissive: new BABYLON.Color3(1.0, 0.86, 0.65),
        },
    
        "36 Ophiuchi B": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 780000,
          color: 0xffe2b3,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "36 Ophiuchi B",
    
          kind: "sun",
          radius: 30,
          emissive: new BABYLON.Color3(1.0, 0.90, 0.70),
        },
    
        "Gamma Waiping": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 700000,
          color: 0xfff5dd,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Gamma Waiping",
    
          kind: "sun",
          radius: 29,
          emissive: new BABYLON.Color3(1.0, 0.94, 0.80),
        },
    
        "Theta Shalish": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 690000,
          color: 0xffdfb0,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Theta Shalish",
    
          kind: "sun",
          radius: 28,
          emissive: new BABYLON.Color3(1.0, 0.82, 0.60),
        },
    
        "Theta Shaowei": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 630000,
          color: 0xffcfaa,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Theta Shaowei",
    
          kind: "sun",
          radius: 25,
          emissive: new BABYLON.Color3(0.95, 0.78, 0.55),
        },
    
        "Psi Draconis": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 670000,
          color: 0xfff0dd,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Psi Draconis",
    
          kind: "sun",
          radius: 27,
          emissive: new BABYLON.Color3(0.95, 0.90, 0.82),
        },
    
        "Sigma Draconis": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 900000,
          color: 0xffaa88,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Sigma Draconis",
    
          kind: "sun",
          radius: 42,
          emissive: new BABYLON.Color3(1.0, 0.60, 0.45),
        },
    
		"Alpha Piscium A": {
		  periapsis: 6582375000, 
		  apoapsis: 19747125000,
		  orbitalPeriod: 262800, 
		  inclination: 65, 
		  argumentOfPeriapsis: 0,
		  longitudeOfAscendingNode: 0,
		  lastPerihelion: "2024-01-01",

		  size: 1391400, 
		  color: 0xe6f0ff,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,
		  rotationPeriod: 2.1,

		  orbits: "Alpha Piscium",

		  kind: "sun",
		  radius: 52,
		  emissive: new BABYLON.Color3(0.9, 0.94, 1.0),
		},

		"Alpha Piscium B": {
		  periapsis: 8377625000, 
		  apoapsis: 25132875000,
		  orbitalPeriod: 262800, 
		  inclination: 65, 
		  argumentOfPeriapsis: 180, // Lado opuesto de la elipse
		  longitudeOfAscendingNode: 0,
		  lastPerihelion: "2024-01-01",

		  size: 1043550, 
		  color: 0xfffcf5,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,
		  rotationPeriod: 3.5,

		  orbits: "Alpha Piscium",

		  kind: "sun",
		  radius: 39,
		  emissive: new BABYLON.Color3(1.0, 0.98, 0.9),
		},
    
        "Laoujin": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 650000,
          color: 0xfff0d2,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Laoujin",
    
          kind: "sun",
          radius: 26,
          emissive: new BABYLON.Color3(0.95, 0.92, 0.78),
        },
    
        "Thalim": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 620000,
          color: 0xffc4aa,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Thalim",
    
          kind: "sun",
          radius: 26,
          emissive: new BABYLON.Color3(1.0, 0.70, 0.55),
        },
    
        "Kuentsing": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 680000,
          color: 0xffedd0,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Kuentsing",
    
          kind: "sun",
          radius: 27,
          emissive: new BABYLON.Color3(0.95, 0.88, 0.70),
        },
    
        "Epsilon Alangue": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 700000,
          color: 0xe9f2ff,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Epsilon Alangue",
    
          kind: "sun",
          radius: 28,
          emissive: new BABYLON.Color3(0.90, 0.92, 1.0),
        },
    
        "Beta Lyncis": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 760000,
          color: 0xfff0d2,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Beta Lyncis",
    
          kind: "sun",
          radius: 30,
          emissive: new BABYLON.Color3(0.95, 0.90, 0.78),
        },
    
        "Alces Minor": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 760000,
          color: 0xfff0d2,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Alces Minor",
    
          kind: "sun",
          radius: 30,
          emissive: new BABYLON.Color3(0.95, 0.90, 0.78),
        },
    
        "70 Ophiuchi A": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 740000,
          color: 0xffe2b3,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "70 Ophiuchi A",
    
          kind: "sun",
          radius: 34,
          emissive: new BABYLON.Color3(1.0, 0.84, 0.60),
        },
    
        "Unsidor": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 700000,
          color: 0xfff5dd,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Unsidor",
    
          kind: "sun",
          radius: 29,
          emissive: new BABYLON.Color3(1.0, 0.94, 0.80),
        },
    
        "Thonaris": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 900000,
          color: 0xffaa88,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Thonaris",
    
          kind: "sun",
          radius: 42,
          emissive: new BABYLON.Color3(1.0, 0.60, 0.45),
        },
    
        "Yondair": {
          periapsis: 0, apoapsis: 0,
          orbitalPeriod: 0,
          inclination: 0,
          argumentOfPeriapsis: 0,
          longitudeOfAscendingNode: 0,
          lastPerihelion: "2024-01-01",
    
          size: 650000,
          color: 0xfff0d2,
          rotationAxis: { x: 0, y: 1, z: 0 },
          axialTilt: 0,
          rotationPeriod: 27,
    
          orbits: "Yondair",
    
          kind: "sun",
          radius: 26,
          emissive: new BABYLON.Color3(0.95, 0.92, 0.78),
        },
		
		// Nearest 100 stars (HYG-derived point set: star100) - coordinates in light-years

		// 1. ESTRELLA DE BARNARD (Barnard's Star)
		// Es la estrella con el mayor movimiento propio conocido.
		"Barnard": {
		  periapsis: 0, apoapsis: 0,
		  orbitalPeriod: 0, inclination: 0,
		  argumentOfPeriapsis: 0, longitudeOfAscendingNode: 0,
		  lastPerihelion: "2024-01-01",

		  size: 130146,              // ~0.187 R☉
		  color: 0xff9966,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,
		  rotationPeriod: 130.4,     // ~130–150 d en la literatura

		  orbits: "Barnard",
		  kind: "star",
		  radius: 6,
		  emissive: new BABYLON.Color3(0.8, 0.25, 0.1)
		},
		
		// 2. LALANDE 21185
		// Una de las enanas rojas más brillantes del cielo norte.
		"Lalande 21185": {
		  periapsis: 0, apoapsis: 0,
		  orbitalPeriod: 0, inclination: 0,
		  argumentOfPeriapsis: 0, longitudeOfAscendingNode: 0,
		  lastPerihelion: "2024-01-01",

		  size: 273244,              // ~0.3924 R☉
		  color: 0xffaa77,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,
		  rotationPeriod: 56.0,

		  orbits: "Lalande 21185",
		  kind: "star",
		  radius: 8,
		  emissive: new BABYLON.Color3(0.9, 0.35, 0.15)
		},
		
		// 3. SIRIUS (Sistema Binario)
		"Sirius A": {
		  periapsis: 0, apoapsis: 0,
		  orbitalPeriod: 0, inclination: 0,
		  argumentOfPeriapsis: 0, longitudeOfAscendingNode: 0,
		  lastPerihelion: "2024-01-01",

		  size: 1192830,              // ~1.713 R☉
		  color: 0xf8fbff,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,
		  rotationPeriod: 5.5,        // típicamente citado como <= 5.5 d

		  orbits: "Sirius",
		  kind: "star",
		  radius: 20,
		  emissive: new BABYLON.Color3(0.9, 0.95, 1.0)
		},
		
		"Sirius B": {
		  // Órbita relativa (valores tipo ORB6)
		  periapsis: 1208157290,          // km  (~8.076 AU)
		  apoapsis: 4705775305,           // km  (~31.456 AU)
		  orbitalPeriod: 18309.4,         // días (~50.1284 años)
		  inclination: 136.336,
		  argumentOfPeriapsis: 149.161,   // (secondary) ojo convenciones
		  longitudeOfAscendingNode: 45.400,
		  lastPerihelion: "1994-07-28",   // ~1994.5715

		  size: 5635,                     // km (radio típico ~5634 km)
		  color: 0xeaf3ff,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,
		  rotationPeriod: 0,              // desconocido / no fijar sin fuente sólida

		  orbits: "Sirius",
		  kind: "white_dwarf",
		  radius: 4,
		  emissive: new BABYLON.Color3(0.7, 0.8, 1.0)
		},
		
		// 4. GL 729 (Ross 154)
		// Una estrella fulgurante (flare star) que puede duplicar su brillo en segundos.
		"Gl 729": {
		  periapsis: 0, apoapsis: 0,
		  orbitalPeriod: 0, inclination: 0,
		  argumentOfPeriapsis: 0, longitudeOfAscendingNode: 0,
		  lastPerihelion: "2024-01-01",

		  size: 139268,              // ~0.200 R☉
		  color: 0xff9966,
		  rotationAxis: { x: 0, y: 1, z: 0 },
		  axialTilt: 0,
		  rotationPeriod: 2.848,

		  orbits: "Gl 729",
		  kind: "star",
		  radius: 6,
		  emissive: new BABYLON.Color3(1.0, 0.3, 0.1)
		},
		
      },	  
    
      // ============================================================
      // PLANETS: planetId KEY. "orbits" apunta a starId.
      // ============================================================
      planets: {
        // ----------------------------------------------------------
        // Sistema SOL
        // ----------------------------------------------------------
        "Mercurio": {
          periapsis: 46000000, apoapsis: 69800000,
          size: 2439.5, color: 0xaaaaaa,
          orbits: "Sol", orbitalPeriod: 88,
          inclination: 7.004, argumentOfPeriapsis: 29.124, longitudeOfAscendingNode: 48.331,
          lastPerihelion: "2024-01-05",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.034, rotationPeriod: 58.7,
          /*jsonFile: "mercurio.json",*/
        },
    
        "Venus": {
          periapsis: 107480000, apoapsis: 108940000,
          size: 6052, color: 0xff9900,
          orbits: "Sol", orbitalPeriod: 224.7,
          inclination: 3.39, argumentOfPeriapsis: 54.852, longitudeOfAscendingNode: 76.67,
          lastPerihelion: "2023-08-13",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 177.36, rotationPeriod: -243.02,
          jsonFile: "vulcanis.json",
        },
    
        "Tierra": {
          periapsis: 147090000, apoapsis: 152100000,
          size: 6371, color: 0x0000ff,
          orbits: "Sol", orbitalPeriod: 365.25,
          inclination: 1.578, argumentOfPeriapsis: 114.208, longitudeOfAscendingNode: 348.739,
          lastPerihelion: "2024-01-03",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 23.44, rotationPeriod: 0.99726968,
          jsonFile: "tierra.json",
        },
    
        "Marte": {
          periapsis: 206620000, apoapsis: 249230000,
          size: 3389.5, color: 0xff3300,
          orbits: "Sol", orbitalPeriod: 687,
          inclination: 1.85, argumentOfPeriapsis: 286.537, longitudeOfAscendingNode: 49.562,
          lastPerihelion: "2022-12-08",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 25.19, rotationPeriod: 1.02595675,
          /*jsonFile: "marte.json",*/
        },
    
        "Jupiter": {
          periapsis: 740520000, apoapsis: 816620000,
          size: 69910, color: 0xb5651d,
          orbits: "Sol", orbitalPeriod: 4332.59,
          inclination: 1.3, argumentOfPeriapsis: 180.75, longitudeOfAscendingNode: 0.49,
          lastPerihelion: "2023-11-03",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 3.13, rotationPeriod: 0.41,
          /*jsonFile: "jupiter.json",*/
        },
    
        "Saturno": {
          periapsis: 1352550000, apoapsis: 1514500000,
          size: 58230, color: 0xf4a460,
          orbits: "Sol", orbitalPeriod: 10759.22,
          inclination: 2.5, argumentOfPeriapsis: 180.43, longitudeOfAscendingNode: 0.66,
          lastPerihelion: "2023-08-27",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 26.73, rotationPeriod: 0.45,
          /*jsonFile: "saturno.json",*/
        },
    	
    	"Urano": { 
    		periapsis: 2741300000, apoapsis: 3006300000, 
    		size: 25362, color: 0x00ffff, 
    		orbits: "Sol", orbitalPeriod: 30685, 
    		inclination: 0.77, argumentOfPeriapsis: 170.96, longitudeOfAscendingNode: 0.01, 
    		lastPerihelion: "2030-09-23", 
    		rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 97.77, rotationPeriod: -0.72 // Rotación retrógrada
    	},
    	"Neptuno": { 
    		periapsis: 4444400000, apoapsis: 4545700000, 
    		size: 24622, color: 0x0000ff, 
    		orbits: "Sol", orbitalPeriod: 60190, 
    		inclination: 1.77, argumentOfPeriapsis: 184.97, longitudeOfAscendingNode: 0.79, 
    		lastPerihelion: "2040-12-01", 
    		rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 28.32, rotationPeriod: 0.67
    	},
    	"Ceres": {
    		periapsis: 413700000, apoapsis: 445600000, 
    		size: 473, color: 0xb0c4de, 
    		orbits: "Sol", orbitalPeriod: 1680,
    		inclination: 10.59, argumentOfPeriapsis: 73.41, longitudeOfAscendingNode: 80.33, 
    		lastPerihelion: "2022-01-01",
    		rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 4, rotationPeriod: 0.38
    	},
    	"Pluton": {
    		periapsis: 4437000000, apoapsis: 7376000000, 
    		size: 1188.3, color: 0xa9a9a9, 
    		orbits: "Sol", orbitalPeriod: 90560,
    		inclination: 17.16, argumentOfPeriapsis: 113.76, longitudeOfAscendingNode: 110.3, 
    		lastPerihelion: "1989-09-05",
    		rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 122.5, rotationPeriod: 6.39
    	},
    	"Haumea": {
    		periapsis: 5155000000, apoapsis: 7748000000, 
    		size: 780, color: 0xffffff, 
    		orbits: "Sol", orbitalPeriod: 103250,
    		inclination: 28.22, argumentOfPeriapsis: 240.2, longitudeOfAscendingNode: 122.1, 
    		lastPerihelion: "1992-01-01",
    		rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0, rotationPeriod: 0.16
    	},
    	"Makemake": {
    		periapsis: 5103000000, apoapsis: 7935000000, 
    		size: 715, color: 0xffd700, 
    		orbits: "Sol", orbitalPeriod: 112897,
    		inclination: 28.98, argumentOfPeriapsis: 296.1, longitudeOfAscendingNode: 79.62, 
    		lastPerihelion: "2023-01-01",
    		rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0, rotationPeriod: 0.32
    	},
    	"Eris": {
    		periapsis: 5766000000, apoapsis: 14544000000, 
    		size: 1163, color: 0xffffff, 
    		orbits: "Sol", orbitalPeriod: 204670,
    		inclination: 44.04, argumentOfPeriapsis: 151.8, longitudeOfAscendingNode: 35.95, 
    		lastPerihelion: "1699-08-01",
    		rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 78, rotationPeriod: 1.08
    	},
    
        // ----------------------------------------------------------
        // Sistema CANOPUS (Dune)
        // ----------------------------------------------------------
        "Seban": {
          periapsis: 36000000, apoapsis: 40000000,
          size: 2440, color: 0xaaaaaa,
          orbits: "Canopus", orbitalPeriod: 88,
          inclination: 7.0, argumentOfPeriapsis: 29.124, longitudeOfAscendingNode: 48.331,
          lastPerihelion: "2024-02-15",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.034, rotationPeriod: 58.646,
          jsonFile: "seban.json",
        },
    
        "Menaris": {
          periapsis: 58000000, apoapsis: 62000000,
          size: 5992, color: 0xff9900,
          orbits: "Canopus", orbitalPeriod: 225.0,
          inclination: 3.39, argumentOfPeriapsis: 54.852, longitudeOfAscendingNode: 76.67,
          lastPerihelion: "2023-08-13",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 177.36, rotationPeriod: -243.02,
          jsonFile: "menaris.json",
        },
    
        "Arrakis": {
          periapsis: 82600000, apoapsis: 91400000,
          size: 6128, color: 0xffeaaf,
          orbits: "Canopus", orbitalPeriod: 353.041,
          inclination: 1.25, argumentOfPeriapsis: 114.208, longitudeOfAscendingNode: 348.739,
          lastPerihelion: "2024-01-03",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.5, rotationPeriod: 1.0,
          jsonFile: "arrakis.json",
        },
    
        "Extaris": {
          periapsis: 135000000, apoapsis: 145000000,
          size: 5341, color: 0xff3300,
          orbits: "Canopus", orbitalPeriod: 687,
          inclination: 1.85, argumentOfPeriapsis: 286.537, longitudeOfAscendingNode: 49.562,
          lastPerihelion: "2023-11-20",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 25.19, rotationPeriod: 1.02595675,
          jsonFile: "extaris.json",
        },
    
        "Ven": {
          periapsis: 230000000, apoapsis: 250000000,
          size: 61284, color: 0xb5651d,
          orbits: "Canopus", orbitalPeriod: 1850.0,
          inclination: 0.8, argumentOfPeriapsis: 150.0, longitudeOfAscendingNode: 22.0,
          lastPerihelion: "2024-05-10",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 3.13, rotationPeriod: 0.41,
          /*jsonFile: "ven.json",*/
        },
    
        "Revona": {
          periapsis: 440000000, apoapsis: 470000000,
          size: 51520, color: 0xf4a460,
          orbits: "Canopus", orbitalPeriod: 4332.0,
          inclination: 2.49, argumentOfPeriapsis: 94.3, longitudeOfAscendingNode: 131.7,
          lastPerihelion: "2024-08-20",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 26.73, rotationPeriod: 0.45,
          jsonFile: "revona.json",
        },
    
        // ----------------------------------------------------------
        // Catálogo Dune (planetas sueltos, cada uno con su estrella)
        // ----------------------------------------------------------
        "Caladan": {
          periapsis: 160000000, apoapsis: 170000000,
          size: 4460, color: 0x2f6fb3,
          orbits: "Delta Pavonis", orbitalPeriod: 410,
          inclination: 1.9, argumentOfPeriapsis: 114.0, longitudeOfAscendingNode: 48.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 18.0, rotationPeriod: 0.92,
          jsonFile: "caladan.json",
        },
    
        "Giedi Prime": {
          periapsis: 120000000, apoapsis: 140000000,
          size: 4200, color: 0x4a4a4a,
          orbits: "36 Ophiuchi B", orbitalPeriod: 290,
          inclination: 3.2, argumentOfPeriapsis: 62.0, longitudeOfAscendingNode: 210.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 6.0, rotationPeriod: 0.78,
          jsonFile: "giedi-prime.json",
        },
    
        "Ix": {
          periapsis: 105000000, apoapsis: 112000000,
          size: 3750, color: 0x8fd3ff,
          orbits: "Alkalurops", orbitalPeriod: 235,
          inclination: 2.4, argumentOfPeriapsis: 18.0, longitudeOfAscendingNode: 320.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 11.0, rotationPeriod: 1.06,
          jsonFile: "ix.json",
        },
    
        "Richese": {
          periapsis: 135000000, apoapsis: 155000000,
          size: 4080, color: 0x2aa6c8,
          orbits: "Eridani A", orbitalPeriod: 335,
          inclination: 1.1, argumentOfPeriapsis: 140.0, longitudeOfAscendingNode: 75.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 23.0, rotationPeriod: 1.12,
          jsonFile: "richese.json",
        },
    
        "Kaitain": {
          periapsis: 145000000, apoapsis: 155000000,
          size: 4020, color: 0x5bc06a,
          orbits: "Alpha Piscium A", orbitalPeriod: 365,
          inclination: 0.8, argumentOfPeriapsis: 102.0, longitudeOfAscendingNode: 12.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 21.0, rotationPeriod: 0.98,
          jsonFile: "kaitain.json",
        },
    
        "Salusa Secundus": {
          periapsis: 210000000, apoapsis: 255000000,
          size: 3820, color: 0x8a6b4b,
          orbits: "Gamma Waiping", orbitalPeriod: 620,
          inclination: 4.7, argumentOfPeriapsis: 250.0, longitudeOfAscendingNode: 33.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 33.0, rotationPeriod: 1.45,
        },
    
        "Wallach IX": {
          periapsis: 98000000, apoapsis: 108000000,
          size: 3180, color: 0x6cbf7a,
          orbits: "Laoujin", orbitalPeriod: 210,
          inclination: 1.6, argumentOfPeriapsis: 80.0, longitudeOfAscendingNode: 190.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 14.0, rotationPeriod: 0.74,
        },
    
        "Tleilax": {
          periapsis: 88000000, apoapsis: 103000000,
          size: 3120, color: 0x7ea0b5,
          orbits: "Thalim", orbitalPeriod: 185,
          inclination: 2.8, argumentOfPeriapsis: 310.0, longitudeOfAscendingNode: 260.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 5.0, rotationPeriod: 1.90,
        },
    
        "Rossak": {
          periapsis: 72000000, apoapsis: 86000000,
          size: 3060, color: 0x1b8f3f,
          orbits: "Alces Minor", orbitalPeriod: 145,
          inclination: 6.1, argumentOfPeriapsis: 170.0, longitudeOfAscendingNode: 45.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 29.0, rotationPeriod: 0.68,
          jsonFile: "rossak.json",
        },
    
        "Buzzell": {
          periapsis: 175000000, apoapsis: 205000000,
          size: 2930, color: 0x2a6fd6,
          orbits: "Alpha Piscium B", orbitalPeriod: 510,
          inclination: 3.9, argumentOfPeriapsis: 12.0, longitudeOfAscendingNode: 155.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 40.0, rotationPeriod: 0.83,
        },
    
        "Lampadas": {
          periapsis: 112000000, apoapsis: 138000000,
          size: 2990, color: 0x555555,
          orbits: "Laoujin", orbitalPeriod: 275,
          inclination: 2.2, argumentOfPeriapsis: 205.0, longitudeOfAscendingNode: 88.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 9.0, rotationPeriod: 1.02,
        },
    
        "Ginaz": {
          periapsis: 130000000, apoapsis: 150000000,
          size: 3600, color: 0x3aa5ff,
          orbits: "Alpha Piscium B", orbitalPeriod: 320,
          inclination: 1.3, argumentOfPeriapsis: 44.0, longitudeOfAscendingNode: 22.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 27.0, rotationPeriod: 0.88,
        },
    
        "Ecaz": {
			// Es el cuarto, así que lo alejamos más en el esquema
			periapsis: 650000000, 
			apoapsis: 720000000,
			size: 6100,                  // Tamaño similar a Venus/Tierra
			color: 0x2e8b57,             // Verde bosque (por su densa vegetación y maderas)
			orbits: "Alpha Centauri B",  // Orbita específicamente a la estrella B
			orbitalPeriod: 2200, 
			inclination: 1.8, 
			argumentOfPeriapsis: 240.0, 
			longitudeOfAscendingNode: 15.0,
			lastPerihelion: "2024-08-15",
			
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 18.0, 
			rotationPeriod: 0.98,        // Día casi terrestre
			
			kind: "planet",
			radius: 2.7,                 // Tamaño visual medio
			emissive: new BABYLON.Color3(0, 0.02, 0) // Un sutil brillo verde
        },
    
        "Chusuk": {
          periapsis: 140000000, apoapsis: 165000000,
          size: 3950, color: 0x2fb35a,
          orbits: "Theta Shalish", orbitalPeriod: 360,
          inclination: 1.7, argumentOfPeriapsis: 90.0, longitudeOfAscendingNode: 60.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 24.0, rotationPeriod: 1.05,
        },
    
        "Hagal": {
          periapsis: 60000000, apoapsis: 68000000,
          size: 2800, color: 0xb3f0ff,
          orbits: "Theta Shaowei", orbitalPeriod: 120,
          inclination: 5.6, argumentOfPeriapsis: 275.0, longitudeOfAscendingNode: 140.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 2.0, rotationPeriod: 0.51,
        },
    
        "Gamont": {
          periapsis: 155000000, apoapsis: 190000000,
          size: 4100, color: 0x2f8f7f,
          orbits: "Psi Draconis", orbitalPeriod: 460,
          inclination: 2.9, argumentOfPeriapsis: 10.0, longitudeOfAscendingNode: 200.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 32.0, rotationPeriod: 0.97,
        },
    
        "Grumman": {
          periapsis: 220000000, apoapsis: 290000000,
          size: 3750, color: 0x8c8c8c,
          orbits: "Psi Draconis", orbitalPeriod: 780,
          inclination: 4.1, argumentOfPeriapsis: 188.0, longitudeOfAscendingNode: 15.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 12.0, rotationPeriod: 1.62,
        },
    
        "Poritrin": {
          periapsis: 105000000, apoapsis: 128000000,
          size: 4010, color: 0x3ac46a,
          orbits: "Epsilon Alangue", orbitalPeriod: 240,
          inclination: 1.2, argumentOfPeriapsis: 56.0, longitudeOfAscendingNode: 270.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 28.0, rotationPeriod: 0.91,
        },
    
        "Bela Tegeuse": {
          periapsis: 180000000, apoapsis: 240000000,
          size: 4200, color: 0x7fb4ff,
          orbits: "Kuentsing", orbitalPeriod: 640,
          inclination: 3.0, argumentOfPeriapsis: 330.0, longitudeOfAscendingNode: 100.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 17.0, rotationPeriod: 1.10,
        },
    
        "Lankiveil": {
          periapsis: 520000000, apoapsis: 720000000,
          size: 3900, color: 0x9bd7ff,
          orbits: "Delta Pavonis", orbitalPeriod: 3200,
          inclination: 7.8, argumentOfPeriapsis: 15.0, longitudeOfAscendingNode: 250.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 9.0, rotationPeriod: 1.28,
        },
    
        "Corrin": {
          periapsis: 240000000, apoapsis: 310000000,
          size: 3950, color: 0xff6b3a,
          orbits: "Sigma Draconis", orbitalPeriod: 860,
          inclination: 5.1, argumentOfPeriapsis: 120.0, longitudeOfAscendingNode: 5.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 16.0, rotationPeriod: 1.34,
        },
    
        "Tanegaard": {
          periapsis: 150000000, apoapsis: 165000000,
          size: 4050, color: 0x88a0a8,
          orbits: "Alpha Piscium B", orbitalPeriod: 370,
          inclination: 0.6, argumentOfPeriapsis: 240.0, longitudeOfAscendingNode: 40.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 3.0, rotationPeriod: 0.99,
        },
    
        "Conexión": {
          periapsis: 170000000, apoapsis: 210000000,
          size: 3600, color: 0x6b7a7f,
          orbits: "Psi Draconis", orbitalPeriod: 520,
          inclination: 2.0, argumentOfPeriapsis: 96.0, longitudeOfAscendingNode: 180.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 7.0, rotationPeriod: 0.93,
        },
    
        "Kolhar": {
          periapsis: 260000000, apoapsis: 340000000,
          size: 3700, color: 0xb9d8ff,
          orbits: "Psi Draconis", orbitalPeriod: 980,
          inclination: 6.4, argumentOfPeriapsis: 200.0, longitudeOfAscendingNode: 290.0,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 22.0, rotationPeriod: 1.08,
        },

		// --- PLANETAS DE PROXIMA CENTAURI ---
		"Proxima b": {
			periapsis: 170000000, apoapsis: 210000000,
			size: 6371, color: 0x6b7a7f,
			orbits: "Proxima Centauri", orbitalPeriod: 520,
			inclination: 2.0, argumentOfPeriapsis: 96.0, longitudeOfAscendingNode: 180.0,
			lastPerihelion: "2024-01-01",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 7.0, rotationPeriod: 0.93,
			kind: "planet", radius: 2.5
		},
		
		"Proxima d": {
			periapsis: 280000000, apoapsis: 320000000,
			size: 3200, color: 0x8b9a9f,
			orbits: "Proxima Centauri", orbitalPeriod: 850,
			inclination: 1.5, argumentOfPeriapsis: 45.0, longitudeOfAscendingNode: 210.0,
			lastPerihelion: "2024-03-12",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 2.0, rotationPeriod: 1.1,
			kind: "planet", radius: 1.8
		},
		
		// --- PLANETA DE ALPHA CENTAURI A (Candidato) ---
		"Alp2Cen A-b": {
			periapsis: 450000000, apoapsis: 510000000,
			size: 12000, color: 0x5a6a6f,
			orbits: "Alpha Centauri A", orbitalPeriod: 1400,
			inclination: 0.5, argumentOfPeriapsis: 180.0, longitudeOfAscendingNode: 15.0,
			lastPerihelion: "2023-11-20",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 10.0, rotationPeriod: 0.85,
			kind: "planet", radius: 4.2
		},
		
		// --- PLANETAS INTERIORES DE ALPHA CENTAURI B (Para completar el sistema de Ecaz) ---

		// Alp2Cen B-b: El primer planeta, un mundo de roca fundida.
		"Alp2Cen B-b": {
			periapsis: 170000000, 
			apoapsis: 210000000,
			size: 3100, 
			color: 0x5c4033, // Marrón oscuro/quemado
			orbits: "Alpha Centauri B", 
			orbitalPeriod: 520,
			inclination: 2.5, 
			argumentOfPeriapsis: 96.0, 
			longitudeOfAscendingNode: 180.0,
			lastPerihelion: "2024-01-01",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 2.0, 
			rotationPeriod: 0.8,
			kind: "planet",
			radius: 2.1
		},

		// Alp2Cen B-c: El segundo planeta, un desierto de polvo sulfuroso.
		"Alp2Cen B-c": {
			periapsis: 320000000, 
			apoapsis: 370000000,
			size: 4800, 
			color: 0x9c8e5e, // Ocre/Arena
			orbits: "Alpha Centauri B", 
			orbitalPeriod: 980,
			inclination: 1.2, 
			argumentOfPeriapsis: 45.0, 
			longitudeOfAscendingNode: 210.0,
			lastPerihelion: "2024-04-10",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 15.0, 
			rotationPeriod: 1.1,
			kind: "planet",
			radius: 2.6
		},

		// Alp2Cen B-d: El tercer planeta, un mundo volcánico activo.
		"Alp2Cen B-d": {
			periapsis: 480000000, 
			apoapsis: 540000000,
			size: 5900, 
			color: 0x7b3f00, // Color tierra rojiza
			orbits: "Alpha Centauri B", 
			orbitalPeriod: 1550,
			inclination: 0.8, 
			argumentOfPeriapsis: 180.0, 
			longitudeOfAscendingNode: 30.0,
			lastPerihelion: "2023-11-20",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 23.0, 
			rotationPeriod: 1.3,
			kind: "planet",
			radius: 2.8
		},
		
		// --- SISTEMA ESTRELLA DE BARNARD ---
		
		"Barnard b": {
			periapsis: 170000000, 
			apoapsis: 210000000,
			size: 3600, 
			color: 0x6b7a7f,
			orbits: "Barnard", 
			orbitalPeriod: 520,
			inclination: 2.0, 
			argumentOfPeriapsis: 96.0, 
			longitudeOfAscendingNode: 180.0,
			lastPerihelion: "2024-01-01",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 7.0, 
			rotationPeriod: 0.93,
			kind: "planet",
			radius: 2.5
		},
		
		"Barnard c": {
			periapsis: 290000000, 
			apoapsis: 330000000,
			size: 4100, 
			color: 0x7a868a,
			orbits: "Barnard", 
			orbitalPeriod: 850,
			inclination: 1.5, 
			argumentOfPeriapsis: 45.0, 
			longitudeOfAscendingNode: 210.0,
			lastPerihelion: "2024-03-12",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 12.0, 
			rotationPeriod: 1.10,
			kind: "planet",
			radius: 2.8
		},
		
		"Barnard d": {
			periapsis: 450000000, 
			apoapsis: 510000000,
			size: 3800, 
			color: 0x5a6469,
			orbits: "Barnard", 
			orbitalPeriod: 1400,
			inclination: 0.5, 
			argumentOfPeriapsis: 180.0, 
			longitudeOfAscendingNode: 15.0,
			lastPerihelion: "2023-11-20",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 3.0, 
			rotationPeriod: 0.85,
			kind: "planet",
			radius: 2.3
		},
		
		"Barnard e": {
			periapsis: 620000000, 
			apoapsis: 690000000,
			size: 5200, 
			color: 0x4d5659,
			orbits: "Barnard", 
			orbitalPeriod: 2100,
			inclination: 1.2, 
			argumentOfPeriapsis: 270.0, 
			longitudeOfAscendingNode: 120.0,
			lastPerihelion: "2024-06-01",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 25.0, 
			rotationPeriod: 1.50,
			kind: "planet",
			radius: 3.5
		},
		
		// --- SISTEMA LALANDE 21185 ---
  
		// Lalande 21185 b: Una Super-Tierra cercana a la estrella.
		"Lalande 21185 b": {
			periapsis: 170000000, 
			apoapsis: 210000000,
			size: 4200, // Un poco más grande que tu ejemplo anterior
			color: 0x7a8b99,
			orbits: "Lalande 21185", 
			orbitalPeriod: 520,
			inclination: 2.0, 
			argumentOfPeriapsis: 96.0, 
			longitudeOfAscendingNode: 180.0,
			lastPerihelion: "2024-01-01",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 7.0, 
			rotationPeriod: 0.93,
			kind: "planet",
			radius: 2.8
		},
		
		// Lalande 21185 d: El planeta intermedio (candidato muy probable).
		"Lalande 21185 d": {
			periapsis: 310000000, 
			apoapsis: 360000000,
			size: 4800, 
			color: 0x8e9ba2,
			orbits: "Lalande 21185", 
			orbitalPeriod: 890,
			inclination: 1.8, 
			argumentOfPeriapsis: 45.0, 
			longitudeOfAscendingNode: 220.0,
			lastPerihelion: "2024-03-15",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 12.0, 
			rotationPeriod: 1.15,
			kind: "planet",
			radius: 3.2
		},
		
		// Lalande 21185 c: Un gigante gaseoso (similar a Neptuno/Urano).
		"Lalande 21185 c": {
			periapsis: 520000000, 
			apoapsis: 590000000,
			size: 22000, // Mucho más grande, es un gigante gaseoso
			color: 0x5c6b70,
			orbits: "Lalande 21185", 
			orbitalPeriod: 1800,
			inclination: 0.8, 
			argumentOfPeriapsis: 180.0, 
			longitudeOfAscendingNode: 15.0,
			lastPerihelion: "2023-11-20",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 3.0, 
			rotationPeriod: 0.65, // Rotación más rápida como los gigantes gaseosos
			kind: "planet",
			radius: 5.5
		},
		
		// --- PLANETAS DE SIRIUS A ---
		
		// Sirius A-b: Un gigante gaseoso masivo (Super-Júpiter)
		"Sirius A-b": {
			periapsis: 170000000, 
			apoapsis: 210000000,
			size: 71000, // Tamaño similar a Júpiter
			color: 0xdae4e8, // Blanco azulado brillante por el reflejo de la estrella
			orbits: "Sirius", 
			orbitalPeriod: 520,
			inclination: 2.0, 
			argumentOfPeriapsis: 96.0, 
			longitudeOfAscendingNode: 180.0,
			lastPerihelion: "2024-01-01",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 3.0, 
			rotationPeriod: 0.41, // Rotación muy rápida
			kind: "planet",
			radius: 9.0
		},
		
		// Sirius A-c: Un gigante helado en el borde del sistema
		"Sirius A-c": {
			periapsis: 350000000, 
			apoapsis: 410000000,
			size: 25000, 
			color: 0x8fa9b3,
			orbits: "Sirius", 
			orbitalPeriod: 1200,
			inclination: 4.5, 
			argumentOfPeriapsis: 210.0, 
			longitudeOfAscendingNode: 45.0,
			lastPerihelion: "2024-06-15",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 28.0, 
			rotationPeriod: 0.72,
			kind: "planet",
			radius: 6.0
		},
		
		// --- PLANETAS DE SIRIUS B ---
		
		// Sirius B-b: Un "Mundo Cadáver" (Planeta superviviente a una Nova)
		"Sirius B-b": {
			periapsis: 120000000, 
			apoapsis: 150000000,
			size: 5800, 
			color: 0x4a4a4a, // Ceniza oscura
			orbits: "Sirius B", 
			orbitalPeriod: 310,
			inclination: 12.0, 
			argumentOfPeriapsis: 0.0, 
			longitudeOfAscendingNode: 0.0,
			lastPerihelion: "2024-02-01",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 45.0, 
			rotationPeriod: 2.1,
			kind: "planet",
			radius: 3.0
		},
		
		// --- SISTEMA GL 729 (ROSS 154) ---
		
		// Gl 729 b: Un mundo abrasado por las fulguraciones
		"Gl 729 b": {
			periapsis: 170000000, 
			apoapsis: 210000000,
			size: 3400, 
			color: 0x8b4513, // Tono bronce/marrón por la radiación
			orbits: "Gl 729", 
			orbitalPeriod: 520,
			inclination: 2.0, 
			argumentOfPeriapsis: 96.0, 
			longitudeOfAscendingNode: 180.0,
			lastPerihelion: "2024-01-01",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 3.0, 
			rotationPeriod: 0.93,
			kind: "planet",
			radius: 2.4
		},
		
		// Gl 729 c: Un mundo desértico con atmósfera tenue
		"Gl 729 c": {
			periapsis: 320000000, 
			apoapsis: 370000000,
			size: 4000, 
			color: 0x696969, // Gris oscuro/ceniza
			orbits: "Gl 729", 
			orbitalPeriod: 910,
			inclination: 1.5, 
			argumentOfPeriapsis: 210.0, 
			longitudeOfAscendingNode: 60.0,
			lastPerihelion: "2024-04-15",
			rotationAxis: { x: 0, y: 1, z: 0 }, 
			axialTilt: 15.0, 
			rotationPeriod: 1.25,
			kind: "planet",
			radius: 2.8
		},
		
      },
    
      // ============================================================
      // SATELLITES: lunas (y lunas de lunas si quieres)
      // satelliteId KEY. "orbits" apunta a planetId (o moonId)
      // ============================================================
      satellites: {
        // --- Sol ---
        "Luna": {
          periapsis: 363300, apoapsis: 405500,
          size: 1737.1, color: 0xcccccc,
          orbits: "Tierra", orbitalPeriod: 27.321,
          inclination: 5.14, argumentOfPeriapsis: 41.5, longitudeOfAscendingNode: 125.08,
          lastPerihelion: "2024-12-03",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 1.54, rotationPeriod: 27.321,
          jsonFile: "luna.json",
        },
    
        "Io": {
          periapsis: 421700, apoapsis: 422000,
          size: 1821.5, color: 0xffa500,
          orbits: "Jupiter", orbitalPeriod: 1.769,
          inclination: 0.05, argumentOfPeriapsis: 84.03, longitudeOfAscendingNode: 43.97,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.04, rotationPeriod: 1.769,
        },
    
        "Europa": {
          periapsis: 670900, apoapsis: 676900,
          size: 1561, color: 0xffffff,
          orbits: "Jupiter", orbitalPeriod: 3.551,
          inclination: 0.47, argumentOfPeriapsis: 88.97, longitudeOfAscendingNode: 219.11,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.10, rotationPeriod: 3.551,
        },
    
        "Ganymede": {
          periapsis: 1070400, apoapsis: 1071600,
          size: 2634, color: 0xffff00,
          orbits: "Jupiter", orbitalPeriod: 7.155,
          inclination: 0.2, argumentOfPeriapsis: 192.42, longitudeOfAscendingNode: 63.55,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.03, rotationPeriod: 7.155,
        },
    
        "Callisto": {
          periapsis: 1882700, apoapsis: 1883300,
          size: 2410.5, color: 0x808080,
          orbits: "Jupiter", orbitalPeriod: 16.689,
          inclination: 0.19, argumentOfPeriapsis: 52.64, longitudeOfAscendingNode: 298.84,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.4, rotationPeriod: 16.689,
        },
    
        "Titan": {
          periapsis: 1186600, apoapsis: 1221860,
          size: 2575, color: 0xffcc99,
          orbits: "Saturno", orbitalPeriod: 15.945,
          inclination: 0.3, argumentOfPeriapsis: 174.17, longitudeOfAscendingNode: 109.49,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.3, rotationPeriod: 15.945,
        },
    
        "Enceladus": {
          periapsis: 237950, apoapsis: 238040,
          size: 252.1, color: 0xb0e0e6,
          orbits: "Saturno", orbitalPeriod: 1.37,
          inclination: 0.019, argumentOfPeriapsis: 161.23, longitudeOfAscendingNode: 40.66,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.02, rotationPeriod: 1.37,
        },
							
		"Miranda": { 
		  periapsis: 129390, apoapsis: 129850, 
		  size: 235.8, color: 0xadd8e6, 
		  orbits: "Urano", orbitalPeriod: 1.41, 
		  inclination: 4.338, argumentOfPeriapsis: 145.2, longitudeOfAscendingNode: 80.3, 
		  lastPerihelion: "2024-01-01",
		  rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 4.22, rotationPeriod: 1.41
		},
    
        // --- Dune: Arrakis ---
    	"Arvon": {
    	  periapsis: 103093, apoapsis: 130040,
          size: 201, color: 0x808080,
          orbits: "Arrakis", orbitalPeriod: 5.7,
          inclination: 0.19, argumentOfPeriapsis: 52.64, longitudeOfAscendingNode: 298.84,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.4, rotationPeriod: 16.689,
          jsonFile: "arvon.json",
        },
    	
        "Krelln": {
    	  periapsis: 324077, apoapsis: 340040,
          size: 488, color: 0xffff00,
          orbits: "Arrakis", orbitalPeriod: 25.5,
          inclination: 0.2, argumentOfPeriapsis: 192.42, longitudeOfAscendingNode: 63.55,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.03, rotationPeriod: 7.155,
          jsonFile: "krelln.json",
        },
    
        // --- Dune: Extaris moons ---
        "Dreko": {
    	  periapsis: 237950, apoapsis: 238040,
          size: 252.1, color: 0xb0e0e6,
          orbits: "Extaris", orbitalPeriod: 1.37,
          inclination: 0.019, argumentOfPeriapsis: 161.23, longitudeOfAscendingNode: 40.66,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.02, rotationPeriod: 1.37,
        },
    
        "Namar": {
    	  periapsis: 237950, apoapsis: 238040,
          size: 235.8, color: 0xadd8e6,
          orbits: "Extaris", orbitalPeriod: 1.41,
          inclination: 4.338, argumentOfPeriapsis: 145.2, longitudeOfAscendingNode: 80.3,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 4.22, rotationPeriod: 1.41,
        },
    
        "Sesh": {
    	  periapsis: 237950, apoapsis: 238040,
          size: 235.8, color: 0xadd8e6,
          orbits: "Extaris", orbitalPeriod: 1.41,
          inclination: 4.338, argumentOfPeriapsis: 145.2, longitudeOfAscendingNode: 80.3,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 4.22, rotationPeriod: 1.41,
        },
    
        "Vala": {
    	  periapsis: 237950, apoapsis: 238040,
          size: 235.8, color: 0xadd8e6,
          orbits: "Extaris", orbitalPeriod: 1.41,
          inclination: 4.338, argumentOfPeriapsis: 145.2, longitudeOfAscendingNode: 80.3,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 4.22, rotationPeriod: 1.41,
        },
    	
    	"Aja": {
    	  periapsis: 398003, apoapsis: 399000,
          size: 257, color: 0xffcc99,
          orbits: "Extaris", orbitalPeriod: 15.945,
          inclination: 0.3, argumentOfPeriapsis: 174.17, longitudeOfAscendingNode: 109.49,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 0.3, rotationPeriod: 15.945,
        },
    
        // --- Dune: Revona moon ---
        "Laran": {
    	  periapsis: 237950, apoapsis: 238040,
          size: 235.8, color: 0xadd8e6,
          orbits: "Revona", orbitalPeriod: 1.41,
          inclination: 4.338, argumentOfPeriapsis: 145.2, longitudeOfAscendingNode: 80.3,
          lastPerihelion: "2024-01-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 4.22, rotationPeriod: 1.41,
        },
      },
    
      // ============================================================
      // ARTIFICIAL SATELLITES
      // ============================================================
      artificialSatellites: {
        "ISS": {
          periapsis: 6779, apoapsis: 6781,
          size: 5.45, color: "green",
          orbits: "Tierra", orbitalPeriod: 1.5,
          inclination: 51.64, argumentOfPeriapsis: 0, longitudeOfAscendingNode: 258.76,
          lastPerihelion: "2023-12-01",
          rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 23.0, rotationPeriod: 365.37,
        },
      },
    
      // ============================================================
      // COMETS
      // ============================================================
      comets: {
        "Halley": {
          periapsis: 87870000, apoapsis: 5247100000,
          size: 11, color: 0xffffff,
          orbits: "Sol", orbitalPeriod: 27740,
          inclination: 162.26, argumentOfPeriapsis: 111.33, longitudeOfAscendingNode: 58.42,
          lastPerihelion: "1986-02-09",
          orientation: 58.42,
        },
    
        "Encke": {
          periapsis: 50917500, apoapsis: 611150000,
          size: 4.8, color: 0x87ceeb,
          orbits: "Sol", orbitalPeriod: 1205.325,
          inclination: 11.78, argumentOfPeriapsis: 186.45, longitudeOfAscendingNode: 334.57,
          lastPerihelion: "2023-11-22",
          orientation: 334.57,
        },
    
        "Hale-Bopp": {
          periapsis: 136680000, apoapsis: 55350000000,
          size: 60, color: 0xadd8e6,
          orbits: "Sol", orbitalPeriod: 919200,
          inclination: 89.4, argumentOfPeriapsis: 130.59, longitudeOfAscendingNode: 282.47,
          lastPerihelion: "1997-04-01",
          orientation: 282.47,
        },
      },
	  
	  // ============================================================
      // ASTEROIDS
      // ============================================================
	  
	  asteroids: {
		"Vesta": {
			periapsis: 321635422, apoapsis: 384466528,
			size: 263, color: 0xb0b0b0,
			orbits: "Sol", orbitalPeriod: 1326,
			inclination: 7.1422, argumentOfPeriapsis: 151.66, longitudeOfAscendingNode: 103.71,
			lastPerihelion: "2025-08-14",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 29, rotationPeriod: 0.2226
		},

		"Pallas": {
			periapsis: 318643465, apoapsis: 510128739,
			size: 256, color: 0xa9a9a9,
			orbits: "Sol", orbitalPeriod: 1687,
			inclination: 34.84, argumentOfPeriapsis: 310.93, longitudeOfAscendingNode: 172.89,
			lastPerihelion: "2023-03-07",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: 84, rotationPeriod: 0.3256
		},

		"Hygiea": {
			periapsis: 418724440, apoapsis: 521797373,
			size: 217, color: 0x6b6b6b,
			orbits: "Sol", orbitalPeriod: 2034,
			inclination: 3.832, argumentOfPeriapsis: 312.71, longitudeOfAscendingNode: 283.13,
			lastPerihelion: "2022-07-12",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: null, rotationPeriod: 0.5761
		},

		"Interamnia": {
			periapsis: 386261702, apoapsis: 528230081,
			size: 160, color: 0x8b8b8b,
			orbits: "Sol", orbitalPeriod: 1951,
			inclination: 17.32, argumentOfPeriapsis: 94.11, longitudeOfAscendingNode: 280.17,
			lastPerihelion: "2023-02-26",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: null, rotationPeriod: 0.3629
		},

		"Davida": {
			periapsis: 383568940, apoapsis: 563086385,
			size: 149, color: 0x7a7a7a,
			orbits: "Sol", orbitalPeriod: 2055,
			inclination: 15.95, argumentOfPeriapsis: 336.67, longitudeOfAscendingNode: 107.56,
			lastPerihelion: "2025-05-03",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: null, rotationPeriod: 0.2137
		},

		"Europa": {
			periapsis: 410795753, apoapsis: 514467077,
			size: 158, color: 0x9a9a9a,
			orbits: "Sol", orbitalPeriod: 1995,
			inclination: 7.48, argumentOfPeriapsis: 342.96, longitudeOfAscendingNode: 128.58,
			lastPerihelion: "2021-03-02",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: null, rotationPeriod: 0.2346
		},

		"Sylvia": {
			periapsis: 471233293, apoapsis: 569967887,
			size: 137, color: 0x5e5e5e,
			orbits: "Sol", orbitalPeriod: 2372,
			inclination: 10.9, argumentOfPeriapsis: 263, longitudeOfAscendingNode: 73,
			lastPerihelion: "2024-03-04",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: null, rotationPeriod: 0.2160
		},

		"Eunomia": {
			periapsis: 321037031, apoapsis: 469438118,
			size: 134, color: 0xb8a47a,
			orbits: "Sol", orbitalPeriod: 1571,
			inclination: 11.75, argumentOfPeriapsis: 99, longitudeOfAscendingNode: 293,
			lastPerihelion: "2024-07-13",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: null, rotationPeriod: 0.2535
		},

		"Euphrosyne": {
			periapsis: 367786365, apoapsis: 576295877,
			size: 134, color: 0x4f4f4f,
			orbits: "Sol", orbitalPeriod: 2042,
			inclination: 26.3033, argumentOfPeriapsis: 61.4704, longitudeOfAscendingNode: 31.1186,
			lastPerihelion: "2023-07-31",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: null, rotationPeriod: 0.2304
		},

		"Cybele": {
			periapsis: 455734953, apoapsis: 569997807,
			size: 132, color: 0x3f3f3f,
			orbits: "Sol", orbitalPeriod: 2319,
			inclination: 3.5627, argumentOfPeriapsis: 102.37, longitudeOfAscendingNode: 155.63,
			lastPerihelion: "2024-12-24",
			rotationAxis: { x: 0, y: 1, z: 0 }, axialTilt: null, rotationPeriod: 0.2534
		},

      },
    };
