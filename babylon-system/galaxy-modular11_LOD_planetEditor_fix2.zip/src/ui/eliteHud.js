// Elite-style HUD overlay (lightweight DOM, no Babylon GUI)
// - Toggle show/hide with key 'C'
// - Buttons: camera modes (M/K), speed 0..9 (ship), fullscreen
// - Toggles: names/labels, navigation grid
// - Coordinates: ABS/CAM/OFF + floating origin threshold
// - Includes logo (src/resources/logo.svg)

// v06+drag: Panels are draggable and persist positions in localStorage.
// Drag using the handle ⠿ on each panel header.
// Reset layout with the ↺ button (top-right panel).

function shouldIgnoreKey(ev) {
  const t = ev?.target;
  const tag = t?.tagName ? String(t.tagName).toUpperCase() : '';
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || ev?.metaKey || ev?.ctrlKey || ev?.altKey;
}

function safeDispatchKey(key) {
  try {
    window.dispatchEvent(new KeyboardEvent('keydown', { key, bubbles: true }));
  } catch (_) {}
}

function toggleFullscreen() {
  const doc = document;
  const el = document.documentElement;
  if (!doc.fullscreenElement) el.requestFullscreen?.();
  else doc.exitFullscreen?.();
}

const LAYOUT_KEY = 'eliteHudLayout_v1';

function loadLayout() {
  try {
    const raw = localStorage.getItem(LAYOUT_KEY);
    return raw ? JSON.parse(raw) : { panels: {}, locked: false };
  } catch (_) {
    return { panels: {}, locked: false };
  }
}

function saveLayout(layout) {
  try { localStorage.setItem(LAYOUT_KEY, JSON.stringify(layout)); } catch (_) {}
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function applyPanelPos(panelEl, pos) {
  if (!panelEl || !pos) return;
  // Switch to explicit left/top positioning and disable right/bottom defaults.
  panelEl.style.right = 'auto';
  panelEl.style.bottom = 'auto';
  panelEl.style.left = `${pos.left}px`;
  panelEl.style.top = `${pos.top}px`;
}

function getPanelPos(panelEl) {
  const r = panelEl.getBoundingClientRect();
  return { left: Math.round(r.left), top: Math.round(r.top) };
}

function clampPanelIntoView(panelEl) {
  if (!panelEl) return;
  const r = panelEl.getBoundingClientRect();
  const vw = window.innerWidth || document.documentElement.clientWidth || 1;
  const vh = window.innerHeight || document.documentElement.clientHeight || 1;
  const maxL = Math.max(0, vw - r.width);
  const maxT = Math.max(0, vh - r.height);
  const left = clamp(r.left, 0, maxL);
  const top = clamp(r.top, 0, maxT);
  applyPanelPos(panelEl, { left, top });
}

function makeDraggable(panelEl, handleEl, layout, panelKey, isLockedFn) {
  if (!panelEl || !handleEl) return;
  let dragging = false;
  let startX = 0, startY = 0;
  let baseLeft = 0, baseTop = 0;
  let raf = 0;
  let nextLeft = 0, nextTop = 0;

  const paint = () => {
    raf = 0;
    applyPanelPos(panelEl, { left: nextLeft, top: nextTop });
  };

  const onMove = (ev) => {
    if (!dragging) return;
    const dx = ev.clientX - startX;
    const dy = ev.clientY - startY;

    // Clamp inside viewport
    const r = panelEl.getBoundingClientRect();
    const vw = window.innerWidth || document.documentElement.clientWidth || 1;
    const vh = window.innerHeight || document.documentElement.clientHeight || 1;
    const maxL = Math.max(0, vw - r.width);
    const maxT = Math.max(0, vh - r.height);

    nextLeft = clamp(baseLeft + dx, 0, maxL);
    nextTop = clamp(baseTop + dy, 0, maxT);
    if (!raf) raf = requestAnimationFrame(paint);
  };

  const onUp = () => {
    if (!dragging) return;
    dragging = false;
    panelEl.classList.remove('dragging');
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    window.removeEventListener('pointercancel', onUp);

    const pos = getPanelPos(panelEl);
    layout.panels[panelKey] = pos;
    saveLayout(layout);
  };

  handleEl.addEventListener('pointerdown', (ev) => {
    if (isLockedFn?.()) return;
    if (ev.button != null && ev.button !== 0) return;
    ev.preventDefault?.();
    ev.stopPropagation?.();

    // Ensure we start from explicit left/top (even if the panel was using right/bottom)
    const current = getPanelPos(panelEl);
    applyPanelPos(panelEl, current);

    dragging = true;
    startX = ev.clientX;
    startY = ev.clientY;
    baseLeft = current.left;
    baseTop = current.top;
    nextLeft = baseLeft;
    nextTop = baseTop;
    panelEl.classList.add('dragging');

    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerup', onUp, { passive: true });
    window.addEventListener('pointercancel', onUp, { passive: true });
  });
}

export function createEliteHud({
  camera,
  engine,
  floating,
  labelsApi,
  gridController,
  camCtrl,
  mountId = 'eliteHudMount',
  logoUrl,
} = {}) {
  if (typeof document === 'undefined') return { update() {}, setVisible() {} };

  // Try auto-wire from globals if not provided
  camCtrl = camCtrl || window.__camCtrl || null;

  const mount = document.getElementById(mountId) || document.body;

  // If hot-reloading or re-bootstrapping, remove previous instance
  try { document.getElementById('eliteHudRoot')?.remove(); } catch (_) {}

  // One-time CSS
  if (!document.getElementById('eliteHudStyles')) {
    const st = document.createElement('style');
    st.id = 'eliteHudStyles';
    st.textContent = `
      :root{
        --hudC: rgba(0,255,204,0.92);
        --hudC2: rgba(0,255,204,0.25);
        --hudBg: rgba(0,0,0,0.35);
        --hudBg2: rgba(0,0,0,0.20);
        --hudLine: rgba(0,255,204,0.20);
        --hudWarn: rgba(255,160,0,0.95);
        --hudRed: rgba(255,60,60,0.95);
      }
      #eliteHudRoot{ position:fixed; inset:0; z-index:9999; pointer-events:none; }
      #eliteHudRoot.eliteHidden{ display:none; }
      .elitePanel{
        pointer-events:auto;
        font-family: Orbitron, system-ui, -apple-system, Segoe UI, Arial, sans-serif;
        color: rgba(210,255,245,0.95);
        background: var(--hudBg);
        border: 1px solid var(--hudLine);
        border-radius: 12px;
        backdrop-filter: blur(6px);
        box-shadow: 0 0 0 1px rgba(0,0,0,0.35) inset;
        position:relative;
        overflow:hidden;
      }
      .elitePanel:before{
        content:'';
        position:absolute; inset:0;
        background: linear-gradient(90deg, rgba(0,255,204,0.08), transparent 40%, transparent 60%, rgba(0,255,204,0.06));
        pointer-events:none;
      }
      .eliteHdr{
        display:flex; align-items:center; justify-content:space-between;
        gap:10px; padding:10px 12px 6px 12px;
        border-bottom: 1px solid rgba(0,255,204,0.10);
      }
      .eliteHdr .dragHandle{
        display:inline-flex; align-items:center; justify-content:center;
        width: 26px; height: 26px;
        border-radius: 9px;
        border: 1px solid rgba(0,255,204,0.18);
        background: rgba(0,0,0,0.25);
        color: rgba(0,255,204,0.75);
        cursor: grab;
        user-select:none;
      }
      .eliteHdr .dragHandle:active{ cursor: grabbing; }
      .elitePanel.dragging{ outline: 2px solid rgba(0,255,204,0.20); }
      .eliteHdr .title{ letter-spacing:0.8px; font-size:12px; color: var(--hudC); text-shadow: 0 0 10px rgba(0,255,204,0.22); }
      .eliteBody{ padding:10px 12px 12px 12px; font-size:12px; }
      .eliteRow{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
      .eliteCol{ display:flex; flex-direction:column; gap:6px; }
      .eliteK{ color: rgba(0,255,204,0.9); }
      .eliteV{ color: rgba(225,255,250,0.95); }
      .eliteMuted{ opacity:0.75; }
      .eliteBtn{
        pointer-events:auto;
        font-family: Orbitron, system-ui, sans-serif;
        font-size: 12px;
        color: rgba(210,255,245,0.95);
        background: rgba(0,0,0,0.40);
        border: 1px solid rgba(0,255,204,0.22);
        border-radius: 10px;
        padding: 6px 10px;
        cursor:pointer;
        transition: transform 0.06s ease, border-color 0.12s ease, background 0.12s ease;
      }
      .eliteBtn:hover{ border-color: rgba(0,255,204,0.45); background: rgba(0,0,0,0.55); }
      .eliteBtn:active{ transform: translateY(1px); }
      .eliteBtn.on{ outline: 2px solid rgba(0,255,204,0.25); }
      .eliteSeg{ display:flex; gap:6px; flex-wrap:wrap; }
      .eliteSeg .eliteBtn{ padding: 5px 8px; border-radius: 9px; }
      .eliteSwitch{ display:flex; align-items:center; gap:8px; }
      .eliteSwitch input{ accent-color: rgba(0,255,204,0.85); }
      .eliteNotes{
        width: 320px; max-width: 40vw;
        height: 120px;
        resize: vertical;
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace;
        font-size: 12px;
        color: rgba(225,255,250,0.95);
        background: rgba(0,0,0,0.30);
        border: 1px solid rgba(0,255,204,0.18);
        border-radius: 10px;
        padding: 8px;
        outline:none;
      }
      .eliteCorner{
        position:absolute; width:14px; height:14px; border-color: rgba(0,255,204,0.35);
        border-style: solid; pointer-events:none;
      }
      .eliteCorner.tl{ left:10px; top:10px; border-width:2px 0 0 2px; border-radius: 12px 0 0 0; }
      .eliteCorner.tr{ right:10px; top:10px; border-width:2px 2px 0 0; border-radius: 0 12px 0 0; }
      .eliteCorner.bl{ left:10px; bottom:10px; border-width:0 0 2px 2px; border-radius: 0 0 0 12px; }
      .eliteCorner.br{ right:10px; bottom:10px; border-width:0 2px 2px 0; border-radius: 0 0 12px 0; }

      /* Layout */
      #eliteHudTopLeft{ position:fixed; left:14px; top:14px; width: 430px; max-width: calc(100vw - 28px); }
      #eliteHudTopRight{ position:fixed; right:14px; top:14px; width: 360px; max-width: calc(100vw - 28px); }
      #eliteHudBottomLeft{ position:fixed; left:14px; bottom:14px; width: 430px; max-width: calc(100vw - 28px); }
      #eliteHudReticle{ position:fixed; inset:0; pointer-events:none; }
      #eliteHudReticle .ret{
        position:absolute; left:50%; top:50%; width:64px; height:64px; transform:translate(-50%,-50%);
        border: 1px solid rgba(0,255,204,0.10);
        border-radius: 14px;
      }
      #eliteHudReticle .ret:before, #eliteHudReticle .ret:after{
        content:''; position:absolute; left:50%; top:50%; width:92px; height:1px;
        background: rgba(0,255,204,0.12); transform:translate(-50%,-50%);
      }
      #eliteHudReticle .ret:after{
        width:1px; height:92px; background: rgba(0,255,204,0.10);
      }
      #eliteHudHint{
        position:fixed; left:50%; bottom:10px; transform:translateX(-50%);
        font-family: Orbitron, system-ui, sans-serif;
        font-size: 12px;
        color: rgba(0,255,204,0.75);
        text-shadow: 0 0 10px rgba(0,255,204,0.18);
        pointer-events:none;
        opacity: 0.65;
      }
      @media (max-width: 920px){
        #eliteHudTopLeft, #eliteHudTopRight, #eliteHudBottomLeft{ width: calc(100vw - 28px); }
      }
    `;
    document.head.appendChild(st);
  }

  const layout = loadLayout();

  const root = document.createElement('div');
  root.id = 'eliteHudRoot';

  // Reticle + hint
  const ret = document.createElement('div');
  ret.id = 'eliteHudReticle';
  ret.innerHTML = `<div class="ret"></div>`;
  const hint = document.createElement('div');
  hint.id = 'eliteHudHint';
  hint.textContent = 'C · HUD   |   M · Ratón   |   K · Nave   |   0-9 · Velocidad   |   Shift · Turbo';

  // Panels
  const topLeft = document.createElement('div');
  topLeft.id = 'eliteHudTopLeft';
  topLeft.className = 'elitePanel';
  topLeft.innerHTML = `
    <div class="eliteCorner tl"></div><div class="eliteCorner tr"></div><div class="eliteCorner bl"></div><div class="eliteCorner br"></div>
    <div class="eliteHdr">
      <div style="display:flex;align-items:center;gap:10px;">
        <img id="eliteLogo" alt="logo" style="width:34px;height:34px;opacity:0.95;filter: drop-shadow(0 0 10px rgba(0,255,204,0.18));" />
        <div>
          <div class="title">NAV / STATUS</div>
          <div class="eliteMuted" style="font-size:11px;">Floating Origin <span id="th"></span></div>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:8px;">
        <span class="dragHandle" id="dragTopLeft" title="Arrastra para mover">⠿</span>
        <button class="eliteBtn" id="btnFullscreen" title="Pantalla completa">⛶</button>
      </div>
    </div>
    <div class="eliteBody">
      <div class="eliteCol">
        <div class="eliteRow">
          <span class="eliteK">ABS</span><span class="eliteV" id="abs">—</span>
        </div>
        <div class="eliteRow">
          <span class="eliteK">CAM</span><span class="eliteV" id="cam">—</span>
        </div>
        <div class="eliteRow">
          <span class="eliteK">OFF</span><span class="eliteV" id="off">—</span>
        </div>
        <div class="eliteRow" style="margin-top:6px; gap:14px;">
          <label class="eliteSwitch"><input id="toggleNames" type="checkbox" checked> <span>Names</span></label>
          <label class="eliteSwitch"><input id="toggleGrid" type="checkbox" checked> <span>Grid</span></label>
        </div>
      </div>
    </div>
  `;

  const topRight = document.createElement('div');
  topRight.id = 'eliteHudTopRight';
  topRight.className = 'elitePanel';
  topRight.innerHTML = `
    <div class="eliteCorner tl"></div><div class="eliteCorner tr"></div><div class="eliteCorner bl"></div><div class="eliteCorner br"></div>
    <div class="eliteHdr">
      <div class="title">FLIGHT / MODES</div>
      <div style="display:flex;align-items:center;gap:8px;">
        <button class="eliteBtn" id="btnLayoutReset" title="Reset HUD layout">↺</button>
        <span class="dragHandle" id="dragTopRight" title="Arrastra para mover">⠿</span>
        <button class="eliteBtn" id="btnHudToggle" title="Mostrar/ocultar HUD (C)">C</button>
      </div>
    </div>
    <div class="eliteBody">
      <div class="eliteRow" style="justify-content:space-between;">
        <div class="eliteRow" style="gap:8px;">
          <button class="eliteBtn" id="btnModeMouse">M · Ratón</button>
          <button class="eliteBtn" id="btnModeShip">K · Nave</button>
        </div>
        <div class="eliteRow" style="gap:8px;">
          <span class="eliteK">SPD</span>
          <span class="eliteV" id="hudSpeed">0</span>
        </div>
      </div>
      <div class="eliteMuted" style="margin:8px 0 6px 0; font-size:11px;">0=Stop · 1=Sound · 2=Light · 9=1LY/h</div>
      <div class="eliteSeg" id="speedSeg"></div>
    </div>
  `;

  const bottomLeft = document.createElement('div');
  bottomLeft.id = 'eliteHudBottomLeft';
  bottomLeft.className = 'elitePanel';
  bottomLeft.innerHTML = `
    <div class="eliteCorner tl"></div><div class="eliteCorner tr"></div><div class="eliteCorner bl"></div><div class="eliteCorner br"></div>
    <div class="eliteHdr">
      <div class="eliteRow" style="align-items:center;gap:10px;">
        <div class="title">COMMS / NOTES</div>
        <span class="dragHandle" id="dragBottomLeft" title="Arrastra para mover">⠿</span>
      </div>
      <div class="eliteMuted" style="font-size:11px;">(Escribe aquí sin afectar a las teclas de vuelo)</div>
    </div>
    <div class="eliteBody">
      <textarea class="eliteNotes" id="hudNotes" placeholder="Notas… / comandos…"></textarea>
    </div>
  `;

  root.appendChild(ret);
  root.appendChild(topLeft);
  root.appendChild(topRight);
  root.appendChild(bottomLeft);
  root.appendChild(hint);
  mount.appendChild(root);

  // Apply saved panel positions
  try {
    if (layout?.panels?.eliteHudTopLeft) applyPanelPos(topLeft, layout.panels.eliteHudTopLeft);
    if (layout?.panels?.eliteHudTopRight) applyPanelPos(topRight, layout.panels.eliteHudTopRight);
    if (layout?.panels?.eliteHudBottomLeft) applyPanelPos(bottomLeft, layout.panels.eliteHudBottomLeft);
    // Clamp after first layout pass
    setTimeout(() => {
      clampPanelIntoView(topLeft);
      clampPanelIntoView(topRight);
      clampPanelIntoView(bottomLeft);
    }, 0);
  } catch (_) {}

  // Logo
  try {
    const img = root.querySelector('#eliteLogo');
    img.src = logoUrl || new URL('../resources/logo.svg', import.meta.url).href;
  } catch (_) {}

  // Speed segmented buttons
  const seg = root.querySelector('#speedSeg');
  const speedBtns = [];
  for (let i = 0; i <= 9; i++) {
    const b = document.createElement('button');
    b.className = 'eliteBtn';
    b.textContent = String(i);
    b.title = `Velocidad ${i}`;
    b.onclick = () => {
      if (camCtrl?.setSpeedLevel) camCtrl.setSpeedLevel(i);
      else safeDispatchKey(String(i));
      updateModeAndSpeed();
    };
    seg.appendChild(b);
    speedBtns.push(b);
  }

  // Buttons
  const btnFs = root.querySelector('#btnFullscreen');
  const btnHud = root.querySelector('#btnHudToggle');
  const btnLayoutReset = root.querySelector('#btnLayoutReset');
  const btnMouse = root.querySelector('#btnModeMouse');
  const btnShip = root.querySelector('#btnModeShip');
  const elSpeed = root.querySelector('#hudSpeed');
  const notes = root.querySelector('#hudNotes');

  btnFs?.addEventListener('click', toggleFullscreen);
  btnHud?.addEventListener('click', () => setVisible(root.classList.contains('eliteHidden')));
  btnLayoutReset?.addEventListener('click', () => {
    // Clear persisted positions and restore defaults
    layout.panels = {};
    saveLayout(layout);
    // Remove inline styles so CSS defaults apply again
    for (const el of [topLeft, topRight, bottomLeft]) {
      el.style.left = '';
      el.style.top = '';
      el.style.right = '';
      el.style.bottom = '';
    }
  });
  btnMouse?.addEventListener('click', () => {
    if (camCtrl?.setMode) camCtrl.setMode('mouse');
    else safeDispatchKey('m');
    updateModeAndSpeed();
  });
  btnShip?.addEventListener('click', () => {
    if (camCtrl?.setMode) camCtrl.setMode('ship');
    else safeDispatchKey('k');
    updateModeAndSpeed();
  });

  // Notes persistence
  try {
    const key = 'eliteHudNotes';
    const saved = localStorage.getItem(key);
    if (saved != null) notes.value = saved;
    notes.addEventListener('input', () => localStorage.setItem(key, notes.value));
    // Stop key events so flight controls don't react
    notes.addEventListener('keydown', (e) => e.stopPropagation());
    notes.addEventListener('keyup', (e) => e.stopPropagation());
  } catch (_) {}

  // HUD show/hide (C)
  function onKeyDown(ev) {
    if (shouldIgnoreKey(ev)) return;
    const k = (ev.key || '').toLowerCase();
    if (k === 'c') {
      ev.preventDefault?.();
      setVisible(root.classList.contains('eliteHidden'));
    }
  }
  window.addEventListener('keydown', onKeyDown, { passive: false });

  // Wire toggles directly as well (in case initHudToggles isn't used)
  const toggleNames = root.querySelector('#toggleNames');
  const toggleGrid = root.querySelector('#toggleGrid');

  function applyNames() {
    const on = !!toggleNames?.checked;
    labelsApi?.setShowLabels?.(on);
  }
  function applyGrid() {
    const on = !!toggleGrid?.checked;
    gridController?.setEnabled?.(on);
  }
  toggleNames?.addEventListener('change', applyNames);
  toggleGrid?.addEventListener('change', applyGrid);

  // Initial apply
  applyNames();
  applyGrid();

  // PERF: throttle + cache HUD state
  const UI_MS = 120;
  let _lastUiT = 0;
  let _lastMode = '';
  let _lastSpeed = -1;
  let _lastFs = null;

  function updateModeAndSpeed() {
    const mode = camCtrl?.getMode?.() || camCtrl?._state?.mode || 'mouse';
    const spd = camCtrl?.getSpeedLevel?.() ?? camCtrl?._state?.ship?.speedLevel;
    const level = Number.isFinite(spd) ? spd : 0;
    // PERF: avoid DOM churn when nothing changed
    if (mode !== _lastMode) {
      if (btnMouse) btnMouse.classList.toggle('on', mode === 'mouse');
      if (btnShip) btnShip.classList.toggle('on', mode === 'ship');
      _lastMode = mode;
    }
    if (level !== _lastSpeed) {
      if (elSpeed) elSpeed.textContent = String(level);
      for (let i = 0; i < speedBtns.length; i++) speedBtns[i].classList.toggle('on', i === level);
      _lastSpeed = level;
    }
  }

  function setVisible(on) {
    root.classList.toggle('eliteHidden', !on);
  }

  // Make panels draggable (using handles)
  const isLocked = () => !!layout.locked;
  makeDraggable(topLeft, root.querySelector('#dragTopLeft'), layout, 'eliteHudTopLeft', isLocked);
  makeDraggable(topRight, root.querySelector('#dragTopRight'), layout, 'eliteHudTopRight', isLocked);
  makeDraggable(bottomLeft, root.querySelector('#dragBottomLeft'), layout, 'eliteHudBottomLeft', isLocked);

  // Clamp on resize
  const onResize = () => {
    clampPanelIntoView(topLeft);
    clampPanelIntoView(topRight);
    clampPanelIntoView(bottomLeft);
    // Persist clamped positions if we already had a saved one
    const p = layout.panels || {};
    if (p.eliteHudTopLeft) p.eliteHudTopLeft = getPanelPos(topLeft);
    if (p.eliteHudTopRight) p.eliteHudTopRight = getPanelPos(topRight);
    if (p.eliteHudBottomLeft) p.eliteHudBottomLeft = getPanelPos(bottomLeft);
    saveLayout(layout);
  };
  window.addEventListener('resize', onResize, { passive: true });

  // Public update hook (call from render loop)
  function update() {
    // PERF: HUD doesn't need 60fps updates
    const now = performance.now();
    if ((now - _lastUiT) < UI_MS) return;
    _lastUiT = now;

    // keep fullscreen icon state (optional)
    try {
      const fs = !!document.fullscreenElement;
      if (btnFs && fs !== _lastFs) {
        btnFs.textContent = fs ? '⛶×' : '⛶';
        _lastFs = fs;
      }
    } catch (_) {}

    updateModeAndSpeed();
  }

  // One immediate update
  update();

  // Cleanup if engine/scene is disposed
  try {
    const obs = engine?.onDisposeObservable || camera?.getScene?.()?.onDisposeObservable;
    obs?.add?.(() => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('resize', onResize);
    });
  } catch (_) {}

  return {
    update,
    setVisible,
    root,
  };
}
