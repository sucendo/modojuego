# Planet Editor — Modular (Babylon.js)
Abre `index.html` desde Apache/WAMP.

## Controles
- Océano: patch (sin esfera superpuesta)
- Nubes: capa mesh real, siempre por encima del océano, sin verse por detrás del planeta
- Anillos: ribbon con bandas
- Tipo: Rocky / GasGiant
- Guardar/Cargar: JSON del planeta (no exporta luz/animación)
