// bodies/systems.js
// Construye los nodos de sistema (ancla + dot billboard + label)

const LY_KM = 9.4607304725808e12; // km en 1 año-luz

export function buildSystemNodes({ scene, worldRoot, GALAXY, SYSTEMS, labelsApi }) {
  if (!scene || !worldRoot) throw new Error('[systems] scene/worldRoot required');

  const sysObj = (GALAXY && GALAXY.system) ? GALAXY.system : (SYSTEMS || {});
  const lyUnits = (typeof sysObj.__LY === 'number')
    ? sysObj.__LY
    : (typeof SYSTEMS?.__LY === 'number') ? SYSTEMS.__LY : 1_000_000;

  try { if (GALAXY?.system && typeof GALAXY.system === 'object') GALAXY.system.__LY = lyUnits; } catch (_) {}
  const kmPerUnitWorld = LY_KM / Math.max(1, lyUnits);

  const systemNodes = [];

  function toVector3(v) {
    if (!v) return null;
    if (v.clone && typeof v.clone === 'function') return v.clone();
    if (typeof v.x === 'number' && typeof v.y === 'number' && typeof v.z === 'number') return new BABYLON.Vector3(v.x, v.y, v.z);
    return null;
  }

  for (const name of Object.keys(sysObj)) {
    if (name === '__LY') continue;
    const def = sysObj[name];
    if (!def?.posLY) continue;
    const posLY = toVector3(def.posLY);
    if (!posLY) continue;
    const posWorld = posLY.scale(lyUnits);

    const sys = new BABYLON.TransformNode(`sys_${name}`, scene);
    sys.parent = worldRoot;
    sys.position.copyFrom(posWorld);

    const dot = BABYLON.MeshBuilder.CreatePlane(`sysDot_${name}`, { width: 1, height: 1 }, scene);
    dot.parent = sys;
    dot.billboardMode = BABYLON.Mesh.BILLBOARDMODE_ALL;
    dot.isPickable = false;
    dot.renderingGroupId = 1;
    dot.metadata = Object.assign({}, dot.metadata, { kmPerUnit: kmPerUnitWorld });

    const dmat = new BABYLON.StandardMaterial(`sysDotMat_${name}`, scene);
    dmat.disableLighting = true;
    dmat.emissiveColor = new BABYLON.Color3(1, 1, 1);
    dmat.alpha = 1.0;
    dmat.backFaceCulling = false;
    dot.material = dmat;

    if (labelsApi?.registerLabel) labelsApi.registerLabel(`system:${String(name)}`, String(name), 'system', dot, { system: name });

    systemNodes.push({ system: sys, dot, name, stars: [], primaryStar: null });
  }

  return { systemNodes, kmPerUnitWorld, lyUnits };
}