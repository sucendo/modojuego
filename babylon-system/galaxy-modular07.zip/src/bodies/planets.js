// bodies/planets.js
// Crea planetas y lunas a partir de GALAXY.planets / GALAXY.satellites.

export function buildPlanets({ scene, systemNodes, starMeshById, GALAXY, lights, labelsApi, kmPerUnitLocal = 1e6 }) {
  if (!scene || !Array.isArray(systemNodes)) throw new Error('[planets] scene/systemNodes required');

  const planetSystems = [];
  const planetMeshById = new Map();
  // "moon" legacy -> ahora "satellite", pero mantenemos el nombre para no romper imports
  const moonMeshById = new Map(); // satelliteId -> Mesh

  const stars = GALAXY?.star || {};
  const planets = GALAXY?.planets || {};
  const satellites = GALAXY?.satellites || {};

  const starsBySystem = new Map();
  for (const [starId, sdef] of Object.entries(stars)) {
    const sys = sdef?.orbits;
    if (!sys) continue;
    if (!starsBySystem.has(sys)) starsBySystem.set(sys, []);
    starsBySystem.get(sys).push({ id: starId, def: sdef });
  }

  const planetsByStar = new Map();
  for (const [pid, pdef] of Object.entries(planets)) {
    const sid = pdef?.orbits;
    if (!sid) continue;
    if (!planetsByStar.has(sid)) planetsByStar.set(sid, []);
    planetsByStar.get(sid).push({ id: pid, def: pdef });
  }

  const KM_TO_UNITS_ORBIT = 1 / 1e6;   // 1 unidad = 1 millón de km
  const KM_TO_UNITS_SIZE  = 1 / 50000; // radio km -> unidades radio
  
  const TAU = Math.PI * 2;
  const DEG = Math.PI / 180;

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function colorFromDef(c) {
    if (typeof c === 'number') {
      const hex = '#' + (c >>> 0).toString(16).padStart(6, '0');
      return BABYLON.Color3.FromHexString(hex);
    }
    return null;
  }
  function radPerDayFromPeriod(periodDays, fallback) {
    const p = Number(periodDays);
    if (!Number.isFinite(p) || p === 0) return fallback;
    return TAU / p;
  }
  function label(kind, sysName, text, mesh, planetId) {
    if (!labelsApi?.registerLabel) return;
    const key = `${kind}:${sysName}:${planetId || ''}:${String(text)}`;
    labelsApi.registerLabel(key, String(text), kind, mesh, { system: sysName, planet: planetId });
  }

  // Mapa genérico de cuerpos por id para colgar satélites donde toque
  // value: { mesh, orbit, systemName, satellites: [] }
  const bodyById = new Map();

  function getOrbitDirFromDef(def) {
    // Si orbitalPeriod es negativo -> retrograde
    const p = Number(def?.orbitalPeriod);
    if (Number.isFinite(p) && p < 0) return -1;
    if (def?.retrogradeOrbit === true) return -1;
    if (def?.orbitDirection === -1) return -1;
    return 1;
  }

  function getSpinDirFromDef(def) {
    const rp = Number(def?.rotationPeriod);
    if (Number.isFinite(rp) && rp < 0) return -1;
    const tilt = Number(def?.axialTilt);
    if (Number.isFinite(tilt) && tilt > 90) return -1; // Venus/Urano style
    if (def?.retrogradeSpin === true) return -1;
    if (def?.spinDirection === -1) return -1;
    return 1;
  }

  function meanFromLastPerihelion(def, nAbs) {
    // mean anomaly at "now" (radian)
    const s = def?.lastPerihelion;
    if (!s || !nAbs) return 0;
    const t0 = Date.parse(s);
    if (Number.isNaN(t0)) return 0;
    const daysSince = (Date.now() - t0) / 86400000;
    return (daysSince * nAbs);
  }

  function createOrbitNodes({ systemName, parentMesh, bodyId, def }) {
    // Orientación orbital: Ω (Y), i (X), ω (Y dentro del plano)
    const lonAsc = Number(def?.longitudeOfAscendingNode || 0) * DEG;
    const inc    = Number(def?.inclination || 0) * DEG;
    const argPeri= Number(def?.argumentOfPeriapsis || 0) * DEG;

    const orbitPlane = new BABYLON.TransformNode(`orbPlane_${systemName}_${bodyId}`, scene);
    orbitPlane.parent = parentMesh;
    orbitPlane.rotation.y = lonAsc;
    orbitPlane.rotation.x = inc;

    const orbitArg = new BABYLON.TransformNode(`orb_${systemName}_${bodyId}`, scene);
    orbitArg.parent = orbitPlane;
    orbitArg.rotation.y = argPeri;

    return { orbitPlane, orbitArg };
  }

  function createBodyMesh({ systemName, parentOrbit, bodyId, def, kind, defaultSizeKm }) {
    const radiusUnits = (Number(def?.size || defaultSizeKm)) * KM_TO_UNITS_SIZE;
    const d = Math.max(0.001, radiusUnits * 2);

    const mesh = BABYLON.MeshBuilder.CreateSphere(`${kind}_${systemName}_${bodyId}`, { diameter: d, segments: (kind === 'planet' ? 18 : 14) }, scene);
    mesh.parent = parentOrbit;
    mesh.isPickable = false;
    mesh.metadata = Object.assign({}, mesh.metadata, { kmPerUnit: kmPerUnitLocal, systemName, bodyId, kind });

    const mat = new BABYLON.StandardMaterial(`${kind}Mat_${systemName}_${bodyId}`, scene);
    const c = colorFromDef(def?.color) || (kind === 'planet' ? new BABYLON.Color3(0.35, 0.35, 0.35) : new BABYLON.Color3(0.7, 0.7, 0.7));
    mat.diffuseColor = c;
    mat.emissiveColor = c.scale(kind === 'planet' ? 0.02 : 0.18);
    mat.specularColor = new BABYLON.Color3(0.06, 0.06, 0.06);
    mesh.material = mat;

    // Luz del sistema
    lights?.includeMesh?.(systemName, mesh);
    return mesh;
  }

  function initSpin(mesh, def) {
    // rotación: rotationPeriod (días); dirección por signo / axialTilt>90
    const spinDir = getSpinDirFromDef(def);
    const rpAbs = Math.abs(Number(def?.rotationPeriod || 0));
    const spinAbs = (rpAbs > 0) ? (TAU / rpAbs) : 0.35; // rad/día

    // Eje base
    const ra = def?.rotationAxis;
    let axis = (ra && Number.isFinite(ra.x) && Number.isFinite(ra.y) && Number.isFinite(ra.z))
      ? new BABYLON.Vector3(ra.x, ra.y, ra.z)
      : new BABYLON.Vector3(0, 1, 0);
    if (axis.lengthSquared() < 1e-9) axis.set(0, 1, 0);
    axis.normalize();

    // axialTilt -> inclinamos el eje (aprox) alrededor de Z
    const tilt = Number(def?.axialTilt || 0) * DEG;
    if (tilt) {
      const q = BABYLON.Quaternion.RotationAxis(BABYLON.Axis.Z, tilt);
      const m = new BABYLON.Matrix();
      // Compat Babylon: en algunas versiones no existe Matrix.FromQuaternion
      if (typeof BABYLON.Matrix.FromQuaternionToRef === 'function') {
        BABYLON.Matrix.FromQuaternionToRef(q, m);
      } else if (typeof q.toRotationMatrix === 'function') {
        q.toRotationMatrix(m);
      } else {
        // fallback ultra defensivo
        BABYLON.Matrix.RotationYawPitchRollToRef(0, 0, tilt, m);
      }
      axis = BABYLON.Vector3.TransformNormal(axis, m);
      if (axis.lengthSquared() < 1e-9) axis.set(0, 1, 0);
      axis.normalize();
    }

    // Guardamos axis en metadata y giramos sobre él (LOCAL)
    mesh.metadata.spin = spinDir * spinAbs;
    mesh.metadata.spinAxis = axis;
  }

  function initOrbit(orbitNode, def) {
    // Kepler: a,e,n,mean (mean anomaly)
    const peri = Math.max(0, Number(def?.periapsis || 0));
    const apo  = Math.max(0, Number(def?.apoapsis || 0));
    const aKm  = (peri + apo) * 0.5;
    const denom = (peri + apo);
    const e = (denom > 0) ? clamp((apo - peri) / denom, 0, 0.999999) : 0;

    // Si no hay peri/apo válidos, fallback a circular con aKm=0 -> aU pequeño
    const aU = Math.max(0.001, (aKm > 0 ? aKm : Math.max(peri, apo, 1)) * KM_TO_UNITS_ORBIT);

    const orbitDir = getOrbitDirFromDef(def);
    const pAbs = Math.abs(Number(def?.orbitalPeriod || 0));
    const nAbs = (pAbs > 0) ? (TAU / pAbs) : (TAU / 365.25); // rad/día

    const Mnow = meanFromLastPerihelion(def, nAbs);

    orbitNode.metadata = Object.assign({}, orbitNode.metadata, {
      aU, e,
      mean: orbitDir * Mnow,
      n: nAbs,
      dir: orbitDir,
    });
  }

  function makePlanetFromDef(systemName, starMesh, planetId, pdef) {
    const { orbitPlane, orbitArg } = createOrbitNodes({ systemName, parentMesh: starMesh, bodyId: planetId, def: pdef });
 

    const planet = createBodyMesh({ systemName, parentOrbit: orbitArg, bodyId: planetId, def: pdef, kind: 'planet', defaultSizeKm: 2500 });
    planetMeshById.set(planetId, planet);	
    label('planet', systemName, planetId, planet, planetId);

    initOrbit(orbitArg, pdef);
    initSpin(planet, pdef);

    const out = { orbit: orbitArg, orbitPlane, planet, satellites: [] };
    // compat antigua
    out.moons = out.satellites;

    bodyById.set(planetId, { mesh: planet, orbit: orbitArg, systemName, satellites: out.satellites });
    return out;
  }

  for (const it of systemNodes) {
    const sysName = it.name;
    const starList = starsBySystem.get(sysName) || [];

    const planetsOut = [];
    for (const st of starList) {
      const starMesh = starMeshById.get(st.id) || it.primaryStar;
      if (!starMesh) continue;

      const plist = planetsByStar.get(st.id) || [];
      plist.sort((a, b) => (((a.def?.periapsis || 0) + (a.def?.apoapsis || 0)) * 0.5) - (((b.def?.periapsis || 0) + (b.def?.apoapsis || 0)) * 0.5));

      for (const { id: pid, def: pdef } of plist) planetsOut.push(makePlanetFromDef(sysName, starMesh, pid, pdef));
    }

    planetSystems.push({ systemName: sysName, planets: planetsOut });
  }
  
  // ============================
  // Satélites: 2ª pasada (enlaza por def.orbits)
  // ============================
  // Hacemos varias pasadas por si hay satélites de satélites
  const pending = new Map(Object.entries(satellites || {})); // id -> def
  let progressed = true;
  let safety = 0;
  while (pending.size && progressed && safety++ < 10) {
    progressed = false;
    for (const [sid, sdef] of Array.from(pending.entries())) {
      const parentId = sdef?.orbits;
      if (!parentId) { pending.delete(sid); continue; }

      const parentBody = bodyById.get(parentId);
      // Permitimos satélite orbitando estrella por id de estrella
      let parentMesh = parentBody?.mesh || starMeshById.get(parentId) || null;
      let systemName = parentBody?.systemName || null;

      if (!parentMesh) continue; // aún no existe el padre (quizá satélite de satélite)

      // si cuelga de una estrella, intentamos inferir sistema por su parent (sys_XXX)
      if (!systemName) {
        // starMesh parent es el TransformNode del sistema (sys_X)
        const sysNodeName = parentMesh.parent?.name || '';
        systemName = sysNodeName.startsWith('sys_') ? sysNodeName.slice(4) : (parentMesh.metadata?.systemName || 'Sol');
      }

      const { orbitPlane, orbitArg } = createOrbitNodes({ systemName, parentMesh, bodyId: sid, def: sdef });
      const satMesh = createBodyMesh({ systemName, parentOrbit: orbitArg, bodyId: sid, def: sdef, kind: 'sat', defaultSizeKm: 300 });
      moonMeshById.set(sid, satMesh);
      label('moon', systemName, sid, satMesh, parentId); // mantenemos kind 'moon' para no romper estilos de label

      initOrbit(orbitArg, sdef);
      initSpin(satMesh, sdef);

      const satObj = { orbit: orbitArg, orbitPlane, mesh: satMesh, satellites: [] };
      satObj.moons = satObj.satellites;

      // registrar para futuros hijos
      bodyById.set(sid, { mesh: satMesh, orbit: orbitArg, systemName, satellites: satObj.satellites });

      // colgar en el padre si era planeta/satélite; si es estrella, no hace falta pero lo guardamos en metadata
      if (parentBody?.satellites) parentBody.satellites.push(satObj);
      else {
        // estrella: lo dejamos “suelto” (seguirá animándose si lo recorremos desde planetSystems?),
        // por simplicidad lo metemos en el sistema como “planeta root” extra:
        const sys = planetSystems.find(s => s.systemName === systemName);
        if (sys) sys.planets.push({ orbit: orbitArg, orbitPlane, planet: satMesh, satellites: satObj.satellites, moons: satObj.satellites });
      }

      pending.delete(sid);
      progressed = true;
    }
  }

  return { planetSystems, planetMeshById, moonMeshById };
}