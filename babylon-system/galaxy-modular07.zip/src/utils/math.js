export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
