// eliteHud.js (v3)
// - Elimina cabin grid (CSS grid animado) por rendimiento.
// - Añade retícula (cruz de dirección) con calibración X/Y por pantalla.
// - Permite 2 AUX: izquierda y derecha, con perspectiva (pitch/yaw) y retícula independientes.
//
// Uso:
//   import { createEliteHud } from "../ui/eliteHud.js";
//   const hud = createEliteHud({ engine, camera, floating, labelsApi, gridController, camCtrl });
//   scene.onBeforeRenderObservable.add(() => hud.update());

function shouldIgnoreKey(ev) {
  const t = ev?.target;
  const tag = t?.tagName ? String(t.tagName).toUpperCase() : "";
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || ev?.metaKey || ev?.ctrlKey || ev?.altKey;
}

function toggleFullscreen() {
  const doc = document;
  const el = document.documentElement;
  if (!doc.fullscreenElement) el.requestFullscreen?.();
  else doc.exitFullscreen?.();
}

function getMainCanvas(engine) {
  try {
    const c = engine?.getRenderingCanvas?.();
    if (c) return c;
  } catch (_) {}
  return document.getElementById("renderCanvas") || document.querySelector("canvas");
}

const MAIN_CFG_KEY = "eliteHud_main_cfg_v3";
function loadMainCfg() {
  const def = {
    visible: true,
    lockLayout: false,
    advOpen: true,
    reticle: {
      enabled: true,
      x: 0.5, // 0..1
      y: 0.5, // 0..1
      sizePx: 42,
      showRefCenter: false,
    },
    panelPos: {
      nav: { x: 14, y: 14, visible: true },
      flight: { x: null, y: 14, visible: true }, // x null => right:14
      notes: { x: 14, y: null, visible: true }, // y null => bottom:14
    },
  };

  try {
    const raw = localStorage.getItem(MAIN_CFG_KEY);
    const cfg = raw ? { ...def, ...JSON.parse(raw) } : def;
    cfg.reticle = { ...def.reticle, ...(cfg.reticle || {}) };
    cfg.panelPos = { ...def.panelPos, ...(cfg.panelPos || {}) };
    return cfg;
  } catch (_) {
    return def;
  }
}

function saveMainCfg(cfg) {
  try {
    localStorage.setItem(MAIN_CFG_KEY, JSON.stringify(cfg));
  } catch (_) {}
}

function makeStylesOnce() {
  if (document.getElementById("eliteHudStyles")) return;
  const st = document.createElement("style");
  st.id = "eliteHudStyles";
  st.textContent = `
    :root{
      --hudC: rgba(0,255,204,0.92);
      --hudLine: rgba(0,255,204,0.20);
      --hudBg: rgba(0,0,0,0.35);

      --retX: 50%;
      --retY: 50%;
      --retS: 42px;
    }

    #eliteHudRoot{ position:fixed; inset:0; z-index:9999; pointer-events:none; }
    #eliteHudRoot.eliteHidden{ display:none; }

    .elitePanel{
      pointer-events:auto;
      font-family: Orbitron, system-ui, -apple-system, Segoe UI, Arial, sans-serif;
      color: rgba(210,255,245,0.95);
      background: var(--hudBg);
      border: 1px solid var(--hudLine);
      border-radius: 12px;
      backdrop-filter: blur(6px);
      box-shadow: 0 0 0 1px rgba(0,0,0,0.35) inset;
      position:fixed;
      overflow:hidden;
    }
    .elitePanel:before{
      content:'';
      position:absolute; inset:0;
      background: linear-gradient(90deg, rgba(0,255,204,0.08), transparent 40%, transparent 60%, rgba(0,255,204,0.06));
      pointer-events:none;
    }

    .eliteHdr{
      display:flex; align-items:center; justify-content:space-between;
      gap:10px; padding:10px 12px 6px 12px;
      border-bottom: 1px solid rgba(0,255,204,0.10);
      cursor: grab;
      user-select:none;
    }
    .eliteHdr:active{ cursor: grabbing; }
    .eliteHdr .title{
      letter-spacing:0.8px; font-size:12px; color: var(--hudC);
      text-shadow: 0 0 10px rgba(0,255,204,0.22);
    }

    .eliteBody{ padding:10px 12px 12px 12px; font-size:12px; }
    .eliteRow{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
    .eliteCol{ display:flex; flex-direction:column; gap:6px; }
    .eliteK{ color: rgba(0,255,204,0.9); }
    .eliteV{ color: rgba(225,255,250,0.95); }
    .eliteMuted{ opacity:0.75; }

    .eliteBtn{
      pointer-events:auto;
      font-family: Orbitron, system-ui, sans-serif;
      font-size: 12px;
      color: rgba(210,255,245,0.95);
      background: rgba(0,0,0,0.40);
      border: 1px solid rgba(0,255,204,0.22);
      border-radius: 10px;
      padding: 6px 10px;
      cursor:pointer;
    }
    .eliteBtn:hover{ border-color: rgba(0,255,204,0.45); background: rgba(0,0,0,0.55); }
    .eliteBtn:active{ transform: translateY(1px); }
    .eliteBtn.on{ outline: 2px solid rgba(0,255,204,0.25); }

    .eliteSeg{ display:flex; gap:6px; flex-wrap:wrap; }
    .eliteSeg .eliteBtn{ padding: 5px 8px; border-radius: 9px; }

    .eliteSwitch{ display:flex; align-items:center; gap:8px; }
    .eliteSwitch input{ accent-color: rgba(0,255,204,0.85); }

    .eliteNotes{
      width: 320px; max-width: 40vw;
      height: 120px;
      resize: vertical;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace;
      font-size: 12px;
      color: rgba(225,255,250,0.95);
      background: rgba(0,0,0,0.30);
      border: 1px solid rgba(0,255,204,0.18);
      border-radius: 10px;
      padding: 8px;
      outline:none;
    }

    .eliteAdv{ display:none; margin-top:10px; padding-top:10px; border-top:1px solid rgba(0,255,204,0.10); }
    .eliteAdv.open{ display:block; }
    .eliteSlider{ width: 180px; }
    .eliteMiniVal{ min-width: 70px; display:inline-block; text-align:right; opacity:0.9; }

    #eliteHudHint{
      position:fixed; left:50%; bottom:10px; transform:translateX(-50%);
      font-family: Orbitron, system-ui, sans-serif;
      font-size: 12px;
      color: rgba(0,255,204,0.75);
      text-shadow: 0 0 10px rgba(0,255,204,0.18);
      pointer-events:none;
      opacity: 0.65;
      user-select:none;
    }

    /* Retícula (cruz de dirección) */
    #eliteReticle{
      position: fixed;
      left: var(--retX);
      top: var(--retY);
      width: var(--retS);
      height: var(--retS);
      transform: translate(-50%, -50%);
      pointer-events:none;
      opacity: 0.95;
      filter: drop-shadow(0 0 6px rgba(0,255,204,0.10));
    }
    #eliteReticle .h{
      position:absolute; left:0; top:50%;
      width:100%;
      border-top: 1px solid rgba(0,255,204,0.78);
    }
    #eliteReticle .v{
      position:absolute; top:0; left:50%;
      height:100%;
      border-left: 1px solid rgba(0,255,204,0.78);
    }
    #eliteReticle .dot{
      position:absolute; left:50%; top:50%;
      width:4px; height:4px;
      transform: translate(-50%, -50%);
      background: rgba(0,255,204,0.90);
      border-radius: 50%;
    }

    /* Referencia fija (centro real 50/50) */
    #eliteRefCenter{
      position: fixed;
      left: 50%;
      top: 50%;
      width: 22px;
      height: 22px;
      transform: translate(-50%, -50%);
      pointer-events:none;
      opacity: 0.35;
      filter: drop-shadow(0 0 6px rgba(0,255,204,0.10));
    }
    #eliteRefCenter .h{
      position:absolute; left:0; top:50%;
      width:100%;
      border-top: 1px solid rgba(0,255,204,0.55);
    }
    #eliteRefCenter .v{
      position:absolute; top:0; left:50%;
      height:100%;
      border-left: 1px solid rgba(0,255,204,0.55);
    }
  `;
  document.head.appendChild(st);
}

function setPanelPos(panel, pos, fallback) {
  if (pos.x == null) {
    panel.style.left = "";
    panel.style.right = fallback?.right != null ? `${fallback.right}px` : "";
  } else {
    panel.style.left = `${pos.x}px`;
    panel.style.right = "";
  }
  if (pos.y == null) {
    panel.style.top = "";
    panel.style.bottom = fallback?.bottom != null ? `${fallback.bottom}px` : "";
  } else {
    panel.style.top = `${pos.y}px`;
    panel.style.bottom = "";
  }
}

function makeDraggable(panelEl, cfg, cfgSaveFn, key) {
  const hdr = panelEl.querySelector(".eliteHdr");
  if (!hdr) return;

  let dragging = false;
  let startX = 0, startY = 0;
  let startLeft = 0, startTop = 0;

  hdr.addEventListener("pointerdown", (e) => {
    if (cfg.lockLayout) return;
    const interactive = e?.target?.closest?.("button, a, input, textarea, select, label");
    if (interactive) return;
    if ((e.pointerType || "mouse") === "mouse" && e.button !== 0) return;

    dragging = true;
    hdr.setPointerCapture?.(e.pointerId);
    startX = e.clientX;
    startY = e.clientY;

    const rect = panelEl.getBoundingClientRect();
    startLeft = rect.left;
    startTop = rect.top;

    e.preventDefault?.();
  });

  hdr.addEventListener("pointermove", (e) => {
    if (!dragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    const left = Math.max(0, startLeft + dx);
    const top = Math.max(0, startTop + dy);

    panelEl.style.left = `${left}px`;
    panelEl.style.top = `${top}px`;
    panelEl.style.right = "";
    panelEl.style.bottom = "";
  });

  hdr.addEventListener("pointerup", () => {
    if (!dragging) return;
    dragging = false;
    const rect = panelEl.getBoundingClientRect();
    cfg.panelPos[key] = { ...cfg.panelPos[key], x: Math.round(rect.left), y: Math.round(rect.top) };
    cfgSaveFn(cfg);
  });
}

function buildAuxHtml() {
  // AUX: sin cabin grid (rendimiento). Incluye retícula calibrable + perspectiva (pitch/yaw) sobre el vídeo.
  return `<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Galaxy AUX</title>
  <style>
    :root{
      --pitch: 22.5deg;
      --yaw: -22.5deg;
      --sceneOpacity: 1.0;

      --retX: 50%;
      --retY: 50%;
      --retS: 42px;
      --retEnabled: 1;
      --refEnabled: 0;
    }
    html,body{ margin:0; width:100%; height:100%; background:#000; overflow:hidden; }
    #wrap{ position:fixed; inset:0; }

    #vid{
      position:absolute; inset:-10%;
      width:120%; height:120%;
      object-fit:cover;
      opacity: var(--sceneOpacity);
      transform: perspective(1200px) rotateX(var(--pitch)) rotateY(var(--yaw));
      transform-origin: 50% 60%;
      will-change: transform;
      background:#000;
    }

    #reticle{
      position:fixed;
      left: var(--retX);
      top: var(--retY);
      width: var(--retS);
      height: var(--retS);
      transform: translate(-50%, -50%);
      pointer-events:none;
      opacity: calc(0.95 * var(--retEnabled));
      filter: drop-shadow(0 0 6px rgba(0,255,204,0.10));
    }
    #reticle .h{ position:absolute; left:0; top:50%; width:100%; border-top:1px solid rgba(0,255,204,0.80); }
    #reticle .v{ position:absolute; top:0; left:50%; height:100%; border-left:1px solid rgba(0,255,204,0.80); }
    #reticle .dot{ position:absolute; left:50%; top:50%; width:4px; height:4px; transform:translate(-50%,-50%); background:rgba(0,255,204,0.90); border-radius:50%; }

    #ref{
      position:fixed;
      left: 50%; top: 50%;
      width: 22px; height: 22px;
      transform: translate(-50%,-50%);
      pointer-events:none;
      opacity: calc(0.35 * var(--refEnabled));
      filter: drop-shadow(0 0 6px rgba(0,255,204,0.10));
    }
    #ref .h{ position:absolute; left:0; top:50%; width:100%; border-top:1px solid rgba(0,255,204,0.55); }
    #ref .v{ position:absolute; top:0; left:50%; height:100%; border-left:1px solid rgba(0,255,204,0.55); }

    #panel{
      position:absolute; right:12px; top:12px;
      width: 340px;
      font-family: system-ui, -apple-system, Segoe UI, Arial;
      color: rgba(210,255,245,0.95);
      background: rgba(0,0,0,0.40);
      border: 1px solid rgba(0,255,204,0.22);
      border-radius: 12px;
      backdrop-filter: blur(6px);
      box-shadow: 0 0 0 1px rgba(0,0,0,0.35) inset;
      padding: 10px 12px 12px 12px;
      user-select:none;
    }
    .row{ display:flex; align-items:center; justify-content:space-between; gap:10px; margin:6px 0; }
    .k{ color: rgba(0,255,204,0.9); font-weight:600; font-size:12px; }
    .v{ color: rgba(225,255,250,0.95); font-size:12px; min-width:70px; text-align:right; }
    input[type="range"]{ width: 190px; }
    .btn{
      font: 12px/1 system-ui, -apple-system, Segoe UI, Arial;
      color: rgba(210,255,245,0.95);
      background: rgba(0,0,0,0.40);
      border: 1px solid rgba(0,255,204,0.22);
      border-radius: 10px;
      padding: 6px 10px;
      cursor:pointer;
    }
    .btn:hover{ border-color: rgba(0,255,204,0.45); background: rgba(0,0,0,0.55); }
    .muted{ opacity:0.75; font-size:11px; margin-top:6px; }
    #hint{
      position:absolute; left:12px; bottom:10px;
      font: 12px/1.2 system-ui, -apple-system, Segoe UI, Arial;
      color: rgba(180,255,240,0.80);
      text-shadow: 0 0 10px rgba(0,255,204,0.18);
      opacity:0.75;
      user-select:none;
    }
    label{ display:flex; gap:8px; align-items:center; font-size:12px; }
    input[type="checkbox"]{ accent-color: rgba(0,255,204,0.85); }
  </style>
</head>
<body>
  <div id="wrap">
    <video id="vid" autoplay muted playsinline></video>

    <div id="reticle"><div class="h"></div><div class="v"></div><div class="dot"></div></div>
    <div id="ref"><div class="h"></div><div class="v"></div></div>

    <div id="panel">
      <div class="row">
        <div class="k" id="role">AUX</div>
        <div style="display:flex; gap:6px;">
          <button class="btn" id="btnCollapse">⤡</button>
          <button class="btn" id="btnClose">✕</button>
        </div>
      </div>

      <div id="controls">
        <div class="row"><div class="k">PITCH</div><input id="pitch" type="range" min="0" max="45" step="0.5"/><div class="v" id="vp">—</div></div>
        <div class="row"><div class="k">YAW</div><input id="yaw" type="range" min="-45" max="45" step="0.5"/><div class="v" id="vy">—</div></div>
        <div class="row"><div class="k">SCENE</div><input id="sceneOp" type="range" min="0" max="1" step="0.02"/><div class="v" id="vs">—</div></div>

        <div class="row"><div class="k">RET X</div><input id="retX" type="range" min="0" max="100" step="1"/><div class="v" id="vx">—</div></div>
        <div class="row"><div class="k">RET Y</div><input id="retY" type="range" min="0" max="100" step="1"/><div class="v" id="vy2">—</div></div>
        <div class="row"><div class="k">RET S</div><input id="retS" type="range" min="18" max="90" step="1"/><div class="v" id="vs2">—</div></div>

        <div class="row" style="justify-content:flex-start; gap:14px;">
          <label><input id="retOn" type="checkbox"/> Reticle</label>
          <label><input id="refOn" type="checkbox"/> Ref</label>
        </div>

        <div class="muted">
          Si el vídeo sale negro: popup bloqueada o canvas "tainted" por CORS.
        </div>
      </div>
    </div>

    <div id="hint">AUX · Arrastra esta ventana al monitor deseado si Chrome no la “salta” automáticamente.</div>
  </div>

  <script>
    const role = (location.hash.slice(1) || "aux").replace("#","");
    document.getElementById("role").textContent = role.toUpperCase();

    const KEY = "eliteHud_aux_cfg_v3_" + role;
    const def = {
      pitch: 22.5,
      yaw: (role.includes("left") ? 22.5 : (role.includes("right") ? -22.5 : -22.5)),
      sceneOp: 1.0,
      retX: 50,
      retY: 50,
      retS: 42,
      retOn: true,
      refOn: false,
    };

    let cfg = def;
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) cfg = Object.assign({}, def, JSON.parse(raw));
    } catch(e){}

    const $ = (id)=>document.getElementById(id);

    const pitch = $("pitch"), yaw = $("yaw"), sceneOp = $("sceneOp");
    const retX = $("retX"), retY = $("retY"), retS = $("retS");
    const retOn = $("retOn"), refOn = $("refOn");

    const vp = $("vp"), vy = $("vy"), vs = $("vs");
    const vx = $("vx"), vy2 = $("vy2"), vs2 = $("vs2");

    const btnClose = $("btnClose"), btnCollapse = $("btnCollapse");
    const controls = $("controls");
    let collapsed = false;

    function apply(){
      document.documentElement.style.setProperty("--pitch", cfg.pitch + "deg");
      document.documentElement.style.setProperty("--yaw", cfg.yaw + "deg");
      document.documentElement.style.setProperty("--sceneOpacity", String(cfg.sceneOp));

      document.documentElement.style.setProperty("--retX", cfg.retX + "%");
      document.documentElement.style.setProperty("--retY", cfg.retY + "%");
      document.documentElement.style.setProperty("--retS", cfg.retS + "px");
      document.documentElement.style.setProperty("--retEnabled", cfg.retOn ? "1" : "0");
      document.documentElement.style.setProperty("--refEnabled", cfg.refOn ? "1" : "0");

      pitch.value = cfg.pitch; yaw.value = cfg.yaw; sceneOp.value = cfg.sceneOp;
      retX.value = cfg.retX; retY.value = cfg.retY; retS.value = cfg.retS;
      retOn.checked = !!cfg.retOn; refOn.checked = !!cfg.refOn;

      vp.textContent = cfg.pitch.toFixed(1)+"°";
      vy.textContent = cfg.yaw.toFixed(1)+"°";
      vs.textContent = cfg.sceneOp.toFixed(2);

      vx.textContent = cfg.retX.toFixed(0)+"%";
      vy2.textContent = cfg.retY.toFixed(0)+"%";
      vs2.textContent = cfg.retS.toFixed(0)+"px";

      try{ localStorage.setItem(KEY, JSON.stringify(cfg)); }catch(e){}
    }

    pitch.addEventListener("input", ()=>{ cfg.pitch = parseFloat(pitch.value); apply(); });
    yaw.addEventListener("input", ()=>{ cfg.yaw = parseFloat(yaw.value); apply(); });
    sceneOp.addEventListener("input", ()=>{ cfg.sceneOp = parseFloat(sceneOp.value); apply(); });

    retX.addEventListener("input", ()=>{ cfg.retX = parseFloat(retX.value); apply(); });
    retY.addEventListener("input", ()=>{ cfg.retY = parseFloat(retY.value); apply(); });
    retS.addEventListener("input", ()=>{ cfg.retS = parseFloat(retS.value); apply(); });

    retOn.addEventListener("change", ()=>{ cfg.retOn = !!retOn.checked; apply(); });
    refOn.addEventListener("change", ()=>{ cfg.refOn = !!refOn.checked; apply(); });

    btnClose.addEventListener("click", ()=>window.close());
    btnCollapse.addEventListener("click", ()=>{
      collapsed = !collapsed;
      controls.style.display = collapsed ? "none" : "block";
      btnCollapse.textContent = collapsed ? "⤢" : "⤡";
    });

    window.addEventListener("message", (ev)=>{
      const d = ev?.data;
      if (!d || d.type !== "eliteHud:set") return;
      if (d.role && d.role !== role) return;
      if (d.cfg && typeof d.cfg === "object"){
        cfg = Object.assign({}, cfg, d.cfg);
        apply();
      }
    });

    apply();
  </script>
</body>
</html>`;
}

export function createEliteHud({
  camera,
  engine,
  floating,
  labelsApi,
  gridController,
  camCtrl,
  mountId = "eliteHudMount",
} = {}) {
  if (typeof document === "undefined") {
    return {
      update() {},
      setVisible() {},
      openAuxLeft() {},
      openAuxRight() {},
      closeAuxAll() {},
    };
  }

  camCtrl = camCtrl || window.__camCtrl || null;

  makeStylesOnce();
  const cfg = loadMainCfg();

  const mount = document.getElementById(mountId) || document.body;
  try { document.getElementById("eliteHudRoot")?.remove(); } catch (_) {}

  const root = document.createElement("div");
  root.id = "eliteHudRoot";
  if (!cfg.visible) root.classList.add("eliteHidden");

  const reticle = document.createElement("div");
  reticle.id = "eliteReticle";
  reticle.innerHTML = `<div class="h"></div><div class="v"></div><div class="dot"></div>`;
  root.appendChild(reticle);

  const refCenter = document.createElement("div");
  refCenter.id = "eliteRefCenter";
  refCenter.innerHTML = `<div class="h"></div><div class="v"></div>`;
  root.appendChild(refCenter);

  const hint = document.createElement("div");
  hint.id = "eliteHudHint";
  hint.textContent = "C · HUD | M · Ratón | K · Nave | 0-9 · Velocidad | AUX L/R · Reticle calibrable";
  root.appendChild(hint);

  const nav = document.createElement("div");
  nav.className = "elitePanel";
  nav.dataset.pid = "nav";
  nav.style.width = "480px";
  nav.innerHTML = `
    <div class="eliteHdr">
      <div>
        <div class="title">NAV / STATUS</div>
        <div class="eliteMuted" style="font-size:11px;">Floating Origin <span id="eh_th"></span></div>
      </div>
      <div style="display:flex; gap:8px; align-items:center;">
        <button class="eliteBtn" id="eh_btnAuxL" title="Abrir/Cerrar AUX izquierda">AUX L</button>
        <button class="eliteBtn" id="eh_btnAuxR" title="Abrir/Cerrar AUX derecha">AUX R</button>
        <button class="eliteBtn" id="eh_btnFullscreen" title="Pantalla completa">⛶</button>
      </div>
    </div>
    <div class="eliteBody">
      <div class="eliteCol">
        <div class="eliteRow"><span class="eliteK">ABS</span><span class="eliteV" id="eh_abs">—</span></div>
        <div class="eliteRow"><span class="eliteK">CAM</span><span class="eliteV" id="eh_cam">—</span></div>
        <div class="eliteRow"><span class="eliteK">OFF</span><span class="eliteV" id="eh_off">—</span></div>

        <div class="eliteRow" style="margin-top:6px; gap:14px;">
          <label class="eliteSwitch"><input id="eh_toggleNames" type="checkbox" checked> <span>Names</span></label>
          <label class="eliteSwitch"><input id="eh_toggleGridWorld" type="checkbox" checked> <span>Grid</span></label>
        </div>

        <div class="eliteAdv ${cfg.advOpen ? "open" : ""}" id="eh_advBox">
          <div class="eliteMuted" style="margin:4px 0 10px 0; font-size:11px;">
            Reticle calibration (MAIN)
          </div>

          <div class="eliteRow" style="align-items:center;">
            <span class="eliteK">RET X</span>
            <input class="eliteSlider" id="eh_slRetX" type="range" min="0" max="100" step="1" />
            <span class="eliteMiniVal eliteV" id="eh_vRetX"></span>
          </div>

          <div class="eliteRow" style="align-items:center; margin-top:6px;">
            <span class="eliteK">RET Y</span>
            <input class="eliteSlider" id="eh_slRetY" type="range" min="0" max="100" step="1" />
            <span class="eliteMiniVal eliteV" id="eh_vRetY"></span>
          </div>

          <div class="eliteRow" style="align-items:center; margin-top:6px;">
            <span class="eliteK">RET S</span>
            <input class="eliteSlider" id="eh_slRetS" type="range" min="18" max="90" step="1" />
            <span class="eliteMiniVal eliteV" id="eh_vRetS"></span>
          </div>

          <div class="eliteRow" style="margin-top:8px; gap:14px;">
            <label class="eliteSwitch"><input id="eh_chkRetOn" type="checkbox"> <span>Reticle</span></label>
            <label class="eliteSwitch"><input id="eh_chkRefOn" type="checkbox"> <span>Ref</span></label>
            <label class="eliteSwitch"><input id="eh_chkLock" type="checkbox"> <span>LOCK</span></label>
          </div>

          <div class="eliteRow" style="margin-top:8px; gap:10px;">
            <button class="eliteBtn" id="eh_btnToggleAdv">CALIB</button>
            <button class="eliteBtn" id="eh_btnPreset1">1 MON</button>
            <button class="eliteBtn" id="eh_btnPreset2L">2 MON (AUX L)</button>
            <button class="eliteBtn" id="eh_btnPreset2R">2 MON (AUX R)</button>
            <button class="eliteBtn" id="eh_btnResetLayout" title="Reset posiciones">RESET</button>
          </div>

          <div class="eliteMuted" style="margin-top:8px; font-size:11px;">
            Presets mueven la retícula a bordes (para centrar entre 2 pantallas).
          </div>
        </div>
      </div>
    </div>
  `;

  const flight = document.createElement("div");
  flight.className = "elitePanel";
  flight.dataset.pid = "flight";
  flight.style.width = "420px";
  flight.innerHTML = `
    <div class="eliteHdr">
      <div class="title">FLIGHT</div>
      <div style="display:flex; gap:8px; align-items:center;">
        <button class="eliteBtn" id="eh_btnHudToggle" title="HUD (C)">C</button>
      </div>
    </div>
    <div class="eliteBody">
      <div class="eliteRow" style="justify-content:space-between;">
        <div class="eliteRow" style="gap:8px;">
          <button class="eliteBtn" id="eh_btnModeMouse">M · Ratón</button>
          <button class="eliteBtn" id="eh_btnModeShip">K · Nave</button>
        </div>
        <div class="eliteRow" style="gap:8px;">
          <span class="eliteK">SPD</span>
          <span class="eliteV" id="eh_hudSpeed">0</span>
        </div>
      </div>
      <div class="eliteSeg" id="eh_speedSeg" style="margin-top:8px;"></div>
      <div class="eliteMuted" style="margin-top:10px; font-size:11px;">
        AUX muestra la escena (stream). El control de vuelo sigue en MAIN.
      </div>
    </div>
  `;

  const notes = document.createElement("div");
  notes.className = "elitePanel";
  notes.dataset.pid = "notes";
  notes.style.width = "460px";
  notes.innerHTML = `
    <div class="eliteHdr">
      <div class="title">COMMS / NOTES</div>
      <div class="eliteMuted" style="font-size:11px;">(No captura teclas de vuelo)</div>
    </div>
    <div class="eliteBody">
      <textarea class="eliteNotes" id="eh_hudNotes" placeholder="Notas…"></textarea>
    </div>
  `;

  root.appendChild(nav);
  root.appendChild(flight);
  root.appendChild(notes);
  mount.appendChild(root);

  const pos = cfg.panelPos || {};
  setPanelPos(nav, pos.nav || { x: 14, y: 14 }, { right: null, bottom: null });
  setPanelPos(flight, pos.flight || { x: null, y: 14 }, { right: 14, bottom: null });
  setPanelPos(notes, pos.notes || { x: 14, y: null }, { right: null, bottom: 14 });

  makeDraggable(nav, cfg, saveMainCfg, "nav");
  makeDraggable(flight, cfg, saveMainCfg, "flight");
  makeDraggable(notes, cfg, saveMainCfg, "notes");

  // AUX manager (2 ventanas) + stream compartido
  const aux = {
    stream: null,
    wins: { left: null, right: null },
  };

  function ensureStream() {
    if (aux.stream) return aux.stream;
    const canvas = getMainCanvas(engine);
    if (!canvas || !canvas.captureStream) {
      console.warn("[AUX] No canvas/captureStream disponible.");
      return null;
    }
    try {
      aux.stream = canvas.captureStream(60);
      return aux.stream;
    } catch (e) {
      console.warn("[AUX] captureStream falló (posible CORS/tainted canvas):", e);
      return null;
    }
  }

  function stopStreamIfNoAux() {
    const anyOpen =
      (aux.wins.left && !aux.wins.left.closed) ||
      (aux.wins.right && !aux.wins.right.closed);
    if (anyOpen) return;
    try { aux.stream?.getTracks?.().forEach(t => t.stop()); } catch (_) {}
    aux.stream = null;
  }

  function attachStreamToWin(win) {
    if (!win || win.closed) return;
    const stream = ensureStream();
    if (!stream) return;
    try {
      const v = win.document.getElementById("vid");
      if (v) {
        v.srcObject = stream;
        v.play?.().catch?.(() => {});
      }
    } catch (_) {}
  }

  function openAux(role /* left|right */) {
    const prev = aux.wins[role];
    if (prev && !prev.closed) { prev.focus?.(); return; }

    const w = Math.min(1500, window.screen?.availWidth || 1500);
    const h = Math.min(900, window.screen?.availHeight || 900);

    const left = (window.screenX || 0) + (role === "right" ? (window.outerWidth || 0) + 20 : -w - 20);
    const top = (window.screenY || 0) + 20;
    const features = `popup=1,resizable=1,scrollbars=0,width=${w},height=${h},left=${left},top=${top}`;

    const win = window.open("", "GalaxyAux_" + role, features);
    if (!win) {
      console.warn("[AUX] Popup bloqueada. Permite popups para abrir la pantalla auxiliar.");
      return;
    }

    aux.wins[role] = win;

    try {
      win.document.open();
      win.document.write(buildAuxHtml());
      win.document.close();
      win.location.hash = role;
    } catch (_) {}

    try {
      win.addEventListener("beforeunload", () => {
        aux.wins[role] = null;
        stopStreamIfNoAux();
      });
    } catch (_) {}

    setTimeout(() => attachStreamToWin(win), 0);
  }

  function closeAux(role) {
    const win = aux.wins[role];
    try { if (win && !win.closed) win.close(); } catch (_) {}
    aux.wins[role] = null;
    stopStreamIfNoAux();
  }

  function toggleAux(role) {
    const win = aux.wins[role];
    if (win && !win.closed) closeAux(role);
    else openAux(role);
  }

  function closeAuxAll() {
    closeAux("left");
    closeAux("right");
  }

  function postToAux(role, cfgObj) {
    const win = aux.wins[role];
    if (!win || win.closed) return;
    try { win.postMessage({ type: "eliteHud:set", role, cfg: cfgObj }, "*"); } catch (_) {}
  }

  // Refs
  const btnFs = root.querySelector("#eh_btnFullscreen");
  const btnAuxL = root.querySelector("#eh_btnAuxL");
  const btnAuxR = root.querySelector("#eh_btnAuxR");
  const btnHudToggle = root.querySelector("#eh_btnHudToggle");
  const btnModeMouse = root.querySelector("#eh_btnModeMouse");
  const btnModeShip = root.querySelector("#eh_btnModeShip");
  const speedSeg = root.querySelector("#eh_speedSeg");
  const elSpeed = root.querySelector("#eh_hudSpeed");

  const thEl = root.querySelector("#eh_th");
  const absEl = root.querySelector("#eh_abs");
  const camEl = root.querySelector("#eh_cam");
  const offEl = root.querySelector("#eh_off");

  const toggleNames = root.querySelector("#eh_toggleNames");
  const toggleGridWorld = root.querySelector("#eh_toggleGridWorld");

  const advBox = root.querySelector("#eh_advBox");
  const btnToggleAdv = root.querySelector("#eh_btnToggleAdv");
  const btnResetLayout = root.querySelector("#eh_btnResetLayout");

  const slRetX = root.querySelector("#eh_slRetX");
  const slRetY = root.querySelector("#eh_slRetY");
  const slRetS = root.querySelector("#eh_slRetS");
  const vRetX = root.querySelector("#eh_vRetX");
  const vRetY = root.querySelector("#eh_vRetY");
  const vRetS = root.querySelector("#eh_vRetS");

  const chkRetOn = root.querySelector("#eh_chkRetOn");
  const chkRefOn = root.querySelector("#eh_chkRefOn");
  const chkLock = root.querySelector("#eh_chkLock");

  const btnPreset1 = root.querySelector("#eh_btnPreset1");
  const btnPreset2L = root.querySelector("#eh_btnPreset2L");
  const btnPreset2R = root.querySelector("#eh_btnPreset2R");

  // Speed buttons 0..9
  const speedBtns = [];
  for (let i = 0; i <= 9; i++) {
    const b = document.createElement("button");
    b.className = "eliteBtn";
    b.textContent = String(i);
    b.onclick = () => {
      if (camCtrl?.setSpeedLevel) camCtrl.setSpeedLevel(i);
      else {
        try { window.dispatchEvent(new KeyboardEvent("keydown", { key: String(i), bubbles: true })); } catch (_) {}
      }
    };
    speedSeg.appendChild(b);
    speedBtns.push(b);
  }

  // Notes persist + stopPropagation
  const notesTa = root.querySelector("#eh_hudNotes");
  try {
    const key = "eliteHudNotes_main";
    const saved = localStorage.getItem(key);
    if (saved != null) notesTa.value = saved;
    notesTa.addEventListener("input", () => localStorage.setItem(key, notesTa.value));
    notesTa.addEventListener("keydown", (e) => e.stopPropagation());
    notesTa.addEventListener("keyup", (e) => e.stopPropagation());
  } catch (_) {}

  function applyReticle() {
    const r = cfg.reticle || {};
    const enabled = !!r.enabled;
    const xPct = Math.max(0, Math.min(100, (r.x ?? 0.5) * 100));
    const yPct = Math.max(0, Math.min(100, (r.y ?? 0.5) * 100));
    const s = Math.max(18, Math.min(90, r.sizePx ?? 42));

    root.style.setProperty("--retX", `${xPct}%`);
    root.style.setProperty("--retY", `${yPct}%`);
    root.style.setProperty("--retS", `${s}px`);

    reticle.style.display = enabled ? "block" : "none";
    refCenter.style.display = r.showRefCenter ? "block" : "none";

    if (slRetX) slRetX.value = String(Math.round(xPct));
    if (slRetY) slRetY.value = String(Math.round(yPct));
    if (slRetS) slRetS.value = String(Math.round(s));

    if (vRetX) vRetX.textContent = `${Math.round(xPct)}%`;
    if (vRetY) vRetY.textContent = `${Math.round(yPct)}%`;
    if (vRetS) vRetS.textContent = `${Math.round(s)}px`;

    if (chkRetOn) chkRetOn.checked = enabled;
    if (chkRefOn) chkRefOn.checked = !!r.showRefCenter;
  }

  function syncControls() {
    advBox?.classList.toggle("open", !!cfg.advOpen);
    if (chkLock) chkLock.checked = !!cfg.lockLayout;
    applyReticle();
  }

  btnFs?.addEventListener("click", toggleFullscreen);
  btnAuxL?.addEventListener("click", () => toggleAux("left"));
  btnAuxR?.addEventListener("click", () => toggleAux("right"));
  btnHudToggle?.addEventListener("click", () => setVisible(root.classList.contains("eliteHidden")));

  btnModeMouse?.addEventListener("click", () => {
    if (camCtrl?.setMode) camCtrl.setMode("mouse");
    else { try { window.dispatchEvent(new KeyboardEvent("keydown", { key: "m", bubbles: true })); } catch (_) {} }
  });
  btnModeShip?.addEventListener("click", () => {
    if (camCtrl?.setMode) camCtrl.setMode("ship");
    else { try { window.dispatchEvent(new KeyboardEvent("keydown", { key: "k", bubbles: true })); } catch (_) {} }
  });

  function applyNames() { labelsApi?.setShowLabels?.(!!toggleNames?.checked); }
  function applyGridWorld() { gridController?.setEnabled?.(!!toggleGridWorld?.checked); }
  toggleNames?.addEventListener("change", applyNames);
  toggleGridWorld?.addEventListener("change", applyGridWorld);

  btnToggleAdv?.addEventListener("click", () => {
    cfg.advOpen = !cfg.advOpen;
    saveMainCfg(cfg);
    syncControls();
  });

  btnResetLayout?.addEventListener("click", () => {
    const fresh = loadMainCfg();
    cfg.panelPos = fresh.panelPos;
    saveMainCfg(cfg);
    const pos2 = cfg.panelPos || {};
    setPanelPos(nav, pos2.nav || { x: 14, y: 14 }, { right: null, bottom: null });
    setPanelPos(flight, pos2.flight || { x: null, y: 14 }, { right: 14, bottom: null });
    setPanelPos(notes, pos2.notes || { x: 14, y: null }, { right: null, bottom: 14 });
  });

  slRetX?.addEventListener("input", () => {
    cfg.reticle.x = (parseFloat(slRetX.value) / 100);
    saveMainCfg(cfg);
    applyReticle();
  });
  slRetY?.addEventListener("input", () => {
    cfg.reticle.y = (parseFloat(slRetY.value) / 100);
    saveMainCfg(cfg);
    applyReticle();
  });
  slRetS?.addEventListener("input", () => {
    cfg.reticle.sizePx = parseFloat(slRetS.value);
    saveMainCfg(cfg);
    applyReticle();
  });

  chkRetOn?.addEventListener("change", () => {
    cfg.reticle.enabled = !!chkRetOn.checked;
    saveMainCfg(cfg);
    applyReticle();
  });
  chkRefOn?.addEventListener("change", () => {
    cfg.reticle.showRefCenter = !!chkRefOn.checked;
    saveMainCfg(cfg);
    applyReticle();
  });
  chkLock?.addEventListener("change", () => {
    cfg.lockLayout = !!chkLock.checked;
    saveMainCfg(cfg);
  });

  // Presets
  btnPreset1?.addEventListener("click", () => {
    cfg.reticle.x = 0.5; cfg.reticle.y = 0.5;
    saveMainCfg(cfg);
    applyReticle();
    postToAux("left",  { retX: 50, retY: 50 });
    postToAux("right", { retX: 50, retY: 50 });
  });

  btnPreset2L?.addEventListener("click", () => {
    // AUX a la izquierda: centro combinado = unión
    cfg.reticle.x = 0.0;
    saveMainCfg(cfg);
    applyReticle();
    openAux("left");
    postToAux("left", { retX: 100, retY: Math.round((cfg.reticle.y ?? 0.5) * 100), retOn: cfg.reticle.enabled });
  });

  btnPreset2R?.addEventListener("click", () => {
    // AUX a la derecha: centro combinado = unión
    cfg.reticle.x = 1.0;
    saveMainCfg(cfg);
    applyReticle();
    openAux("right");
    postToAux("right", { retX: 0, retY: Math.round((cfg.reticle.y ?? 0.5) * 100), retOn: cfg.reticle.enabled });
  });

  function setVisible(on) {
    cfg.visible = !!on;
    root.classList.toggle("eliteHidden", !cfg.visible);
    saveMainCfg(cfg);
  }

  function onKeyDown(ev) {
    if (shouldIgnoreKey(ev)) return;
    const k = (ev.key || "").toLowerCase();
    if (k === "c") {
      ev.preventDefault?.();
      setVisible(root.classList.contains("eliteHidden"));
    }
  }
  window.addEventListener("keydown", onKeyDown, { passive: false });

  syncControls();
  applyNames();
  applyGridWorld();

  function updateModeSpeedUi() {
    const mode = camCtrl?.getMode?.() || camCtrl?._state?.mode || "";
    const spd = camCtrl?.getSpeedLevel?.() ?? camCtrl?._state?.ship?.speedLevel ?? 0;
    const level = Number.isFinite(spd) ? spd : 0;

    if (elSpeed) elSpeed.textContent = String(level);
    btnModeMouse?.classList.toggle("on", mode === "mouse");
    btnModeShip?.classList.toggle("on", mode === "ship");
    for (let i = 0; i < speedBtns.length; i++) speedBtns[i].classList.toggle("on", i === level);

    btnAuxL?.classList.toggle("on", !!(aux.wins.left && !aux.wins.left.closed));
    btnAuxR?.classList.toggle("on", !!(aux.wins.right && !aux.wins.right.closed));
  }

  function updateHudNumbers() {
    if (!camera) return;
    try {
      const off = floating?.originOffset;
      const absV = floating?.getCameraAbsolute?.() || (off ? camera.position.add(off) : null);
      const th =
        floating?.thresh != null
          ? `${Number(floating.thresh).toLocaleString("es-ES")} (grid ${Number(floating.rebaseGrid).toLocaleString("es-ES")})`
          : "";

      if (thEl) thEl.textContent = th;
      if (absEl) absEl.textContent = absV ? `${absV.x.toFixed(0)}, ${absV.y.toFixed(0)}, ${absV.z.toFixed(0)}` : "—";
      if (camEl) camEl.textContent = `${camera.position.x.toFixed(0)}, ${camera.position.y.toFixed(0)}, ${camera.position.z.toFixed(0)}`;
      if (offEl) offEl.textContent = off ? `${off.x.toFixed(0)}, ${off.y.toFixed(0)}, ${off.z.toFixed(0)}` : "—";
    } catch (_) {}
  }

  function update() {
    updateModeSpeedUi();
    updateHudNumbers();
  }

  try {
    const obs = engine?.onDisposeObservable || camera?.getScene?.()?.onDisposeObservable;
    obs?.add?.(() => {
      window.removeEventListener("keydown", onKeyDown);
      closeAuxAll();
    });
  } catch (_) {}

  return {
    update,
    setVisible,
    openAuxLeft: () => openAux("left"),
    openAuxRight: () => openAux("right"),
    closeAuxAll,
    root,
  };
}
