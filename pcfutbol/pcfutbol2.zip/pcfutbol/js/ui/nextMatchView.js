// js/ui/nextMatchView.js
// Vista 3/3 de Competición: PRÓXIMO PARTIDO (previa + postpartido)

import { GameState } from '../state.js';
import { getGameDateFor, formatGameDateLabel } from './utils/calendar.js';
import { createCoatImgElement } from './utils/coats.js';

let __bound = false;
let __onOpenMatchDetail = null;
let __lastSimulatedMatchday = null;

function escapeHtml(v) {
  const s = String(v ?? '');
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function stableHash(str) {
  const s = String(str || '');
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function stableRand01(seedStr) {
  const h = stableHash(seedStr);
  // LCG
  let x = (h + 1013904223) >>> 0;
  x = (Math.imul(1664525, x) + 1013904223) >>> 0;
  return (x >>> 0) / 4294967295;
}

function getUserClub() {
  const id = GameState.user?.clubId || null;
  const clubs = Array.isArray(GameState.clubs) ? GameState.clubs : [];
  return (id ? clubs.find((c) => String(c?.id) === String(id)) : null) || clubs[0] || null;
}

function buildClubIndex() {
  const map = new Map();
  (GameState.clubs || []).forEach((c) => {
    if (c?.id) map.set(c.id, c);
  });
  return map;
}

function getClubName(club, fallbackId) {
  return (club && (club.shortName || club.name)) || fallbackId || '';
}

function getKickoffTime(fx, idx = 0) {
  const t = fx?.kickoffTime;
  if (typeof t === 'string' && t.includes(':')) return t;
  const slots = ['16:00', '18:15', '20:30', '22:00'];
  return slots[Math.max(0, idx) % slots.length];
}

function pickBestXI(club) {
  const players = Array.isArray(club?.players) ? club.players : [];
  const available = players.filter(Boolean).slice().sort((a, b) => Number(b?.overall || 0) - Number(a?.overall || 0));
  const xi = [];
  const gk = available.find((p) => String(p?.position || '').toUpperCase() === 'GK');
  if (gk) xi.push(gk);
  for (let i = 0; i < available.length && xi.length < 11; i++) {
    if (!xi.includes(available[i])) xi.push(available[i]);
  }
  return xi.slice(0, 11);
}

function getPreLineup(club) {
  // 1) si la alineación está definida por el usuario
  const ids = Array.isArray(club?.lineup) ? club.lineup : [];
  const benchIds = Array.isArray(club?.bench) ? club.bench : [];
  const byId = new Map((club?.players || []).map((p) => [p?.id, p]));
  const xi = ids.map((id) => byId.get(id)).filter(Boolean);
  const bench = benchIds.map((id) => byId.get(id)).filter(Boolean);
  if (xi.length >= 11) return { xi: xi.slice(0, 11), bench };

  // 2) fallback: best XI
  const best = pickBestXI(club);
  const bestIds = new Set(best.map((p) => p.id));
  const rest = (club?.players || []).filter((p) => p && !bestIds.has(p.id)).slice().sort((a, b) => Number(b?.overall || 0) - Number(a?.overall || 0));
  return { xi: best, bench: rest.slice(0, 9) };
}

function estimateAttendance(fx, homeClub, awayClub) {
  const cap = Number(homeClub?.stadium?.capacity || homeClub?.stadiumCapacity || 30000);
  const seed = `${fx?.id || ''}:${homeClub?.id || ''}:${awayClub?.id || ''}:${fx?.matchday || ''}`;
  const r = stableRand01(seed);
  // 62%..98% con ligera variación
  const fill = 0.62 + r * 0.36;
  const att = Math.max(1500, Math.round(cap * fill));
  return { capacity: cap, attendance: Math.min(att, cap) };
}

function renderPlayersList(container, players) {
  if (!container) return;
  container.innerHTML = '';
  const list = Array.isArray(players) ? players : [];
  if (!list.length) {
    container.innerHTML = '<div class="muted">—</div>';
    return;
  }
  list.forEach((p) => {
    const div = document.createElement('div');
    div.className = 'pcf-lineup-item';
    div.innerHTML = `<span class="pcf-lineup-pos">${escapeHtml(String(p?.position || '').toUpperCase())}</span><span class="pcf-lineup-name">${escapeHtml(p?.name || 'Jugador')}</span><span class="muted">${escapeHtml(p?.overall ?? '')}</span>`;
    container.appendChild(div);
  });
}

function renderTeamStatsBlocks(root, teamStats) {
  if (!root) return;
  const h = teamStats?.home || null;
  const a = teamStats?.away || null;

  const mk = (title, rows) => {
    const wrap = document.createElement('div');
    wrap.className = 'pcf-stats-block';
    const head = document.createElement('div');
    head.className = 'pcf-stats-block__title';
    head.textContent = title;
    wrap.appendChild(head);
    const table = document.createElement('table');
    table.className = 'pcf-stats-table';
    const tb = document.createElement('tbody');
    rows.forEach((r) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="th-num">${escapeHtml(r.home ?? '-') }</td>
        <td class="pcf-stats-label">${escapeHtml(r.label)}</td>
        <td class="th-num">${escapeHtml(r.away ?? '-') }</td>
      `;
      tb.appendChild(tr);
    });
    table.appendChild(tb);
    wrap.appendChild(table);
    return wrap;
  };

  root.innerHTML = '';
  if (!h || !a) {
    root.innerHTML = '<div class="muted">No hay estadísticas avanzadas para este partido.</div>';
    return;
  }

  const key = mk('Estadísticas clave', [
    { label: 'Posesión (%)', home: h.possessionPct, away: a.possessionPct },
    { label: 'Disparos totales', home: h.shotsTotal, away: a.shotsTotal },
    { label: 'Disparos a puerta', home: h.shotsOnTarget, away: a.shotsOnTarget },
    { label: 'Saques de esquina', home: h.corners, away: a.corners },
    { label: 'Precisión en el pase (%)', home: h.passAccuracyPct, away: a.passAccuracyPct },
    { label: 'Pases completados', home: h.passesCompleted, away: a.passesCompleted },
    { label: 'Pases realizados', home: h.passesAttempted, away: a.passesAttempted },
    { label: 'Balones recuperados', home: h.recoveries, away: a.recoveries },
    { label: 'Fueras de juego', home: h.offsides, away: a.offsides },
    { label: 'Paradas', home: h.saves, away: a.saves },
    { label: 'Distancia recorrida (km)', home: h.distanceKm, away: a.distanceKm },
    { label: 'Tarjetas amarillas', home: h.yellowCards, away: a.yellowCards },
    { label: 'Tarjetas rojas', home: h.redCards, away: a.redCards },
  ]);

  const atk = mk('Ataque', [
    { label: 'Goles', home: h.goals, away: a.goals },
    { label: 'Goles dentro del área', home: h.goalsInBox, away: a.goalsInBox },
    { label: 'Goles fuera del área', home: h.goalsOutBox, away: a.goalsOutBox },
    { label: 'Disparos fuera', home: h.shotsOffTarget, away: a.shotsOffTarget },
    { label: 'Disparos bloqueados', home: h.shotsBlocked, away: a.shotsBlocked },
    { label: 'Ocasiones claras', home: h.bigChances, away: a.bigChances },
    { label: 'Regates', home: h.dribbles, away: a.dribbles },
    { label: 'Ataques', home: h.attacks, away: a.attacks },
    { label: 'Ataques en el tercio ofensivo', home: h.attacksFinalThird, away: a.attacksFinalThird },
    { label: 'Ataques en zonas clave', home: h.attacksDangerZone, away: a.attacksDangerZone },
    { label: 'Carreras hacia el área', home: h.runsIntoBox, away: a.runsIntoBox },
  ]);

  const dist = mk('Distribución', [
    { label: 'Precisión en el pase (%)', home: h.passAccuracyPct, away: a.passAccuracyPct },
    { label: 'Pases en corto completados', home: h.shortPassesCompleted, away: a.shortPassesCompleted },
    { label: 'Pases de media distancia completados', home: h.mediumPassesCompleted, away: a.mediumPassesCompleted },
    { label: 'Pases en largo completados', home: h.longPassesCompleted, away: a.longPassesCompleted },
    { label: 'Centros completados', home: h.crossesCompleted, away: a.crossesCompleted },
    { label: 'Centros realizados', home: h.crossesAttempted, away: a.crossesAttempted },
    { label: 'Pases a zonas clave', home: h.passesToKeyAreas, away: a.passesToKeyAreas },
    { label: 'Pases al área', home: h.passesIntoBox, away: a.passesIntoBox },
    { label: 'Tiempo de posesión', home: h.possessionTime, away: a.possessionTime },
  ]);

  const def = mk('Defensa', [
    { label: 'Balones recuperados', home: h.recoveries, away: a.recoveries },
    { label: 'Duelos', home: h.duels, away: a.duels },
    { label: 'Entradas con éxito', home: h.tacklesWon, away: a.tacklesWon },
    { label: 'Entradas perdidas', home: h.tacklesLost, away: a.tacklesLost },
    { label: 'Despejes completados', home: h.clearancesCompleted, away: a.clearancesCompleted },
    { label: 'Despejes realizados', home: h.clearancesAttempted, away: a.clearancesAttempted },
    { label: 'Faltas cometidas', home: h.foulsCommitted, away: a.foulsCommitted },
  ]);

  root.appendChild(key);
  root.appendChild(atk);
  root.appendChild(dist);
  root.appendChild(def);
}

function buildTimelineItems(fx, clubIndex, playerIndex) {
  const events = Array.isArray(fx?.events) ? fx.events.slice() : [];
  // Inyectamos sustituciones como eventos (si no existen)
  const subs = Array.isArray(fx?.substitutions) ? fx.substitutions : [];
  subs.forEach((s) => {
    if (!s) return;
    const min = Number(s.minute || 0) || 0;
    events.push({
      type: 'SUB',
      minute: min,
      clubId: s.clubId,
      inPlayerId: s.inPlayerId,
      outPlayerId: s.outPlayerId,
    });
  });

  events.sort((a, b) => Number(a?.minute || 999) - Number(b?.minute || 999));

  const items = [];
  for (const ev of events) {
    const minute = Number(ev?.minute || 0) || null;
    const club = ev?.clubId ? clubIndex.get(ev.clubId) : null;
    const teamName = club ? (club.shortName || club.name || club.id) : (ev?.clubId || '');

    if (ev.type === 'GOAL') {
      const info = ev.playerId ? playerIndex.get(ev.playerId) : null;
      const scorer = info?.player?.name || 'Jugador';
      const ainfo = ev.assistPlayerId ? playerIndex.get(ev.assistPlayerId) : null;
      const assister = ainfo?.player?.name || '';
      items.push({
        minute,
        text: assister ? `Gol de ${scorer} (${teamName}) · Asistencia: ${assister}` : `Gol de ${scorer} (${teamName})`,
        side: ev.clubId === fx.homeClubId ? 'home' : 'away',
      });
    } else if (ev.type === 'YELLOW_CARD') {
      const info = ev.playerId ? playerIndex.get(ev.playerId) : null;
      const name = info?.player?.name || 'Jugador';
      items.push({ minute, text: `Amarilla a ${name} (${teamName})`, side: ev.clubId === fx.homeClubId ? 'home' : 'away' });
    } else if (ev.type === 'RED_CARD') {
      const info = ev.playerId ? playerIndex.get(ev.playerId) : null;
      const name = info?.player?.name || 'Jugador';
      items.push({ minute, text: `Roja a ${name} (${teamName})`, side: ev.clubId === fx.homeClubId ? 'home' : 'away' });
    } else if (ev.type === 'INJURY') {
      const info = ev.playerId ? playerIndex.get(ev.playerId) : null;
      const name = info?.player?.name || 'Jugador';
      const it = ev.injuryType || 'Lesión';
      items.push({ minute, text: `Lesión: ${name} (${teamName}) – ${it}`, side: ev.clubId === fx.homeClubId ? 'home' : 'away' });
    } else if (ev.type === 'SUB') {
      const inInfo = ev.inPlayerId ? playerIndex.get(ev.inPlayerId) : null;
      const outInfo = ev.outPlayerId ? playerIndex.get(ev.outPlayerId) : null;
      const inName = inInfo?.player?.name || 'Jugador';
      const outName = outInfo?.player?.name || 'Jugador';
      items.push({ minute, text: `${inName} entra por ${outName} (${teamName})`, side: ev.clubId === fx.homeClubId ? 'home' : 'away' });
    }
  }
  return items;
}

function renderTimeline(root, fx) {
  if (!root) return;
  root.innerHTML = '';
  if (!fx) return;

  const clubs = Array.isArray(GameState.clubs) ? GameState.clubs : [];
  const clubIndex = new Map(clubs.map((c) => [c?.id, c]));
  const playerIndex = new Map();
  clubs.forEach((c) => (c.players || []).forEach((p) => p?.id && playerIndex.set(p.id, { player: p, club: c })));

  const items = buildTimelineItems(fx, clubIndex, playerIndex);
  if (!items.length) {
    root.innerHTML = '<div class="muted">No hay cronología para este partido.</div>';
    return;
  }

  const ul = document.createElement('ul');
  ul.className = 'pcf-timeline';

  items.forEach((it) => {
    const li = document.createElement('li');
    li.className = `pcf-timeline__item ${it.side ? `pcf-timeline__item--${it.side}` : ''}`;
    li.innerHTML = `<span class="pcf-timeline__min">${it.minute ? `${escapeHtml(it.minute)}'` : '-'}</span><span class="pcf-timeline__text">${escapeHtml(it.text)}</span>`;
    ul.appendChild(li);
  });

  root.appendChild(ul);
}

function renderPlayerMatchStatsTable(root, fx, clubId) {
  if (!root) return;
  root.innerHTML = '';
  if (!fx) return;
  const byId = fx?.playerStatsById && typeof fx.playerStatsById === 'object' ? fx.playerStatsById : null;
  if (!byId) {
    root.innerHTML = '<div class="muted">No hay estadísticas de jugadores para este partido.</div>';
    return;
  }

  const clubs = Array.isArray(GameState.clubs) ? GameState.clubs : [];
  const club = clubs.find((c) => String(c?.id) === String(clubId)) || null;
  const playerMap = new Map((club?.players || []).map((p) => [p?.id, p]));

  const rows = Object.keys(byId)
    .map((pid) => ({ pid, s: byId[pid] }))
    .filter((r) => String(r.s?.clubId) === String(clubId))
    .sort((a, b) => Number(b.s?.minutes || 0) - Number(a.s?.minutes || 0));

  if (!rows.length) {
    root.innerHTML = '<div class="muted">No hay jugadores con stats en este partido.</div>';
    return;
  }

  const table = document.createElement('table');
  table.className = 'table table-standings table-stats pcf-player-match-stats';
  table.innerHTML = `
    <thead>
      <tr>
        <th>Jugador</th>
        <th class="th-num">Min</th>
        <th class="th-num">G</th>
        <th class="th-num">A</th>
        <th class="th-num">Tir</th>
        <th class="th-num">Pases</th>
        <th class="th-num">%P</th>
        <th class="th-num">Rec</th>
        <th class="th-num">Dist</th>
        <th class="th-num">Vel</th>
        <th class="th-num">TA</th>
        <th class="th-num">TR</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  const tb = table.querySelector('tbody');

  rows.forEach(({ pid, s }) => {
    const p = playerMap.get(pid) || null;
    const name = p?.name || s?.playerName || pid;
    const passes = `${Number(s.passesCompleted || 0)}/${Number(s.passesAttempted || 0)}`;
    const passPct = s.passAccuracyPct != null ? `${Number(s.passAccuracyPct).toFixed(2)}` : '-';
    const dist = s.distanceKm != null ? Number(s.distanceKm).toFixed(2) : '-';
    const spd = s.maxSpeedKmh != null ? Number(s.maxSpeedKmh).toFixed(1) : '-';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${escapeHtml(name)}</td>
      <td class="th-num">${Number(s.minutes || 0)}</td>
      <td class="th-num"><strong>${Number(s.goals || 0)}</strong></td>
      <td class="th-num">${Number(s.assists || 0)}</td>
      <td class="th-num">${Number(s.shotsOnTarget || 0)}/${Number(s.shotsTotal || 0)}</td>
      <td class="th-num">${escapeHtml(passes)}</td>
      <td class="th-num">${escapeHtml(passPct)}</td>
      <td class="th-num">${Number(s.recoveries || 0)}</td>
      <td class="th-num">${escapeHtml(dist)}</td>
      <td class="th-num">${escapeHtml(spd)}</td>
      <td class="th-num">${Number(s.yellowCards || 0)}</td>
      <td class="th-num">${Number(s.redCards || 0)}</td>
    `;
    tb.appendChild(tr);
  });

  root.appendChild(table);
}

function ensureBindings() {
  if (__bound) return;
  const btnDetailLast = document.getElementById('nextmatch-open-last-detail');
  const btnDetailNext = document.getElementById('nextmatch-open-next-detail');
  if (btnDetailLast) {
    btnDetailLast.addEventListener('click', () => {
      const fid = btnDetailLast.getAttribute('data-fixture-id');
      if (fid && typeof __onOpenMatchDetail === 'function') {
        __onOpenMatchDetail({ competitionId: GameState.league?.id || 'current', fixtureId: fid });
      }
    });
  }
  if (btnDetailNext) {
    btnDetailNext.addEventListener('click', () => {
      const fid = btnDetailNext.getAttribute('data-fixture-id');
      if (fid && typeof __onOpenMatchDetail === 'function') {
        __onOpenMatchDetail({ competitionId: GameState.league?.id || 'current', fixtureId: fid });
      }
    });
  }
  __bound = true;
}

export function initNextMatchUI({ onOpenMatchDetail } = {}) {
  __onOpenMatchDetail = typeof onOpenMatchDetail === 'function' ? onOpenMatchDetail : null;
}

export function setLastSimulatedMatchday(md) {
  const n = Number(md);
  if (Number.isFinite(n) && n >= 1) __lastSimulatedMatchday = n;
}

export function updateNextMatchView() {
  ensureBindings();

  const userClub = getUserClub();
  const clubIndex = buildClubIndex();
  const fixtures = Array.isArray(GameState.fixtures) ? GameState.fixtures : [];
  const season = Number(GameState.currentDate?.season || 1);
  const currentMd = Number(GameState.currentDate?.matchday || 1);
  const userId = userClub?.id || null;

  const preWrap = document.getElementById('nextmatch-pre');
  const postWrap = document.getElementById('nextmatch-post');

  const nextTitle = document.getElementById('nextmatch-next-title');
  const nextMeta = document.getElementById('nextmatch-next-meta');
  const nextStadium = document.getElementById('nextmatch-next-stadium');
  const nextAttendance = document.getElementById('nextmatch-next-attendance');
  const nextXI = document.getElementById('nextmatch-next-xi');
  const nextBench = document.getElementById('nextmatch-next-bench');
  const nextOppXI = document.getElementById('nextmatch-next-opp-xi');
  const nextOppBench = document.getElementById('nextmatch-next-opp-bench');
  const btnDetailNext = document.getElementById('nextmatch-open-next-detail');

  const lastTitle = document.getElementById('nextmatch-last-title');
  const lastMeta = document.getElementById('nextmatch-last-meta');
  const lastStats = document.getElementById('nextmatch-last-stats');
  const lastTimeline = document.getElementById('nextmatch-last-timeline');
  const lastPlayers = document.getElementById('nextmatch-last-players');
  const btnDetailLast = document.getElementById('nextmatch-open-last-detail');

  if (!userClub || !userId) {
    if (preWrap) preWrap.innerHTML = '<div class="muted">No hay club de usuario.</div>';
    if (postWrap) postWrap.innerHTML = '';
    return;
  }

  // ----------------
  // Próximo partido
  // ----------------
  const nextFx = fixtures
    .filter((fx) => fx && !fx.played && (fx.homeClubId === userId || fx.awayClubId === userId))
    .slice()
    .sort((a, b) => Number(a.matchday || 0) - Number(b.matchday || 0))[0] || null;

  if (!nextFx) {
    if (nextTitle) nextTitle.textContent = 'No hay próximo partido.';
    if (nextMeta) nextMeta.textContent = '';
    if (nextStadium) nextStadium.textContent = '';
    if (nextAttendance) nextAttendance.textContent = '';
    renderPlayersList(nextXI, []);
    renderPlayersList(nextBench, []);
    renderPlayersList(nextOppXI, []);
    renderPlayersList(nextOppBench, []);
    if (btnDetailNext) btnDetailNext.setAttribute('data-fixture-id', '');
  } else {
    const home = clubIndex.get(nextFx.homeClubId);
    const away = clubIndex.get(nextFx.awayClubId);
    const homeName = getClubName(home, nextFx.homeClubId);
    const awayName = getClubName(away, nextFx.awayClubId);
    const date = getGameDateFor(season, Number(nextFx.matchday || currentMd));
    const dateLabel = formatGameDateLabel(date);
    const time = getKickoffTime(nextFx, 0);

    const coatH = createCoatImgElement(nextFx.homeClubId, homeName, 22);
    const coatA = createCoatImgElement(nextFx.awayClubId, awayName, 22);

    if (nextTitle) {
      nextTitle.innerHTML = `${coatH.outerHTML}<span>${escapeHtml(homeName)}</span><span class="pcf-vs">vs</span>${coatA.outerHTML}<span>${escapeHtml(awayName)}</span>`;
    }
    if (nextMeta) {
      nextMeta.textContent = `Jornada ${nextFx.matchday} • ${dateLabel} • ${time}`;
    }

    const homeStadiumName = home?.stadium?.name || home?.stadiumName || 'Estadio';
    const { capacity, attendance } = nextFx?.meta?.attendance != null
      ? { capacity: Number(nextFx.meta.capacity || home?.stadium?.capacity || 30000), attendance: Number(nextFx.meta.attendance || 0) }
      : estimateAttendance(nextFx, home, away);

    if (nextStadium) nextStadium.textContent = `${homeStadiumName} (Aforo: ${capacity.toLocaleString('es-ES')})`;
    if (nextAttendance) nextAttendance.textContent = `Espectadores: ${attendance.toLocaleString('es-ES')}`;

    const userSide = String(userId) === String(nextFx.homeClubId) ? 'home' : 'away';
    const myClub = userSide === 'home' ? home : away;
    const oppClub = userSide === 'home' ? away : home;

    const myL = getPreLineup(myClub);
    const oppL = getPreLineup(oppClub);

    renderPlayersList(nextXI, myL.xi);
    renderPlayersList(nextBench, myL.bench);
    renderPlayersList(nextOppXI, oppL.xi);
    renderPlayersList(nextOppBench, oppL.bench);

    if (btnDetailNext) btnDetailNext.setAttribute('data-fixture-id', String(nextFx.id));
  }

  // ----------------
  // Partido recién simulado (post)
  // ----------------
  let lastFx = null;
  const mdTarget = Number(__lastSimulatedMatchday || 0);
  if (mdTarget >= 1) {
    lastFx = fixtures.find((fx) => fx && fx.played && Number(fx.matchday) === mdTarget && (fx.homeClubId === userId || fx.awayClubId === userId)) || null;
  }
  if (!lastFx) {
    // fallback: último jugado del usuario
    lastFx = fixtures
      .filter((fx) => fx && fx.played && (fx.homeClubId === userId || fx.awayClubId === userId))
      .slice()
      .sort((a, b) => Number(b.matchday || 0) - Number(a.matchday || 0))[0] || null;
  }

  if (!lastFx) {
    if (lastTitle) lastTitle.textContent = 'Aún no has jugado ningún partido.';
    if (lastMeta) lastMeta.textContent = '';
    if (btnDetailLast) btnDetailLast.setAttribute('data-fixture-id', '');
    renderTeamStatsBlocks(lastStats, null);
    if (lastTimeline) lastTimeline.innerHTML = '';
    if (lastPlayers) lastPlayers.innerHTML = '';
    return;
  }

  const home = clubIndex.get(lastFx.homeClubId);
  const away = clubIndex.get(lastFx.awayClubId);
  const homeName = getClubName(home, lastFx.homeClubId);
  const awayName = getClubName(away, lastFx.awayClubId);
  const coatH = createCoatImgElement(lastFx.homeClubId, homeName, 22);
  const coatA = createCoatImgElement(lastFx.awayClubId, awayName, 22);
  if (lastTitle) {
    lastTitle.innerHTML = `${coatH.outerHTML}<span>${escapeHtml(homeName)}</span> <strong>${Number(lastFx.homeGoals || 0)} - ${Number(lastFx.awayGoals || 0)}</strong> ${coatA.outerHTML}<span>${escapeHtml(awayName)}</span>`;
  }
  if (lastMeta) {
    const date = getGameDateFor(season, Number(lastFx.matchday || currentMd));
    lastMeta.textContent = `Jornada ${lastFx.matchday} • ${formatGameDateLabel(date)}`;
  }

  if (btnDetailLast) btnDetailLast.setAttribute('data-fixture-id', String(lastFx.id));

  renderTeamStatsBlocks(lastStats, lastFx.teamStats);
  renderTimeline(lastTimeline, lastFx);
  renderPlayerMatchStatsTable(lastPlayers, lastFx, userId);
}