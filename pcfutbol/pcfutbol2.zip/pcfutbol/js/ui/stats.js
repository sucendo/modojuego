// js/ui/stats.js
// Vista "Estadísticas" (tabla avanzada por partido) – solo del club del usuario.

import { GameState } from '../state.js';
import {
  getCompetitions,
  getCompetitionById,
  getDefaultCompetitionId,
  buildClubIndex,
  getUserClubId,
  findFixtureInCompetition,
} from './utils/competitions.js';
import { getGameDateFor, formatGameDateLabel } from './utils/calendar.js';
import { createCoatImgElement } from './utils/coats.js';
import { openMatchDetailModal } from './modals/matchDetailModal.js';

let __bound = false;
let __selectedCompetitionId = null;
let __expandedFixtureId = null;

function esc(v) {
  return String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function fmtNum(n, decimals = 0) {
  const x = Number(n);
  if (!Number.isFinite(x)) return '—';
  return x.toLocaleString('es-ES', { maximumFractionDigits: decimals, minimumFractionDigits: decimals });
}

function fmtPct(n) {
  const x = Number(n);
  if (!Number.isFinite(x)) return '—';
  return `${fmtNum(x, 0)}%`;
}

function getComp() {
  const id = __selectedCompetitionId || getDefaultCompetitionId();
  return getCompetitionById(id);
}

function getUserClub(comp) {
  const userId = getUserClubId();
  const idx = buildClubIndex(comp?.clubs);
  return { userId, club: userId ? idx.get(userId) || null : null, clubIndex: idx };
}

function getSideForFixture(userId, fx) {
  if (!fx || !userId) return null;
  if (String(fx.homeClubId) === String(userId)) return 'home';
  if (String(fx.awayClubId) === String(userId)) return 'away';
  return null;
}

function renderCompetitionSelect(sel) {
  const list = getCompetitions();
  sel.innerHTML = '';
  list.forEach((c) => {
    const opt = document.createElement('option');
    opt.value = String(c.id);
    opt.textContent = c.isCurrent ? `${c.name} (actual)` : c.name;
    sel.appendChild(opt);
  });
  if (!__selectedCompetitionId) __selectedCompetitionId = getDefaultCompetitionId();
  sel.value = String(__selectedCompetitionId);
}

function ensureBindings() {
  if (__bound) return;
  const sel = document.getElementById('stats-adv-competition-select');
  const tbody = document.getElementById('stats-adv-matches-body');
  if (!sel || !tbody) return;

  sel.addEventListener('change', () => {
    __selectedCompetitionId = String(sel.value || getDefaultCompetitionId());
    __expandedFixtureId = null;
    updateStatsView();
  });

  tbody.addEventListener('click', (ev) => {
    const target = ev.target instanceof Element ? ev.target : null;
    if (!target) return;

    const btn = target.closest('[data-fixture-id]');
    if (!btn) return;
    const fid = btn.getAttribute('data-fixture-id');
    if (!fid) return;

    // Botón "modal" (detalle completo) o "inline"
    if (btn.getAttribute('data-action') === 'modal') {
      openMatchDetailModal({ competitionId: __selectedCompetitionId, fixtureId: fid });
      return;
    }

    __expandedFixtureId = String(__expandedFixtureId) === String(fid) ? null : String(fid);
    updateStatsView();
  });

  __bound = true;
}

function getTeamStatsForUser(fx, side) {
  const ts = fx?.teamStats;
  if (!ts) return null;
  return side === 'home' ? ts.home : ts.away;
}

function getTeamStatsForOpp(fx, side) {
  const ts = fx?.teamStats;
  if (!ts) return null;
  return side === 'home' ? ts.away : ts.home;
}

function renderMatchesTable({ comp, userId, clubIndex, tbody }) {
  const season = Number(comp?.currentDate?.season || GameState.currentDate?.season || 1);
  const fixtures = Array.isArray(comp?.fixtures) ? comp.fixtures : [];

  const list = fixtures
    .filter((fx) => fx && fx.played && getSideForFixture(userId, fx))
    .slice()
    .sort((a, b) => Number(b.matchday || 0) - Number(a.matchday || 0));

  tbody.innerHTML = '';

  if (!list.length) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td colspan="10" class="muted">Aún no hay partidos jugados.</td>`;
    tbody.appendChild(tr);
    return;
  }

  list.forEach((fx) => {
    const side = getSideForFixture(userId, fx);
    const myStats = getTeamStatsForUser(fx, side);
    const oppStats = getTeamStatsForOpp(fx, side);

    const home = clubIndex.get(fx.homeClubId) || null;
    const away = clubIndex.get(fx.awayClubId) || null;
    const homeName = home?.shortName || home?.name || fx.homeClubId;
    const awayName = away?.shortName || away?.name || fx.awayClubId;

    const date = getGameDateFor(season, Number(fx.matchday || 1));
    const dateLabel = formatGameDateLabel(date);

    const isHome = side === 'home';
    const oppName = isHome ? awayName : homeName;
    const goalsFor = isHome ? Number(fx.homeGoals || 0) : Number(fx.awayGoals || 0);
    const goalsAgainst = isHome ? Number(fx.awayGoals || 0) : Number(fx.homeGoals || 0);

    const coatOpp = createCoatImgElement(isHome ? fx.awayClubId : fx.homeClubId, oppName, 18);

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${Number(fx.matchday || 0) || '—'}</td>
      <td>${esc(dateLabel)}</td>
      <td>
        <div class="club-cell">
          ${coatOpp ? coatOpp.outerHTML : ''}
          <span>${esc(oppName)}</span>
        </div>
      </td>
      <td><strong>${goalsFor} - ${goalsAgainst}</strong></td>
      <td>${myStats ? fmtPct(myStats.possessionPct) : '—'}</td>
      <td>${myStats ? fmtNum(myStats.shotsTotal, 0) : '—'} / ${myStats ? fmtNum(myStats.shotsOnTarget, 0) : '—'}</td>
      <td>${myStats ? fmtNum(myStats.passesCompleted, 0) : '—'} / ${myStats ? fmtNum(myStats.passesAttempted, 0) : '—'}</td>
      <td>${myStats ? fmtNum(myStats.distanceKm, 1) : '—'}</td>
      <td>${myStats ? fmtNum(myStats.yellowCards, 0) : '—'} / ${myStats ? fmtNum(myStats.redCards, 0) : '—'}</td>
      <td>
        <button class="btn btn-xs btn-secondary" type="button" data-action="inline" data-fixture-id="${esc(fx.id)}">Ver</button>
        <button class="btn btn-xs" type="button" data-action="modal" data-fixture-id="${esc(fx.id)}">Modal</button>
      </td>
    `;
    tbody.appendChild(tr);

    // Si está expandido, pintamos un row detalle justo debajo
    if (String(__expandedFixtureId) === String(fx.id)) {
      const detailTr = document.createElement('tr');
      detailTr.className = 'stats-adv-detail-row';
      const td = document.createElement('td');
      td.colSpan = 10;
      td.appendChild(renderInlineDetail({ comp, fx, userId, clubIndex, myStats, oppStats }));
      detailTr.appendChild(td);
      tbody.appendChild(detailTr);
    }
  });
}

function labelForEvent(ev) {
  if (!ev) return '';
  if (ev.type === 'GOAL') return 'Gol';
  if (ev.type === 'YELLOW_CARD') return 'Amarilla';
  if (ev.type === 'RED_CARD') return 'Roja';
  if (ev.type === 'INJURY') return 'Lesión';
  return ev.type || '';
}

function buildPlayerIndex(comp) {
  const idx = new Map();
  (comp?.clubs || []).forEach((club) => {
    (club?.players || []).forEach((p) => {
      if (p?.id) idx.set(p.id, { player: p, club });
    });
  });
  return idx;
}

function renderInlineDetail({ comp, fx, userId, clubIndex, myStats, oppStats }) {
  const side = getSideForFixture(userId, fx);
  const isHome = side === 'home';
  const home = clubIndex.get(fx.homeClubId) || null;
  const away = clubIndex.get(fx.awayClubId) || null;
  const homeName = home?.name || home?.shortName || fx.homeClubId;
  const awayName = away?.name || away?.shortName || fx.awayClubId;

  const wrap = document.createElement('div');
  wrap.className = 'stats-adv-inline';

  const score = fx.played ? `${fx.homeGoals} - ${fx.awayGoals}` : 'vs';
  const meta = fx?.meta || {};
  const stadium = meta.stadiumName || (home?.stadium?.name || home?.stadiumName || 'Estadio');
  const cap = meta.capacity || home?.stadium?.capacity || 0;
  const att = meta.attendance || 0;

  wrap.innerHTML = `
    <div class="stats-adv-detail__header">
      <div class="stats-adv-detail__title"><strong>${esc(homeName)}</strong> ${esc(score)} <strong>${esc(awayName)}</strong></div>
      <div class="stats-adv-mini">${esc(stadium)}${cap ? ` • Aforo: ${fmtNum(cap, 0)}` : ''}${att ? ` • Espectadores: ${fmtNum(att, 0)}` : ''}</div>
    </div>
    <div class="stats-adv-detail__grid">
      <div class="stats-adv-detail__card">
        <h4>Estadísticas (tu equipo)</h4>
        ${renderTeamStatsTable(myStats)}
      </div>
      <div class="stats-adv-detail__card">
        <h4>Estadísticas (rival)</h4>
        ${renderTeamStatsTable(oppStats)}
      </div>
      <div class="stats-adv-detail__card">
        <h4>Cronología</h4>
        ${renderTimelineHtml({ comp, fx })}
      </div>
      <div class="stats-adv-detail__card">
        <h4>Jugadores (tu equipo)</h4>
        ${renderPlayersHtml({ comp, fx, userId })}
      </div>
    </div>
  `;
  return wrap;
}

function renderTeamStatsTable(stats) {
  if (!stats) return '<div class="muted">Sin estadísticas avanzadas (partidos antiguos).</div>';

  const rows = [
    ['Posesión', fmtPct(stats.possessionPct)],
    ['Disparos', `${fmtNum(stats.shotsTotal)} (a puerta ${fmtNum(stats.shotsOnTarget)})`],
    ['Pases', `${fmtNum(stats.passesCompleted)} / ${fmtNum(stats.passesAttempted)} (${fmtPct(stats.passAccuracyPct)})`],
    ['Saques de esquina', fmtNum(stats.corners)],
    ['Fueras de juego', fmtNum(stats.offsides)],
    ['Recuperaciones', fmtNum(stats.recoveries)],
    ['Entradas', `${fmtNum(stats.tacklesWon)} / ${fmtNum(stats.tacklesLost)}`],
    ['Despejes', `${fmtNum(stats.clearancesCompleted)} / ${fmtNum(stats.clearancesAttempted)}`],
    ['Paradas', fmtNum(stats.saves)],
    ['Distancia (km)', fmtNum(stats.distanceKm, 1)],
    ['Faltas', fmtNum(stats.foulsCommitted)],
    ['Tarjetas', `${fmtNum(stats.yellowCards)} / ${fmtNum(stats.redCards)}`],
  ];

  return `
    <table class="table table-competition table-stats-adv-mini">
      <tbody>
        ${rows.map(([k, v]) => `<tr><td>${esc(k)}</td><td style="text-align:right;"><strong>${esc(v)}</strong></td></tr>`).join('')}
      </tbody>
    </table>
  `;
}

function renderTimelineHtml({ comp, fx }) {
  const playerIndex = buildPlayerIndex(comp);
  const evs = Array.isArray(fx?.events) ? fx.events : [];
  const subs = Array.isArray(fx?.substitutions) ? fx.substitutions : [];

  const items = [];
  evs.forEach((ev) => {
    const info = ev.playerId ? playerIndex.get(ev.playerId) : null;
    const name = info?.player?.name || ev.playerId || '';
    const club = info?.club?.shortName || info?.club?.name || ev.clubId || '';
    let extra = '';
    if (ev.type === 'GOAL' && ev.assistPlayerId) {
      const a = playerIndex.get(ev.assistPlayerId);
      if (a?.player?.name) extra = ` (asist. ${a.player.name})`;
    }
    items.push({ minute: Number(ev.minute || 0), html: `<li><span class="tmin">${fmtMinute(ev.minute)}</span> ${esc(labelForEvent(ev))}: <strong>${esc(name)}</strong>${extra} <span class="muted">(${esc(club)})</span></li>` });
  });
  subs.forEach((s) => {
    const out = playerIndex.get(s?.outPlayerId)?.player?.name || s?.outPlayerId || '';
    const inn = playerIndex.get(s?.inPlayerId)?.player?.name || s?.inPlayerId || '';
    items.push({ minute: Number(s?.minute || 0), html: `<li><span class="tmin">${fmtMinute(s?.minute)}</span> Cambio: entra <strong>${esc(inn)}</strong> por ${esc(out)}</li>` });
  });
  items.sort((a, b) => a.minute - b.minute);

  if (!items.length) return '<div class="muted">Sin cronología.</div>';
  return `<ul class="timeline">${items.map((i) => i.html).join('')}</ul>`;
}

function fmtMinute(m) {
  const mm = Number(m);
  if (!Number.isFinite(mm) || mm <= 0) return '';
  return `${mm}'`;
}

function renderPlayersHtml({ comp, fx, userId }) {
  const side = getSideForFixture(userId, fx);
  if (!side) return '<div class="muted">No es partido de tu equipo.</div>';
  const isHome = side === 'home';
  const myClubId = isHome ? fx.homeClubId : fx.awayClubId;
  const pstats = fx?.playerStatsById || null;
  if (!pstats) return '<div class="muted">Sin estadísticas de jugadores (partidos antiguos).</div>';

  const rows = Object.entries(pstats)
    .map(([pid, st]) => ({ pid, ...st }))
    .filter((r) => String(r.clubId) === String(myClubId))
    .sort((a, b) => (Number(b.minutes || 0) - Number(a.minutes || 0)) || String(a.playerName || a.pid).localeCompare(String(b.playerName || b.pid)));

  if (!rows.length) return '<div class="muted">Sin datos.</div>';

  const html = `
    <div class="stats-adv-players">
      <table class="table table-competition table-stats-adv-players">
        <thead>
          <tr>
            <th>Jugador</th>
            <th>Min</th>
            <th>G</th>
            <th>A</th>
            <th>Disparos</th>
            <th>Pases</th>
            <th>Rec</th>
            <th>Km</th>
            <th>TA</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map((r) => {
            const pass = `${fmtNum(r.passesCompleted)} / ${fmtNum(r.passesAttempted)}`;
            const shots = `${fmtNum(r.shotsTotal)} / ${fmtNum(r.shotsOnTarget)}`;
            return `
              <tr>
                <td>${esc(r.playerName || r.pid)}</td>
                <td>${fmtNum(r.minutes)}</td>
                <td>${fmtNum(r.goals)}</td>
                <td>${fmtNum(r.assists)}</td>
                <td>${esc(shots)}</td>
                <td>${esc(pass)}</td>
                <td>${fmtNum(r.recoveries)}</td>
                <td>${fmtNum(r.distanceKm, 1)}</td>
                <td>${fmtNum(r.yellowCards)}</td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
  return html;
}

export function initStatsUI() {
  __selectedCompetitionId = getDefaultCompetitionId();
  __expandedFixtureId = null;
}

export function updateStatsView() {
  ensureBindings();

  const sel = document.getElementById('stats-adv-competition-select');
  const seasonEl = document.getElementById('stats-adv-season-label');
  const tbody = document.getElementById('stats-adv-matches-body');
  const detail = document.getElementById('stats-adv-detail');
  if (!sel || !tbody) return;

  renderCompetitionSelect(sel);
  const comp = getComp();
  if (!comp) return;

  if (seasonEl) seasonEl.textContent = String(comp.currentDate?.season || GameState.currentDate?.season || 1);

  const { userId, clubIndex } = getUserClub(comp);
  renderMatchesTable({ comp, userId, clubIndex, tbody });

  // El "detail" de la vista se mantiene para compatibilidad con CSS/HTML,
  // pero ahora el detalle se renderiza inline dentro de la tabla.
  if (detail) detail.innerHTML = '';
}