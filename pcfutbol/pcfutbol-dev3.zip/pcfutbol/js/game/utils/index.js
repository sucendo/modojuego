// js/game/utils/index.js
// Barrel: utilidades del motor

export * from './tacticsState.js';
export * from './availability.js';
export * from './medical.js';