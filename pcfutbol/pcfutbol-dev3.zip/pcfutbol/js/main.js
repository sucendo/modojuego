// js/main.js

//import { initUI } from './ui.js';
import { initUI } from './ui/index.js';

document.addEventListener('DOMContentLoaded', () => {
  initUI();
});
