/**
 * Modal partido (placeholder).
 */

export function initMatchModal() {
  // TODO: migrar desde ui.js
}