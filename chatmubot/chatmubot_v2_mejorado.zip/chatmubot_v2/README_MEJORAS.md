# ChatmuBot v2 mejorado

## Qué se ha mejorado

- Estructura de rutas corregida:
  - `css/chatbot/chatbot.css`
  - `js/chatbot/*.js`
  - `data/chatbot/chatbotrespuestas.json`
- Loader modular seguro y sin cargas duplicadas.
- Core reescrito para evitar errores de inicialización.
- Historial persistente en `localStorage` con exportación JSON.
- UI renovada con cabecera, acciones rápidas y diseño responsive.
- Selector de idioma persistente.
- Modo oscuro persistente.
- Botón de lectura en voz alta.
- Botón de dictado por voz con degradación segura si el navegador no lo soporta.
- Botones para limpiar y exportar historial.
- Contexto conversacional más robusto:
  - cálculo continuo
  - traducción continua
  - ortografía continua
  - seguimiento básico del último tema de búsqueda
- Memoria local simple:
  - `guardar clave valor`
  - `mostrar clave`
  - `mostrar datos`
  - `borrar clave`
- Ayuda integrada con ejemplos.
- Mejoras de sanitización HTML y renderizado de mensajes.

## Comandos útiles

- `ayuda`
- `cuanto es 5*8`
- `+2`
- `traduce al inglés: buenos días`
- `como se escribe cocreta`
- `busca Roma`
- `guardar color azul`
- `mostrar color`
- `/reset`
- `/limpiar`
- `/exportar`

## Notas

- Si algunos servicios externos fallan, el chatbot sigue funcionando con respuestas locales y degradación elegante.
- Para un funcionamiento completo, conviene abrir el proyecto desde un servidor local o hosting web.
