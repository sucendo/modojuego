/**
 * ChatmuBot - Lógica conversacional (versión SAFE)
 * - Sin returns en el ámbito global
 * - Maneja contexto para cálculo continuo, búsqueda continua, listas genéricas, cortesías e insultos
 */

(function(){
  function _norm(s){ return String(s||"").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,""); }

  const INSULTOS = /\b(gilipollas|idiota|imb[eé]cil|est[uú]pido|tonto|asqueroso|mierda|capullo)\b/i;
  const RESET_CORTESIA = /^(gracias|de nada|vale|ok|okay|perfecto|entendido|genial|igualmente|a ti|no hay de que|no hay de qué)\.?$/i;

  function _resetCtx(ctx){
    if (!ctx) return;
    ctx.modo = null;
    ctx.modoLista = null;
    ctx.ultimaListaNombre = null;
    ctx.ultimaListaItems = null;
    ctx.confirm = null;
    ctx.confirmKey = null;
    ctx.buscaUltimo = null;
    ctx.calcValor = undefined;
    ctx.traducirIdioma = null;
    ctx.traducirUltima = null;
    ctx.ortoUltima = null;
  }

  function _activarLista(ctx, nombre, items){
    if (!Array.isArray(items) || !items.length) return false;
    ctx.modoLista = { nombre, items, indice: 0 };
    ctx.ultimaListaNombre = nombre;
    ctx.ultimaListaItems = items;
    return true;
  }

  function _itemActual(ctx){
    const m = ctx.modoLista; if (!m) return null;
    if (m.indice < 0) m.indice = 0;
    if (m.indice >= m.items.length) m.indice = m.items.length - 1;
    return m.items[m.indice];
  }

  function _siguiente(ctx){
    const m = ctx.modoLista; if (!m) return null;
    m.indice = (m.indice + 1) % m.items.length;
    return m.items[m.indice];
  }

  function _aTexto(it){
    if (it == null) return "";
    if (typeof it === "string") return it;
    if (typeof it === "object") {
      if (it.pregunta && it.respuesta) return it.pregunta;
      if (it.texto) return it.texto;
      return JSON.stringify(it);
    }
    return String(it);
  }

  function _esExpresionMatematicaSimple(txt){
    const t = String(txt||"").trim();
    if (!t) return false;
    if (/[^0-9\s+*\/x·^().,-]/i.test(t)) return false;
    return /[-+*\/x·^]/.test(t);
  }

  function manejarContextoConversacion(ctx, texto, tnorm, palabras, resp){
    const t = String(texto||"").trim();

    if (INSULTOS.test(t)) {
      ctx.insultos = (ctx.insultos||0) + 1;
      if (ctx.insultos >= 3) return "Puedo parar si quieres. ¿Deseas que dejemos los insultos y sigamos con otra cosa?";
    }

    if (ctx.confirm && ctx.confirm.pending) {
      const AFFIRM_CONFIRM = /\b(s[ií]|si|claro|vale|ok|okay|de acuerdo|correcto|por supuesto)\b/i;
      const NEG = /\b(no|para|det[eé]n|cancela|mejor no)\b/i;
      const act = ctx.confirm.action;
      if (AFFIRM_CONFIRM.test(tnorm)) {
        ctx.confirm = null;
        if (act === "lista_otro" && ctx.modoLista) {
          const it = _siguiente(ctx);
          return `${_aTexto(it)}\n¿Quieres otro?`;
        }
      } else if (NEG.test(tnorm)) {
        ctx.confirm = null;
        ctx.modoLista = null;
        return "Entendido.";
      }
    }

    if (RESET_CORTESIA.test(tnorm)) { _resetCtx(ctx); return null; }

    if (resp && typeof resp === "object") {
      const _coincideClave = (tn, clave) => {
        const k = _norm(clave); if (!k) return false;
        if (k === "hora") return /\bhora(s)?\b/i.test(tn);
        if (k.length <= 3) return new RegExp(`\\b${k}\\b`,"i").test(tn);
        return tn.includes(k);
      };
      for (const clave of Object.keys(resp)) {
        if (_coincideClave(tnorm, clave)) { _resetCtx(ctx); break; }
      }
    }

    const CAMBIO_ACCION =
      /^(?:\s*traduce\s+al\b)/i.test(t) ||
      /\b(busca|que es|qué es|quien es|quién es)\b/i.test(tnorm) ||
      /\b(calcula|cuanto es|cuánto es)\b/i.test(tnorm) ||
      _esExpresionMatematicaSimple(t) ||
      /\b(chistes?|broma(s)?|curiosidad(es)?|pel[ií]culas?|adivinanza(s)?|duelo|juego|jugar|corrige\b)\b/i.test(tnorm);

    if (!CAMBIO_ACCION) {
      if (ctx.modo === "calc") {
        if (RESET_CORTESIA.test(tnorm)) { _resetCtx(ctx); return "Entendido."; }
        const rel = t.match(/^\s*([+\-*/])\s*([\-+]?\d+(?:[.,]\d+)?)\s*$/);
        if (rel && typeof ctx.calcValor === "number") {
          const op = rel[1];
          const b = parseFloat(rel[2].replace(",", "."));
          if (!isNaN(b)) {
            let a = ctx.calcValor, r;
            if (op === "+") r = a + b;
            else if (op === "-") r = a - b;
            else if (op === "*") r = a * b;
            else if (op === "/") { if (b === 0) return "No se puede dividir por cero."; r = a / b; }
            ctx.calcValor = Number(r);
            ctx.modo = "calc";
            return `El resultado es ${r}`;
          }
        }
      }

      if (ctx.modo === "busca") {
        const mY = t.match(/^\s*(?:y|ahora)\s+(.+)$/i);
        if (mY && mY[1]) { ctx.buscaUltimo = mY[1].trim(); return null; }
      }

      if (ctx.modo === "traduce") {
        if (/(?:\b(deja|termina|para|cancela|sal(?:ir)?)\b.*\b(traducir|traducci[oó]n)\b)/i.test(t)) {
          _resetCtx(ctx); return "Hecho, dejo de traducir.";
        }
        if (RESET_CORTESIA.test(tnorm)) { _resetCtx(ctx); return "Entendido."; }
      }

      if (ctx.modo === "ortografia") {
        if (/(?:\b(deja|termina|para|cancela|sal(?:ir)?)\b.*\b(corregir|correcci[oó]n|ortograf[ií]a)\b)/i.test(t)) {
          _resetCtx(ctx); return "Hecho, dejo de corregir.";
        }
        if (RESET_CORTESIA.test(tnorm)) { _resetCtx(ctx); return "Entendido."; }
      }

      if (ctx.modoLista) {
        const AFFIRM = /\b(s[ií]|si|claro|de acuerdo|correcto|por supuesto|adelante|contin[uú]a|continuar|sigue|proceder)\b/i;
        if (/\botro\b/i.test(tnorm) || AFFIRM.test(tnorm)) {
          const it = _siguiente(ctx);
          ctx.confirm = { pending: true, action: "lista_otro" };
          return `${_aTexto(it)}\n¿Quieres otro?`;
        }
        if (RESET_CORTESIA.test(tnorm)) { ctx.modoLista = null; return "Entendido."; }
      }
    }

    if (/^\s*corrige\s*:\s*/i.test(t)) {
      const q = t.replace(/^\s*corrige\s*:\s*/i, "").trim();
      if (!q) return "Dime el texto que quieres corregir.";
      ctx.modo = "ortografia";
      ctx.ortoUltima = q;
      ctx.confirm = { pending:true, action:"orto_continuar" };
      return null;
    }

    if (!ctx.modoLista && resp && typeof resp === "object") {
      const LISTA_AUTO_KEYS = new Set(["chiste", "broma", "peliculas_lista", "adivinanza", "duelo", "cuentame una curiosidad", "cuéntame una curiosidad"]);
      for (const clave of Object.keys(resp)) {
        const val = resp[clave];
        if (!Array.isArray(val) || !val.length) continue;
        const k = _norm(clave);
        if (!k || !LISTA_AUTO_KEYS.has(k)) continue;
        const kEsc = k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        const reK = new RegExp(`\\b${kEsc}\\b`, "i");
        if (reK.test(tnorm)) {
          if (_activarLista(ctx, clave, val)) {
            const it = _itemActual(ctx);
            return `${_aTexto(it)}\n¿Quieres otro?`;
          }
        }
      }
    }

    if (!ctx.modoLista && /\botro\b/i.test(tnorm) && Array.isArray(ctx.ultimaListaItems) && ctx.ultimaListaItems.length) {
      if (_activarLista(ctx, ctx.ultimaListaNombre||"lista", ctx.ultimaListaItems)) {
        const it = _siguiente(ctx);
        return `${_aTexto(it)}\n¿Quieres otro?`;
      }
    }

    return null;
  }

  window.manejarContextoConversacion = manejarContextoConversacion;
})();
