/*
* chatbotLoader.js — carga ordenada y segura de los módulos del chatbot
* By Sucendo 2024
*/

(function () {
// Evita cargas dobles si el loader se incluye más de una vez
if (window.__CHATBOT_LOADER_ACTIVE__) return;
window.__CHATBOT_LOADER_ACTIVE__ = true;

// ==== Utilidades internas ====
const LOADED = (window.__CHATBOT_LOADED__ = window.__CHATBOT_LOADED__ || new Set());

// Resuelve la carpeta base del loader para cargar el resto desde el mismo sitio
const currentScript =
	document.currentScript ||
	(function () {
	const s = document.getElementsByTagName("script");
	return s[s.length - 1];
	})();
const BASE = (currentScript && currentScript.src.split("?")[0].replace(/\/[^\/]+$/, "/")) || "./";
window.__CHATBOT_BASE__ = BASE;


function alreadyLoaded(url) {
	if (LOADED.has(url)) return true;
	const scripts = document.querySelectorAll('script[src]');
	for (const s of scripts) {
	// Comparamos por nombre de archivo para ser tolerantes con rutas absolutas/relativas
	if (s.src.split("?")[0].endsWith("/" + url.split("?")[0].split("/").pop())) {
		return true;
	}
	}
	return false;
}

function loadScriptOnce(url, { timeout = 15000 } = {}) {
	return new Promise((resolve, reject) => {
	if (alreadyLoaded(url)) {
		LOADED.add(url);
		return resolve("cached");
	}
	const s = document.createElement("script");
	s.defer = true;
	s.src = url;

	const t = setTimeout(() => {
		s.onerror = s.onload = null;
		reject(new Error("Timeout cargando " + url));
	}, timeout);

	s.onload = () => {
		clearTimeout(t);
		LOADED.add(url);
		resolve("loaded");
	};
	s.onerror = () => {
		clearTimeout(t);
		reject(new Error("Error cargando " + url));
	};
	document.head.appendChild(s);
	});
}

async function loadEither(urls, opts) {
	let lastErr;
	for (const u of urls) {
	try {
		return await loadScriptOnce(u, opts);
	} catch (e) {
		lastErr = e;
		// Intentamos el siguiente
	}
	}
	throw lastErr || new Error("No se pudo cargar ninguna de: " + urls.join(", "));
}

function domReady() {
	if (document.readyState === "loading") {
	return new Promise((res) => document.addEventListener("DOMContentLoaded", res, { once: true }));
	}
	return Promise.resolve();
}

async function bootstrapIfAvailable() {
	// Llamamos a alguna función de arranque si el core la expone
	const candidates = ["inicializarChatbot", "initChatbot", "bootstrapChatbot", "setupChatbot"];
	for (const name of candidates) {
	const fn = window[name];
	if (typeof fn === "function") {
		try {
		await fn();
		return true;
		} catch (e) {
		console.warn(`[ChatbotLoader] Falló ${name}():`, e);
		}
	}
	}
	return false;
}

// ==== Secuencia de carga ====
(async () => {
	await domReady();

	const q = (p) => (p.startsWith("http") ? p : BASE + p);

	// 1) Utilidades primero (suele ser requerido por todo)
	await loadScriptOnce(q("chatbotUtilidades.js")).catch((e) => {
	console.error("[ChatbotLoader] No se pudo cargar chatbotUtilidades.js", e);
	throw e;
	});

	// 2) Core con fallback: chatbotCore.js -> chatbot.js
	await loadEither([q("chatbot.js"), q("chatbotCore.js")]).catch((e) => {
	console.error("[ChatbotLoader] No se pudo cargar el Core (chatbotCore.js/chatbot.js)", e);
	throw e;
	});

	// 3) Resto de módulos en orden recomendado
	const modules = [
	"chatbotCorrector.js",
	"chatbotLogicaConversacional.js",
	"chatbotPedia.js",
	"chatbotTranslate.js",
	"chatbotJuegos.js",
	];
	for (const m of modules) {
	try {
		await loadScriptOnce(q(m));
	} catch (e) {
		// No abortamos todo el bot por un módulo opcional; registramos el error y seguimos
		console.warn(`[ChatbotLoader] Módulo opcional no cargado: ${m}`, e);
	}
	}

	// 4) Arranque si existe alguna función conocida
	const started = await bootstrapIfAvailable();
	console.info(
	`[ChatbotLoader] Listo. Base="${BASE}" · Módulos cargados: ${Array.from(LOADED).map((u) => u.split("/").pop()).join(", ")}${started ? " · Arrancado" : " · (sin función de arranque)"}`
	);
})().catch((e) => {
	console.error("[ChatbotLoader] Error fatal durante la carga:", e);
});
})();
