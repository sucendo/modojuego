/*
* chatbotJuegos.js
* By Sucendo 2024-2026
*/

function iniciarAdivinanza(ctx, respuestas) {
  const lista = respuestas["adivinanza"] || [];
  if (!Array.isArray(lista) || !lista.length) return "No tengo adivinanzas ahora.";
  const adivinanzaAleatoria = lista[Math.floor(Math.random() * lista.length)];
  ctx.respuestaCorrecta = adivinanzaAleatoria.respuesta;
  ctx.palabraClave = "adivinanza";
  return adivinanzaAleatoria.pregunta;
}

function manejarAdivinanza(contextoConversacion, respuestaUsuario) {
  const esCorrecto = verificarRespuesta(contextoConversacion, respuestaUsuario);
  if (esCorrecto) {
    contextoConversacion.respuestaCorrecta = null;
    return "¡Correcto! ¿Quieres otra adivinanza?";
  }
  return "¡Incorrecto! Inténtalo de nuevo o di 'otra' para una nueva adivinanza.";
}

function verificarRespuesta(contextoConversacion, respuestaUsuario) {
  const respuestaCorrecta = String(contextoConversacion.respuestaCorrecta || "").toLowerCase().trim();
  return String(respuestaUsuario || "").toLowerCase().trim() === respuestaCorrecta;
}

function iniciarDueloDeInsultos(ctx, respuestas) {
  const lista = respuestas["duelo"] || [];
  if (!Array.isArray(lista) || !lista.length) return "No tengo duelos ahora.";
  const insultoAleatorio = lista[Math.floor(Math.random() * lista.length)];
  ctx.respuestaCorrecta = insultoAleatorio.respuesta;
  ctx.palabrasClave = insultoAleatorio.palabrasClave || [];
  ctx.palabraClave = "duelo";
  return `El chatbot te dice: "${insultoAleatorio.insulto}". ¡Es tu turno!`;
}

function manejarRespuestaInsulto(contextoConversacion, respuestaUsuario) {
  const palabrasClave = Array.isArray(contextoConversacion.palabrasClave) ? contextoConversacion.palabrasClave : [];
  const respuestaUsuarioNormalizada = String(respuestaUsuario || "").toLowerCase();
  const esCorrecto = palabrasClave.length && palabrasClave.every((palabra) => respuestaUsuarioNormalizada.includes(String(palabra).toLowerCase()));

  if (esCorrecto) {
    contextoConversacion.repeticiones = (contextoConversacion.repeticiones || 0) + 1;
    return "¡Buena réplica! ¿Listo para el siguiente insulto?";
  }

  const respuestaCorrecta = contextoConversacion.respuestaCorrecta;
  return `¡Respuesta incorrecta! La réplica correcta era: "${respuestaCorrecta}". ¿Quieres intentarlo de nuevo?`;
}
